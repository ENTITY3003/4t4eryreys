#!/usr/bin/env python3

import argparse
import html
import json
import os
import re
from collections import Counter, defaultdict
from datetime import datetime

VERSION = "2.0"

IP_PATTERN = re.compile(
r"\b(?:\d{1,3}.){3}\d{1,3}\b"
)

URL_PATTERN = re.compile(
r"https?://[^\s"'<>]+",
re.IGNORECASE
)

HASH_PATTERN = re.compile(
r"\b(?:[a-fA-F0-9]{32}|"
r"[a-fA-F0-9]{40}|"
r"[a-fA-F0-9]{64})\b"
)

PORT_PATTERN = re.compile(
r"(?:port|dport|dst_port|destination_port)"
r"\s*[=:]\s*(\d{1,5})",
re.IGNORECASE
)

USER_PATTERN = re.compile(
r"(?:user|username|for)\s*[=:]?\s*"
r"["']?([A-Za-z0-9_.@-]+)",
re.IGNORECASE
)

STATUS_PATTERN = re.compile(
r"\s([1-5]\d{2})\s"
)

def valid_ip(value):
try:
parts = value.split(".")
return (
len(parts) == 4
and all(0 <= int(part) <= 255 for part in parts)
)
except (ValueError, AttributeError):
return False

def extract_ips(text):
return sorted(
{
ip
for ip in IP_PATTERN.findall(text)
if valid_ip(ip)
}
)

def extract_urls(text):
return sorted(set(URL_PATTERN.findall(text)))

def extract_hashes(text):
return sorted(set(HASH_PATTERN.findall(text)))

def extract_port(text):
match = PORT_PATTERN.search(text)

if not match:
    return None

port = int(match.group(1))

if 1 <= port <= 65535:
    return port

return None

def extract_username(text):
match = USER_PATTERN.search(text)
return match.group(1) if match else None

def severity(score):
if score >= 90:
return "CRITICAL"
if score >= 70:
return "HIGH"
if score >= 40:
return "MEDIUM"
if score >= 15:
return "LOW"
return "INFO"

class LogHunter:
def init(self):
self.events = []
self.alerts = []

    self.ip_counter = Counter()
    self.port_counter = Counter()
    self.user_counter = Counter()
    self.status_counter = Counter()

    self.failed_auth = Counter()
    self.success_auth = Counter()

    self.ip_ports = defaultdict(set)
    self.ip_status = defaultdict(Counter)

    self.iocs = {
        "ips": set(),
        "urls": set(),
        "hashes": set(),
    }

def classify_event(self, line):
    text = line.lower()

    event_type = "GENERAL"
    score = 0
    reasons = []

    if any(
        phrase in text
        for phrase in (
            "failed password",
            "authentication failure",
            "invalid user",
            "failed publickey",
            "login failed",
            "authentication failed",
        )
    ):
        event_type = "AUTH_FAILURE"
        score += 20
        reasons.append("Authentication failure")

    elif any(
        phrase in text
        for phrase in (
            "accepted password",
            "accepted publickey",
            "login successful",
            "authentication successful",
        )
    ):
        event_type = "AUTH_SUCCESS"

    status_match = STATUS_PATTERN.search(line)

    if status_match:
        status = int(status_match.group(1))

        if 400 <= status <= 499:
            event_type = "HTTP_4XX"
            score += 3

        elif 500 <= status <= 599:
            event_type = "HTTP_5XX"
            score += 10
            reasons.append("HTTP server error")

    indicators = {
        "sqlmap": "SQLMap indicator",
        "nmap": "Nmap indicator",
        "masscan": "Masscan indicator",
        "nikto": "Nikto indicator",
        "wpscan": "WPScan indicator",
        "gobuster": "Gobuster indicator",
        "dirbuster": "Dirbuster indicator",
        "burpsuite": "Burp Suite indicator",
        "metasploit": "Metasploit indicator",
        "union select": "Possible SQL injection",
        "information_schema": "Possible SQL injection",
        "../": "Possible path traversal",
        "..\\": "Possible path traversal",
        "/etc/passwd": "Sensitive file access pattern",
        "cmd.exe": "Command execution indicator",
        "powershell": "PowerShell indicator",
        "/bin/sh": "Shell execution indicator",
        "command=": "Command execution indicator",
        "exec=": "Command execution indicator",
    }

    for indicator, reason in indicators.items():
        if indicator in text:
            score += 25
            reasons.append(reason)

    if "permission denied" in text:
        score += 15
        reasons.append("Permission denied")

    if "unauthorized" in text:
        score += 15
        reasons.append("Unauthorized activity")

    if "forbidden" in text:
        score += 10
        reasons.append("Forbidden request")

    return event_type, min(score, 100), reasons

def process_line(self, line, source, line_number):
    ips = extract_ips(line)
    urls = extract_urls(line)
    hashes = extract_hashes(line)

    port = extract_port(line)
    username = extract_username(line)

    for ip in ips:
        self.ip_counter[ip] += 1
        self.iocs["ips"].add(ip)

        if port:
            self.ip_ports[ip].add(port)

    for url in urls:
        self.iocs["urls"].add(url)

    for file_hash in hashes:
        self.iocs["hashes"].add(file_hash)

    if port:
        self.port_counter[port] += 1

    if username:
        self.user_counter[username] += 1

    event_type, score, reasons = self.classify_event(line)

    if event_type == "AUTH_FAILURE":
        for ip in ips:
            self.failed_auth[ip] += 1

    elif event_type == "AUTH_SUCCESS":
        for ip in ips:
            self.success_auth[ip] += 1

    status_match = STATUS_PATTERN.search(line)

    if status_match:
        status = int(status_match.group(1))

        for ip in ips:
            self.status_counter[status] += 1
            self.ip_status[ip][status] += 1

    self.events.append(
        {
            "source": source,
            "line": line_number,
            "event_type": event_type,
            "score": score,
            "severity": severity(score),
            "ips": ips,
            "urls": urls,
            "hashes": hashes,
            "port": port,
            "username": username,
            "reasons": reasons,
            "message": line.strip(),
        }
    )

def detect_bruteforce(self):
    for ip, count in self.failed_auth.items():
        if count >= 20:
            self.add_alert(
                "BRUTE_FORCE",
                "CRITICAL",
                95,
                ip,
                count,
                f"{count} authentication failures "
                f"were observed from {ip}.",
                "Review authentication logs and "
                "validate whether the source is authorized.",
            )

        elif count >= 10:
            self.add_alert(
                "BRUTE_FORCE",
                "HIGH",
                80,
                ip,
                count,
                f"{count} authentication failures "
                f"were observed from {ip}.",
                "Investigate the source and related "
                "authentication activity.",
            )

        elif count >= 5:
            self.add_alert(
                "BRUTE_FORCE",
                "MEDIUM",
                55,
                ip,
                count,
                f"{count} authentication failures "
                f"were observed from {ip}.",
                "Review the authentication timeline.",
            )

def detect_scan_patterns(self):
    for ip, ports in self.ip_ports.items():
        port_count = len(ports)

        if port_count >= 20:
            self.add_alert(
                "PORT_SCAN_PATTERN",
                "CRITICAL",
                92,
                ip,
                port_count,
                f"{ip} interacted with "
                f"{port_count} different ports.",
                "Review network telemetry and determine "
                "whether the activity was authorized.",
            )

        elif port_count >= 10:
            self.add_alert(
                "PORT_SCAN_PATTERN",
                "HIGH",
                78,
                ip,
                port_count,
                f"{ip} interacted with "
                f"{port_count} different ports.",
                "Investigate the source and surrounding events.",
            )

        elif port_count >= 5:
            self.add_alert(
                "PORT_SCAN_PATTERN",
                "MEDIUM",
                52,
                ip,
                port_count,
                f"{ip} interacted with "
                f"{port_count} different ports.",
                "Inspect related network activity.",
            )

def detect_high_frequency_ips(self):
    for ip, count in self.ip_counter.items():
        if count >= 200:
            self.add_alert(
                "HIGH_FREQUENCY_IP",
                "HIGH",
                75,
                ip,
                count,
                f"{ip} generated {count} log events.",
                "Review the IP timeline and determine "
                "whether the volume is expected.",
            )

        elif count >= 100:
            self.add_alert(
                "HIGH_FREQUENCY_IP",
                "MEDIUM",
                50,
                ip,
                count,
                f"{ip} generated {count} log events.",
                "Inspect related requests and events.",
            )

def detect_error_spikes(self):
    for ip, statuses in self.ip_status.items():
        error_count = sum(
            count
            for status, count in statuses.items()
            if status >= 400
        )

        if error_count >= 100:
            self.add_alert(
                "HTTP_ERROR_SPIKE",
                "HIGH",
                72,
                ip,
                error_count,
                f"{ip} generated {error_count} "
                f"HTTP 4xx/5xx responses.",
                "Inspect request paths, user agents "
                "and authentication activity.",
            )

        elif error_count >= 50:
            self.add_alert(
                "HTTP_ERROR_SPIKE",
                "MEDIUM",
                48,
                ip,
                error_count,
                f"{ip} generated {error_count} "
                f"HTTP 4xx/5xx responses.",
                "Review the related web requests.",
            )

def detect_tool_indicators(self):
    tools = (
        "nmap",
        "masscan",
        "sqlmap",
        "nikto",
        "wpscan",
        "gobuster",
        "dirbuster",
        "burpsuite",
        "metasploit",
    )

    for event in self.events:
        message = event["message"].lower()

        for tool in tools:
            if tool in message:
                source = (
                    event["ips"][0]
                    if event["ips"]
                    else "unknown"
                )

                self.add_alert(
                    "TOOL_INDICATOR",
                    "MEDIUM",
                    50,
                    source,
                    1,
                    f"Possible {tool} activity "
                    "was found in the log.",
                    "Confirm whether the activity "
                    "belongs to an authorized security test.",
                )
                break

def detect_attack_patterns(self):
    patterns = {
        "SQL_INJECTION_PATTERN": (
            "union select",
            "information_schema",
            "' or '1'='1",
            "sqlmap",
        ),
        "PATH_TRAVERSAL_PATTERN": (
            "../",
            "..\\",
            "/etc/passwd",
        ),
        "COMMAND_INJECTION_PATTERN": (
            "cmd=",
            "exec=",
            "command=",
            "/bin/sh",
            "powershell",
        ),
    }

    for event in self.events:
        message = event["message"].lower()

        for attack_type, indicators in patterns.items():
            matched = next(
                (
                    indicator
                    for indicator in indicators
                    if indicator in message
                ),
                None,
            )

            if matched:
                source = (
                    event["ips"][0]
                    if event["ips"]
                    else "unknown"
                )

                self.add_alert(
                    attack_type,
                    "HIGH",
                    80,
                    source,
                    1,
                    f"Pattern '{matched}' was detected.",
                    "Review the complete request and "
                    "surrounding events.",
                )

def detect_auth_anomalies(self):
    for ip, successes in self.success_auth.items():
        failures = self.failed_auth.get(ip, 0)

        if failures >= 10 and successes > 0:
            self.add_alert(
                "AUTH_ANOMALY",
                "HIGH",
                82,
                ip,
                successes,
                f"{ip} had {failures} failed "
                f"authentication attempts followed "
                f"by {successes} successful attempts.",
                "Review the authentication timeline "
                "and verify the successful session.",
            )

def add_alert(
    self,
    alert_type,
    alert_severity,
    score,
    source,
    count,
    description,
    recommendation,
):
    self.alerts.append(
        {
            "type": alert_type,
            "severity": alert_severity,
            "score": score,
            "source": source,
            "count": count,
            "description": description,
            "recommendation": recommendation,
        }
    )

def analyze(self):
    self.detect_bruteforce()
    self.detect_scan_patterns()
    self.detect_high_frequency_ips()
    self.detect_error_spikes()
    self.detect_tool_indicators()
    self.detect_attack_patterns()
    self.detect_auth_anomalies()

    unique = []
    seen = set()

    for alert in self.alerts:
        key = json.dumps(
            alert,
            sort_keys=True,
        )

        if key not in seen:
            seen.add(key)
            unique.append(alert)

    priority = {
        "CRITICAL": 4,
        "HIGH": 3,
        "MEDIUM": 2,
        "LOW": 1,
        "INFO": 0,
    }

    self.alerts = sorted(
        unique,
        key=lambda item: (
            priority.get(item["severity"], 0),
            item["score"],
        ),
        reverse=True,
    )

def build_report(self):
    severity_counts = Counter(
        alert["severity"]
        for alert in self.alerts
    )

    return {
        "loghunter": {
            "version": VERSION,
            "generated_at": datetime.utcnow().isoformat()
            + "Z",
        },
        "summary": {
            "events": len(self.events),
            "alerts": len(self.alerts),
            "critical": severity_counts["CRITICAL"],
            "high": severity_counts["HIGH"],
            "medium": severity_counts["MEDIUM"],
            "low": severity_counts["LOW"],
            "info": severity_counts["INFO"],
        },
        "statistics": {
            "top_ips": [
                {
                    "ip": ip,
                    "count": count,
                }
                for ip, count in
                self.ip_counter.most_common(20)
            ],
            "top_ports": [
                {
                    "port": port,
                    "count": count,
                }
                for port, count in
                self.port_counter.most_common(20)
            ],
            "top_users": [
                {
                    "username": username,
                    "count": count,
                }
                for username, count in
                self.user_counter.most_common(20)
            ],
            "http_status": [
                {
                    "status": status,
                    "count": count,
                }
                for status, count in
                self.status_counter.most_common(20)
            ],
            "authentication": {
                "failed": sum(self.failed_auth.values()),
                "successful": sum(self.success_auth.values()),
            },
        },
        "iocs": {
            "ips": sorted(self.iocs["ips"]),
            "urls": sorted(self.iocs["urls"]),
            "hashes": sorted(self.iocs["hashes"]),
        },
        "alerts": self.alerts,
        "timeline": self.events,
    }

def escape(value):
return html.escape(str(value))

def build_html(report):
summary = report["summary"]

alerts = []

for alert in report["alerts"]:
    alerts.append(
        f"""
        <article class="alert">
            <div class="alert-head">
                <h3>{escape(alert["type"])}</h3>
                <span class="severity "
                f"{alert["severity"].lower()}">
                    {escape(alert["severity"])}
                </span>
            </div>

            <p>
                <strong>Source:</strong>
                {escape(alert["source"])}
            </p>

            <p>
                <strong>Risk Score:</strong>
                {alert["score"]}
            </p>

            <p>
                {escape(alert["description"])}
            </p>

            <p class="recommendation">
                <strong>Recommendation:</strong>
                {escape(alert["recommendation"])}
            </p>
        </article>
        """
    )

alert_section = (
    "\n".join(alerts)
    if alerts
    else "<p>No suspicious activity detected.</p>"
)

ip_items = "".join(
    f"<li>{escape(ip)}</li>"
    for ip in report["iocs"]["ips"]
)

url_items = "".join(
    f"<li>{escape(url)}</li>"
    for url in report["iocs"]["urls"]
)

hash_items = "".join(
    f"<li>{escape(value)}</li>"
    for value in report["iocs"]["hashes"]
)

top_ips = "".join(
    f"<li>{escape(item['ip'])} "
    f"— {item['count']} events</li>"
    for item in report["statistics"]["top_ips"]
)

return f"""<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport"
content="width=device-width, initial-scale=1.0"><title>LogHunter Report</title><style>
body {{
    margin: 0;
    background: #080c0a;
    color: #dce5df;
    font-family: Arial, sans-serif;
}}

.container {{
    max-width: 1200px;
    margin: auto;
    padding: 30px;
}}

header {{
    background: #0f1712;
    border: 1px solid #26372d;
    padding: 25px;
    margin-bottom: 25px;
}}

header h1 {{
    margin: 0;
}}

.muted {{
    color: #7e9085;
}}

.cards {{
    display: grid;
    grid-template-columns:
    repeat(auto-fit, minmax(140px, 1fr));
    gap: 12px;
    margin-bottom: 30px;
}}

.card {{
    background: #0f1712;
    border: 1px solid #26372d;
    padding: 18px;
}}

.card strong {{
    display: block;
    font-size: 28px;
    margin-top: 8px;
}}

.alert {{
    background: #0f1712;
    border: 1px solid #26372d;
    padding: 20px;
    margin-bottom: 15px;
}}

.alert-head {{
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 15px;
}}

.severity {{
    border: 1px solid #405246;
    padding: 5px 10px;
    font-size: 12px;
    font-weight: bold;
}}

.critical {{
    border-color: #a92d2d;
}}

.high {{
    border-color: #a65a2c;
}}

.medium {{
    border-color: #a38732;
}}

.low {{
    border-color: #4e765c;
}}

.info {{
    border-color: #4b6677;
}}

.recommendation {{
    color: #abbab0;
}}

.grid {{
    display: grid;
    grid-template-columns:
    repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
}}

.box {{
    background: #0f1712;
    border: 1px solid #26372d;
    padding: 20px;
}}

li {{
    margin: 7px 0;
    word-break: break-all;
}}

section {{
    margin-top: 35px;
}}
</style></head><body><div class="container"><header>
<h1>LogHunter</h1>
<p class="muted">
Security Log Analysis & Threat Hunting
</p>
</header><div class="cards"><div class="card">
Events
<strong>{summary["events"]}</strong>
</div><div class="card">
Alerts
<strong>{summary["alerts"]}</strong>
</div><div class="card">
Critical
<strong>{summary["critical"]}</strong>
</div><div class="card">
High
<strong>{summary["high"]}</strong>
</div><div class="card">
Medium
<strong>{summary["medium"]}</strong>
</div><div class="card">
Low
<strong>{summary["low"]}</strong>
</div></div><section>
<h2>Threat Alerts</h2>
{alert_section}
</section><section>
<h2>Indicators of Compromise</h2><div class="grid"><div class="box">
<h3>IP Addresses</h3>
<ul>
{ip_items or "<li>None</li>"}
</ul>
</div><div class="box">
<h3>URLs</h3>
<ul>
{url_items or "<li>None</li>"}
</ul>
</div><div class="box">
<h3>Hashes</h3>
<ul>
{hash_items or "<li>None</li>"}
</ul>
</div></div>
</section><section>
<h2>Top IP Addresses</h2><div class="box">
<ul>
{top_ips or "<li>None</li>"}
</ul>
</div></section></div></body>
</html>
"""def main():
parser = argparse.ArgumentParser(
description="LogHunter - Threat Hunting Log Analyzer"
)

parser.add_argument(
    "logfile",
    help="Path to the log file",
)

parser.add_argument(
    "-o",
    "--output",
    default="loghunter.json",
    help="JSON report path",
)

parser.add_argument(
    "--html",
    default="loghunter.html",
    help="HTML report path",
)

parser.add_argument(
    "--max-lines",
    type=int,
    default=0,
    help="Maximum lines to analyze",
)

args = parser.parse_args()

if not os.path.isfile(args.logfile):
    print(f"[!] File not found: {args.logfile}")
    return 1

hunter = LogHunter()

print("[*] LogHunter starting...")
print(f"[*] Log: {args.logfile}")

try:
    with open(
        args.logfile,
        "r",
        encoding="utf-8",
        errors="replace",
    ) as logfile:

        for line_number, line in enumerate(
            logfile,
            start=1,
        ):
            if (
                args.max_lines > 0
                and line_number > args.max_lines
            ):
                break

            if line.strip():
                hunter.process_line(
                    line,
                    args.logfile,
                    line_number,
                )

except PermissionError:
    print(
        "[!] Permission denied. "
        "Use an authorized log file."
    )
    return 1

hunter.analyze()
report = hunter.build_report()

with open(
    args.output,
    "w",
    encoding="utf-8",
) as output_file:
    json.dump(
        report,
        output_file,
        indent=4,
        ensure_ascii=False,
    )

with open(
    args.html,
    "w",
    encoding="utf-8",
) as html_file:
    html_file.write(
        build_html(report)
    )

summary = report["summary"]

print()
print("========== LogHunter ==========")
print(f"Events   : {summary['events']}")
print(f"Alerts   : {summary['alerts']}")
print(f"Critical : {summary['critical']}")
print(f"High     : {summary['high']}")
print(f"Medium   : {summary['medium']}")
print(f"Low      : {summary['low']}")
print()
print(f"[+] JSON: {args.output}")
print(f"[+] HTML: {args.html}")

return 0

if name == "main":
raise SystemExit(main())