#!/usr/bin/env python3

"""
Wazuh Threat Hunter
Defensive real-time threat hunting and alert correlation.

Features:
- Real-time alerts.json monitoring
- Alert correlation
- Authentication burst detection
- Privilege escalation indicators
- Suspicious tool detection
- IOC extraction
- MITRE ATT&CK extraction
- Risk scoring
- Incident generation
- JSON incident logging
- Optional webhook notification

This tool DOES NOT execute commands on endpoints.
"""

import argparse
import hashlib
import ipaddress
import json
import os
import re
import sys
import time
import urllib.request
import urllib.error

from collections import defaultdict, deque
from datetime import datetime, timezone


DEFAULT_ALERT_FILE = "/var/ossec/logs/alerts/alerts.json"
DEFAULT_REPORT_DIR = "./threat_hunter_reports"

# Correlation window
WINDOW_SECONDS = 300

# Authentication threshold
AUTH_FAILURE_THRESHOLD = 5

# Duplicate suppression
DEDUP_SECONDS = 120


class ThreatHunter:

    def __init__(
        self,
        alert_file,
        report_dir,
        severity_threshold=10,
        webhook=None
    ):

        self.alert_file = alert_file
        self.report_dir = report_dir
        self.severity_threshold = severity_threshold
        self.webhook = webhook

        os.makedirs(self.report_dir, exist_ok=True)

        # IP -> timestamps
        self.auth_failures = defaultdict(deque)

        # IP -> recent events
        self.events = defaultdict(deque)

        # Fingerprint -> last timestamp
        self.dedup = {}

        self.stats = {
            "alerts": 0,
            "high_severity": 0,
            "incidents": 0,
            "auth_bursts": 0,
            "web_indicators": 0,
            "privilege_indicators": 0,
            "malware_indicators": 0,
        }

    # --------------------------------------------------
    # General helpers
    # --------------------------------------------------

    @staticmethod
    def utc_now():

        return datetime.now(
            timezone.utc
        ).isoformat()

    @staticmethod
    def clean_text(value):

        if value is None:
            return ""

        if isinstance(value, (dict, list)):
            return json.dumps(
                value,
                ensure_ascii=False
            )

        return str(value)

    @staticmethod
    def flatten_json(obj):

        values = []

        def walk(value):

            if isinstance(value, dict):

                for key, item in value.items():

                    values.append(str(key))

                    walk(item)

            elif isinstance(value, list):

                for item in value:
                    walk(item)

            else:

                values.append(str(value))

        walk(obj)

        return " ".join(values)

    # --------------------------------------------------
    # IOC extraction
    # --------------------------------------------------

    @staticmethod
    def extract_ips(text):

        results = set()

        candidates = re.findall(
            r'(?<![\w:])'
            r'(?:\d{1,3}\.){3}\d{1,3}'
            r'(?![\w])',
            text
        )

        for value in candidates:

            try:

                ip = ipaddress.ip_address(value)

                results.add(str(ip))

            except ValueError:

                pass

        return sorted(results)

    @staticmethod
    def extract_urls(text):

        urls = re.findall(
            r'https?://[^\s"\'<>]+',
            text,
            flags=re.IGNORECASE
        )

        return sorted(set(urls))

    @staticmethod
    def extract_hashes(text):

        hashes = set()

        patterns = [
            r'\b[a-fA-F0-9]{32}\b',
            r'\b[a-fA-F0-9]{40}\b',
            r'\b[a-fA-F0-9]{64}\b',
        ]

        for pattern in patterns:

            hashes.update(
                re.findall(pattern, text)
            )

        return sorted(hashes)

    # --------------------------------------------------
    # Field extraction
    # --------------------------------------------------

    @staticmethod
    def get_nested(data, *paths):

        for path in paths:

            current = data

            try:

                for key in path:

                    if not isinstance(
                        current,
                        dict
                    ):
                        raise KeyError

                    current = current[key]

                if current not in (
                    None,
                    "",
                    [],
                    {}
                ):

                    return current

            except (KeyError, TypeError):

                continue

        return None

    def normalize_alert(self, alert):

        rule = alert.get(
            "rule",
            {}
        )

        agent = alert.get(
            "agent",
            {}
        )

        data = alert.get(
            "data",
            {}
        )

        timestamp = alert.get(
            "timestamp",
            self.utc_now()
        )

        level = rule.get(
            "level",
            0
        )

        try:
            level = int(level)

        except (TypeError, ValueError):

            level = 0

        rule_id = str(
            rule.get(
                "id",
                "unknown"
            )
        )

        description = self.clean_text(
            rule.get(
                "description",
                ""
            )
        )

        agent_name = self.clean_text(
            agent.get(
                "name",
                "unknown"
            )
        )

        agent_id = self.clean_text(
            agent.get(
                "id",
                ""
            )
        )

        src_ip = self.get_nested(
            alert,
            ("data", "srcip"),
            ("data", "src_ip"),
            ("srcip",),
            ("src_ip",)
        )

        dst_ip = self.get_nested(
            alert,
            ("data", "dstip"),
            ("data", "dst_ip"),
            ("dstip",),
            ("dst_ip",)
        )

        user = self.get_nested(
            alert,
            ("data", "dstuser"),
            ("data", "srcuser"),
            ("data", "user"),
            ("user",)
        )

        mitre = rule.get(
            "mitre",
            {}
        )

        if isinstance(mitre, dict):

            mitre_ids = mitre.get(
                "id",
                []
            )

            if isinstance(
                mitre_ids,
                str
            ):

                mitre_ids = [
                    mitre_ids
                ]

            tactics = mitre.get(
                "tactic",
                []
            )

            techniques = mitre.get(
                "technique",
                []
            )

        else:

            mitre_ids = []
            tactics = []
            techniques = []

        groups = rule.get(
            "groups",
            []
        )

        if not isinstance(groups, list):

            groups = []

        full_text = (
            self.flatten_json(alert)
            .lower()
        )

        return {
            "timestamp": timestamp,
            "level": level,
            "rule_id": rule_id,
            "description": description,
            "agent": agent_name,
            "agent_id": agent_id,
            "src_ip": self.clean_text(src_ip),
            "dst_ip": self.clean_text(dst_ip),
            "user": self.clean_text(user),
            "mitre_ids": mitre_ids,
            "mitre_tactics": tactics,
            "mitre_techniques": techniques,
            "groups": groups,
            "raw": alert,
            "text": full_text,
        }

    # --------------------------------------------------
    # Detection logic
    # --------------------------------------------------

    def detect_auth_failure(self, event):

        keywords = [
            "authentication failure",
            "authentication failed",
            "failed password",
            "login failed",
            "invalid user",
            "authentication error",
            "failed login",
            "logon failure"
        ]

        return any(
            keyword in event["text"]
            for keyword in keywords
        )

    def detect_web_attack(self, event):

        keywords = [
            "sql injection",
            "xss",
            "cross site scripting",
            "command injection",
            "directory traversal",
            "path traversal",
            "web attack",
            "remote file inclusion",
            "local file inclusion"
        ]

        return any(
            keyword in event["text"]
            for keyword in keywords
        )

    def detect_privilege(self, event):

        keywords = [
            "privilege escalation",
            "elevated privileges",
            "root privileges",
            "administrator privileges",
            "sudo",
            "setuid",
            "run as administrator"
        ]

        return any(
            keyword in event["text"]
            for keyword in keywords
        )

    def detect_malware(self, event):

        keywords = [
            "malware",
            "trojan",
            "ransomware",
            "rootkit",
            "backdoor",
            "cryptominer",
            "virus detected",
            "malicious file",
            "potentially unwanted"
        ]

        return any(
            keyword in event["text"]
            for keyword in keywords
        )

    def detect_suspicious_tools(self, event):

        tools = [
            "mimikatz",
            "powershell",
            "certutil",
            "mshta",
            "regsvr32",
            "rundll32",
            "nc.exe",
            "netcat",
            "psexec",
            "wmic"
        ]

        return [
            tool
            for tool in tools
            if tool in event["text"]
        ]

    # --------------------------------------------------
    # Correlation
    # --------------------------------------------------

    def correlate(self, event):

        findings = []

        ip = (
            event["src_ip"]
            or "unknown"
        )

        now = time.time()

        self.events[ip].append(
            (
                now,
                event
            )
        )

        # Remove old events
        while (
            self.events[ip]
            and now - self.events[ip][0][0]
            > WINDOW_SECONDS
        ):

            self.events[ip].popleft()

        # ----------------------------------------------
        # Authentication burst
        # ----------------------------------------------

        if self.detect_auth_failure(event):

            self.auth_failures[ip].append(
                now
            )

            while (
                self.auth_failures[ip]
                and now -
                self.auth_failures[ip][0]
                > 60
            ):

                self.auth_failures[ip].popleft()

            count = len(
                self.auth_failures[ip]
            )

            if count >= AUTH_FAILURE_THRESHOLD:

                findings.append({
                    "type": "AUTHENTICATION_BURST",
                    "severity": "HIGH",
                    "source_ip": ip,
                    "attempts": count,
                    "window_seconds": 60
                })

                self.stats[
                    "auth_bursts"
                ] += 1

        # ----------------------------------------------
        # Web attack
        # ----------------------------------------------

        if self.detect_web_attack(event):

            findings.append({
                "type": "WEB_ATTACK_INDICATOR",
                "severity": "HIGH",
                "source_ip": ip,
                "description": event["description"]
            })

            self.stats[
                "web_indicators"
            ] += 1

        # ----------------------------------------------
        # Privilege escalation
        # ----------------------------------------------

        if self.detect_privilege(event):

            findings.append({
                "type": "PRIVILEGE_ESCALATION_INDICATOR",
                "severity": "HIGH",
                "user": event["user"],
                "description": event["description"]
            })

            self.stats[
                "privilege_indicators"
            ] += 1

        # ----------------------------------------------
        # Malware
        # ----------------------------------------------

        if self.detect_malware(event):

            findings.append({
                "type": "MALWARE_INDICATOR",
                "severity": "CRITICAL",
                "description": event["description"]
            })

            self.stats[
                "malware_indicators"
            ] += 1

        # ----------------------------------------------
        # Suspicious tools
        # ----------------------------------------------

        suspicious_tools = (
            self.detect_suspicious_tools(
                event
            )
        )

        if suspicious_tools:

            findings.append({
                "type": "SUSPICIOUS_TOOL",
                "severity": "MEDIUM",
                "tools": suspicious_tools
            })

        # ----------------------------------------------
        # Multi-stage correlation
        # ----------------------------------------------

        recent_events = [
            item[1]
            for item in self.events[ip]
        ]

        has_auth = any(
            self.detect_auth_failure(x)
            for x in recent_events
        )

        has_privilege = any(
            self.detect_privilege(x)
            for x in recent_events
        )

        has_malware = any(
            self.detect_malware(x)
            for x in recent_events
        )

        if (
            has_auth
            and has_privilege
        ):

            findings.append({
                "type": "MULTI_STAGE_ACTIVITY",
                "severity": "CRITICAL",
                "chain": [
                    "Authentication activity",
                    "Privilege escalation indicator"
                ]
            })

        if (
            has_privilege
            and has_malware
        ):

            findings.append({
                "type": "MULTI_STAGE_ACTIVITY",
                "severity": "CRITICAL",
                "chain": [
                    "Privilege escalation indicator",
                    "Malware indicator"
                ]
            })

        return findings

    # --------------------------------------------------
    # Risk score
    # --------------------------------------------------

    @staticmethod
    def calculate_risk(event, findings):

        score = 0

        score += min(
            event["level"] * 4,
            40
        )

        weights = {
            "AUTHENTICATION_BURST": 20,
            "WEB_ATTACK_INDICATOR": 20,
            "PRIVILEGE_ESCALATION_INDICATOR": 25,
            "MALWARE_INDICATOR": 35,
            "SUSPICIOUS_TOOL": 15,
            "MULTI_STAGE_ACTIVITY": 35
        }

        for finding in findings:

            score += weights.get(
                finding["type"],
                5
            )

        return min(
            score,
            100
        )

    @staticmethod
    def risk_label(score):

        if score >= 80:
            return "CRITICAL"

        if score >= 60:
            return "HIGH"

        if score >= 30:
            return "MEDIUM"

        return "LOW"

    # --------------------------------------------------
    # IOC extraction
    # --------------------------------------------------

    def extract_iocs(self, event):

        text = self.clean_text(
            event["raw"]
        )

        return {
            "ipv4_ipv6": self.extract_ips(
                text
            ),
            "urls": self.extract_urls(
                text
            ),
            "hashes": self.extract_hashes(
                text
            )
        }

    # --------------------------------------------------
    # Deduplication
    # --------------------------------------------------

    def is_duplicate(
        self,
        event,
        findings
    ):

        key_data = (
            event["rule_id"],
            event["agent"],
            event["src_ip"],
            tuple(
                x["type"]
                for x in findings
            )
        )

        fingerprint = hashlib.sha256(
            repr(key_data).encode()
        ).hexdigest()

        now = time.time()

        previous = self.dedup.get(
            fingerprint
        )

        self.dedup[
            fingerprint
        ] = now

        if (
            previous
            and now - previous
            < DEDUP_SECONDS
        ):

            return True

        return False

    # --------------------------------------------------
    # Incident creation
    # --------------------------------------------------

    def build_incident(
        self,
        event,
        findings
    ):

        risk = self.calculate_risk(
            event,
            findings
        )

        incident_id = (
            "INC-"
            + datetime.now().strftime(
                "%Y%m%d-%H%M%S"
            )
            + "-"
            + hashlib.sha1(
                (
                    event["rule_id"]
                    + event["agent"]
                    + event["src_ip"]
                ).encode()
            ).hexdigest()[:8]
        )

        return {
            "incident_id": incident_id,
            "created_at": self.utc_now(),

            "risk": {
                "score": risk,
                "level": self.risk_label(
                    risk
                )
            },

            "source": {
                "agent": event["agent"],
                "agent_id": event["agent_id"],
                "source_ip": event["src_ip"],
                "destination_ip": event["dst_ip"],
                "user": event["user"]
            },

            "detection": {
                "rule_id": event["rule_id"],
                "rule_level": event["level"],
                "description": event[
                    "description"
                ],
                "mitre_ids": event[
                    "mitre_ids"
                ],
                "mitre_tactics": event[
                    "mitre_tactics"
                ],
                "mitre_techniques": event[
                    "mitre_techniques"
                ],
                "groups": event[
                    "groups"
                ]
            },

            "findings": findings,

            "iocs": self.extract_iocs(
                event
            )
        }

    # --------------------------------------------------
    # JSON report
    # --------------------------------------------------

    def save_incident(
        self,
        incident
    ):

        date = datetime.now().strftime(
            "%Y-%m-%d"
        )

        filename = os.path.join(
            self.report_dir,
            f"incidents-{date}.jsonl"
        )

        with open(
            filename,
            "a",
            encoding="utf-8"
        ) as file:

            file.write(
                json.dumps(
                    incident,
                    ensure_ascii=False
                )
                + "\n"
            )

    # --------------------------------------------------
    # Webhook
    # --------------------------------------------------

    def send_webhook(
        self,
        incident
    ):

        if not self.webhook:
            return

        payload = json.dumps(
            incident,
            ensure_ascii=False
        ).encode("utf-8")

        request = urllib.request.Request(
            self.webhook,
            data=payload,
            headers={
                "Content-Type":
                    "application/json"
            },
            method="POST"
        )

        try:

            with urllib.request.urlopen(
                request,
                timeout=5
            ):

                pass

        except (
            urllib.error.URLError,
            TimeoutError
        ):

            print(
                "[!] Webhook notification failed"
            )

    # --------------------------------------------------
    # Console output
    # --------------------------------------------------

    @staticmethod
    def print_incident(
        incident
    ):

        print()
        print("=" * 72)

        print(
            "🔥 WAZUH THREAT HUNTER INCIDENT"
        )

        print("=" * 72)

        print(
            f"Incident : "
            f"{incident['incident_id']}"
        )

        print(
            f"Risk     : "
            f"{incident['risk']['score']}/100 "
            f"({incident['risk']['level']})"
        )

        source = incident[
            "source"
        ]

        print(
            f"Agent    : "
            f"{source['agent']}"
        )

        print(
            f"Source IP: "
            f"{source['source_ip'] or '-'}"
        )

        print(
            f"User     : "
            f"{source['user'] or '-'}"
        )

        detection = incident[
            "detection"
        ]

        print(
            f"Rule     : "
            f"{detection['rule_id']}"
        )

        print(
            f"Level    : "
            f"{detection['rule_level']}"
        )

        print(
            f"Description:\n"
            f"  {detection['description']}"
        )

        print("\nFindings:")

        for finding in incident[
            "findings"
        ]:

            print(
                f"  [!] "
                f"{finding['type']} "
                f"({finding['severity']})"
            )

        mitre = detection[
            "mitre_ids"
        ]

        if mitre:

            print(
                "\nMITRE ATT&CK: "
                + ", ".join(
                    str(x)
                    for x in mitre
                )
            )

        iocs = incident[
            "iocs"
        ]

        if iocs["ipv4_ipv6"]:

            print(
                "\nIPs: "
                + ", ".join(
                    iocs["ipv4_ipv6"]
                )
            )

        if iocs["urls"]:

            print(
                "URLs: "
                + ", ".join(
                    iocs["urls"]
                )
            )

        if iocs["hashes"]:

            print(
                "Hashes: "
                + ", ".join(
                    iocs["hashes"]
                )
            )

        print("=" * 72)

    # --------------------------------------------------
    # Process one alert
    # --------------------------------------------------

    def process_alert(
        self,
        alert
    ):

        event = self.normalize_alert(
            alert
        )

        self.stats[
            "alerts"
        ] += 1

        if event["level"] >= (
            self.severity_threshold
        ):

            self.stats[
                "high_severity"
            ] += 1

        findings = self.correlate(
            event
        )

        # High Wazuh alert itself
        if (
            event["level"]
            >= self.severity_threshold
        ):

            findings.append({
                "type": "HIGH_WAZUH_SEVERITY",
                "severity": "HIGH",
                "rule_level": event[
                    "level"
                ]
            })

        if not findings:
            return

        if self.is_duplicate(
            event,
            findings
        ):

            return

        incident = self.build_incident(
            event,
            findings
        )

        self.stats[
            "incidents"
        ] += 1

        self.print_incident(
            incident
        )

        self.save_incident(
            incident
        )

        self.send_webhook(
            incident
        )

    # --------------------------------------------------
    # Real-time file monitor
    # --------------------------------------------------

    def run(self):

        print(
            """
╔══════════════════════════════════════════════════════════╗
║                 WAZUH THREAT HUNTER                    ║
╠══════════════════════════════════════════════════════════╣
║ Mode       : REAL-TIME                                  ║
║ Detection  : CORRELATION + IOC + MITRE                 ║
║ Action     : MONITOR / REPORT ONLY                      ║
╚══════════════════════════════════════════════════════════╝
"""
        )

        print(
            f"[+] Monitoring: "
            f"{self.alert_file}"
        )

        print(
            f"[+] Report dir: "
            f"{self.report_dir}"
        )

        if not os.path.isfile(
            self.alert_file
        ):

            print(
                "\n[ERROR] alerts.json not found."
            )

            print(
                "Make sure Wazuh Manager is "
                "installed and JSON alert output "
                "is enabled."
            )

            sys.exit(1)

        try:

            with open(
                self.alert_file,
                "r",
                encoding="utf-8",
                errors="ignore"
            ) as file:

                file.seek(
                    0,
                    os.SEEK_END
                )

                while True:

                    position = file.tell()

                    line = file.readline()

                    # File rotation/truncation
                    if not line:

                        try:

                            current_size = os.path.getsize(
                                self.alert_file
                            )

                            if current_size < position:

                                file.seek(
                                    0,
                                    os.SEEK_SET
                                )

                        except OSError:

                            pass

                        time.sleep(
                            0.5
                        )

                        continue

                    line = line.strip()

                    if not line:
                        continue

                    try:

                        alert = json.loads(
                            line
                        )

                        self.process_alert(
                            alert
                        )

                    except json.JSONDecodeError:

                        continue

                    except Exception as error:

                        print(
                            f"[ERROR] "
                            f"{error}"
                        )

        except PermissionError:

            print(
                "\n[ERROR] Permission denied."
            )

            print(
                "Run the script with sudo "
                "on the Wazuh Manager."
            )

            sys.exit(1)

        except KeyboardInterrupt:

            print(
                "\n\n[+] Threat Hunter stopped."
            )

            print(
                f"[+] Alerts processed: "
                f"{self.stats['alerts']}"
            )

            print(
                f"[+] Incidents: "
                f"{self.stats['incidents']}"
            )


def main():

    parser = argparse.ArgumentParser(
        description=(
            "Wazuh Real-Time Threat Hunter"
        )
    )

    parser.add_argument(
        "-f",
        "--file",
        default=DEFAULT_ALERT_FILE,
        help="Path to Wazuh alerts.json"
    )

    parser.add_argument(
        "-o",
        "--output",
        default=DEFAULT_REPORT_DIR,
        help="Incident report directory"
    )

    parser.add_argument(
        "-t",
        "--threshold",
        type=int,
        default=10,
        help="Wazuh severity threshold"
    )

    parser.add_argument(
        "--webhook",
        default=None,
        help="Optional HTTP webhook URL"
    )

    args = parser.parse_args()

    hunter = ThreatHunter(
        alert_file=args.file,
        report_dir=args.output,
        severity_threshold=args.threshold,
        webhook=args.webhook
    )

    hunter.run()


if __name__ == "__main__":
    main()