#!/usr/bin/env python3

import argparse
import json
import re
import socket
import ssl
import sys
import time
from collections import deque
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse, urldefrag
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError


VERSION = "1.0"
MAX_PAGES = 100
TIMEOUT = 8

SECURITY_HEADERS = {
    "content-security-policy": "CSP",
    "strict-transport-security": "HSTS",
    "x-frame-options": "X-Frame-Options",
    "x-content-type-options": "X-Content-Type-Options",
    "referrer-policy": "Referrer-Policy",
    "permissions-policy": "Permissions-Policy",
}


class LinkParser(HTMLParser):

    def __init__(self):
        super().__init__()
        self.links = set()
        self.forms = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)

        if tag == "a" and attrs.get("href"):
            self.links.add(attrs["href"])

        if tag == "form":
            self.forms.append({
                "action": attrs.get("action", ""),
                "method": attrs.get("method", "GET").upper()
            })


def normalize_url(url):
    url, _ = urldefrag(url)

    parsed = urlparse(url)

    if parsed.scheme not in ("http", "https"):
        return None

    return url.rstrip("/") or f"{parsed.scheme}://{parsed.netloc}"


def same_host(url, target_host):
    return urlparse(url).netloc == target_host


def fetch(url):
    request = Request(
        url,
        headers={
            "User-Agent": "WebScope/1.0 Security Research"
        }
    )

    try:
        response = urlopen(
            request,
            timeout=TIMEOUT
        )

        body = response.read(500000)

        headers = dict(response.headers)

        return {
            "status": response.status,
            "url": response.geturl(),
            "headers": headers,
            "body": body.decode(
                "utf-8",
                errors="ignore"
            )
        }

    except HTTPError as e:

        body = ""

        try:
            body = e.read(100000).decode(
                "utf-8",
                errors="ignore"
            )
        except Exception:
            pass

        return {
            "status": e.code,
            "url": url,
            "headers": dict(e.headers),
            "body": body
        }

    except Exception as e:

        return {
            "error": str(e)
        }


def analyze_headers(headers):
    findings = []

    normalized = {
        k.lower(): v
        for k, v in headers.items()
    }

    for header, name in SECURITY_HEADERS.items():

        if header not in normalized:

            findings.append({
                "type": "missing_security_header",
                "header": name,
                "severity": "info"
            })

    server = normalized.get("server")

    if server:
        findings.append({
            "type": "server_disclosure",
            "value": server,
            "severity": "info"
        })

    powered = normalized.get("x-powered-by")

    if powered:
        findings.append({
            "type": "technology_disclosure",
            "value": powered,
            "severity": "info"
        })

    return findings


def analyze_cookies(headers):
    cookies = []

    for key, value in headers.items():

        if key.lower() == "set-cookie":

            parts = [
                x.strip()
                for x in value.split(";")
            ]

            cookie_name = parts[0].split("=")[0]

            flags = [
                x.lower()
                for x in parts[1:]
            ]

            cookies.append({
                "name": cookie_name,
                "secure": "secure" in flags,
                "httponly": "httponly" in flags,
                "samesite": next(
                    (
                        x
                        for x in flags
                        if x.startswith("samesite")
                    ),
                    None
                )
            })

    return cookies


def detect_technology(headers, body):
    technologies = set()

    text = body.lower()

    server = headers.get("Server", "")
    powered = headers.get("X-Powered-By", "")

    signatures = {
        "wordpress": [
            "wp-content",
            "wp-includes"
        ],

        "jquery": [
            "jquery"
        ],

        "bootstrap": [
            "bootstrap"
        ],

        "react": [
            "react",
            "__next_data__"
        ],

        "vue": [
            "vue.js",
            "vue.min.js"
        ],

        "laravel": [
            "laravel"
        ],

        "php": [
            "php"
        ]
    }

    combined = (
        text +
        " " +
        server.lower() +
        " " +
        powered.lower()
    )

    for technology, patterns in signatures.items():

        if any(
            pattern in combined
            for pattern in patterns
        ):
            technologies.add(technology)

    return sorted(technologies)


def analyze_tls(host):
    context = ssl.create_default_context()

    try:

        with socket.create_connection(
            (host, 443),
            timeout=TIMEOUT
        ) as sock:

            with context.wrap_socket(
                sock,
                server_hostname=host
            ) as tls:

                certificate = tls.getpeercert()

                return {
                    "version": tls.version(),
                    "cipher": tls.cipher()[0],
                    "issuer": str(
                        certificate.get("issuer")
                    ),
                    "subject": str(
                        certificate.get("subject")
                    ),
                    "expires": certificate.get(
                        "notAfter"
                    )
                }

    except Exception as e:

        return {
            "error": str(e)
        }


def extract_endpoints(body, base_url):
    endpoints = set()

    patterns = [
        r'href=["\']([^"\']+)["\']',
        r'src=["\']([^"\']+)["\']',
        r'action=["\']([^"\']+)["\']'
    ]

    for pattern in patterns:

        for match in re.findall(
            pattern,
            body,
            re.I
        ):

            absolute = urljoin(
                base_url,
                match
            )

            normalized = normalize_url(
                absolute
            )

            if normalized:
                endpoints.add(normalized)

    return endpoints


def crawl(start_url):
    target_host = urlparse(start_url).netloc

    queue = deque([start_url])
    visited = set()

    pages = []
    endpoints = set()
    technologies = set()
    findings = []
    forms = []
    cookies = []

    while queue and len(visited) < MAX_PAGES:

        url = queue.popleft()

        if url in visited:
            continue

        if not same_host(
            url,
            target_host
        ):
            continue

        visited.add(url)

        print(
            f"[+] {len(visited):03d} "
            f"{url}"
        )

        result = fetch(url)

        if "error" in result:
            continue

        body = result.get(
            "body",
            ""
        )

        headers = result.get(
            "headers",
            {}
        )

        page_findings = analyze_headers(
            headers
        )

        page_cookies = analyze_cookies(
            headers
        )

        page_tech = detect_technology(
            headers,
            body
        )

        findings.extend(
            page_findings
        )

        cookies.extend(
            page_cookies
        )

        technologies.update(
            page_tech
        )

        parser = LinkParser()

        try:
            parser.feed(body)
        except Exception:
            pass

        page_links = set()

        for link in parser.links:

            absolute = normalize_url(
                urljoin(url, link)
            )

            if (
                absolute
                and same_host(
                    absolute,
                    target_host
                )
            ):
                page_links.add(
                    absolute
                )

        for endpoint in extract_endpoints(
            body,
            url
        ):
            endpoints.add(endpoint)

        forms.extend(
            parser.forms
        )

        pages.append({
            "url": url,
            "status": result.get("status"),
            "content_type": headers.get(
                "Content-Type"
            ),
            "size": len(body)
        })

        for link in page_links:

            if link not in visited:
                queue.append(link)

    return {
        "pages": pages,
        "endpoints": sorted(endpoints),
        "technologies": sorted(
            technologies
        ),
        "findings": findings,
        "cookies": cookies,
        "forms": forms
    }


def build_report(target):
    print("\n[*] Starting WebScope...\n")

    parsed = urlparse(target)

    if parsed.scheme not in (
        "http",
        "https"
    ):
        target = "https://" + target

    target = normalize_url(target)

    host = urlparse(target).netloc

    print(f"[*] Target: {target}")
    print(f"[*] Host:   {host}\n")

    try:
        ip = socket.gethostbyname(host)
    except Exception:
        ip = None

    print(f"[*] IP: {ip}")

    report = crawl(target)

    tls = None

    if urlparse(target).scheme == "https":
        print("\n[*] Checking TLS...")
        tls = analyze_tls(host)

    report["target"] = target
    report["ip"] = ip
    report["tls"] = tls
    report["tool"] = "WebScope"
    report["version"] = VERSION
    report["timestamp"] = time.strftime(
        "%Y-%m-%dT%H:%M:%SZ",
        time.gmtime()
    )

    return report


def main():

    parser = argparse.ArgumentParser(
        description=
        "WebScope - Web Recon & Security Analyzer"
    )

    parser.add_argument(
        "target",
        help="Authorized HTTP/HTTPS target"
    )

    parser.add_argument(
        "-o",
        "--output",
        default="webscope_report.json",
        help="JSON report"
    )

    args = parser.parse_args()

    print("""
╔════════════════════════════════════╗
║            WEBSCOPE               ║
║     Web Recon & Analyzer          ║
║              v1.0                 ║
╚════════════════════════════════════╝
""")

    print(
        "[!] Use only on systems you "
        "are authorized to test.\n"
    )

    report = build_report(
        args.target
    )

    with open(
        args.output,
        "w",
        encoding="utf-8"
    ) as file:

        json.dump(
            report,
            file,
            indent=4,
            ensure_ascii=False
        )

    print("\n" + "=" * 50)

    print("[+] Scan completed")
    print(
        f"[+] Pages: "
        f"{len(report['pages'])}"
    )

    print(
        f"[+] Endpoints: "
        f"{len(report['endpoints'])}"
    )

    print(
        f"[+] Technologies: "
        f"{len(report['technologies'])}"
    )

    print(
        f"[+] Findings: "
        f"{len(report['findings'])}"
    )

    print(
        f"[+] Report: "
        f"{args.output}"
    )

    print("=" * 50)


if __name__ == "__main__":
    main()